-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.5.8


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


USE s_nounours;

--
-- Dumping data for table `ezapprove_items`
--

/*!40000 ALTER TABLE `ezapprove_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezapprove_items` ENABLE KEYS */;


--
-- Dumping data for table `ezbasket`
--

/*!40000 ALTER TABLE `ezbasket` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezbasket` ENABLE KEYS */;


--
-- Dumping data for table `ezbinaryfile`
--

/*!40000 ALTER TABLE `ezbinaryfile` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezbinaryfile` ENABLE KEYS */;


--
-- Dumping data for table `ezcobj_state`
--

/*!40000 ALTER TABLE `ezcobj_state` DISABLE KEYS */;
INSERT INTO `ezcobj_state` (`default_language_id`,`group_id`,`id`,`identifier`,`language_mask`,`priority`) VALUES 
 (2,2,1,'not_locked',3,0),
 (2,2,2,'locked',3,1);
/*!40000 ALTER TABLE `ezcobj_state` ENABLE KEYS */;


--
-- Dumping data for table `ezcobj_state_group`
--

/*!40000 ALTER TABLE `ezcobj_state_group` DISABLE KEYS */;
INSERT INTO `ezcobj_state_group` (`default_language_id`,`id`,`identifier`,`language_mask`) VALUES 
 (2,2,'ez_lock',3);
/*!40000 ALTER TABLE `ezcobj_state_group` ENABLE KEYS */;


--
-- Dumping data for table `ezcobj_state_group_language`
--

/*!40000 ALTER TABLE `ezcobj_state_group_language` DISABLE KEYS */;
INSERT INTO `ezcobj_state_group_language` (`contentobject_state_group_id`,`description`,`language_id`,`name`) VALUES 
 (2,'',3,'Lock');
/*!40000 ALTER TABLE `ezcobj_state_group_language` ENABLE KEYS */;


--
-- Dumping data for table `ezcobj_state_language`
--

/*!40000 ALTER TABLE `ezcobj_state_language` DISABLE KEYS */;
INSERT INTO `ezcobj_state_language` (`contentobject_state_id`,`description`,`language_id`,`name`) VALUES 
 (1,'',3,'Not locked'),
 (2,'',3,'Locked');
/*!40000 ALTER TABLE `ezcobj_state_language` ENABLE KEYS */;


--
-- Dumping data for table `ezcobj_state_link`
--

/*!40000 ALTER TABLE `ezcobj_state_link` DISABLE KEYS */;
INSERT INTO `ezcobj_state_link` (`contentobject_id`,`contentobject_state_id`) VALUES 
 (4,1),
 (10,1),
 (11,1),
 (12,1),
 (13,1),
 (14,1),
 (41,1),
 (42,1),
 (45,1),
 (49,1),
 (50,1),
 (51,1),
 (52,1),
 (54,1),
 (56,1),
 (57,1),
 (58,1),
 (59,1),
 (61,1),
 (62,1),
 (63,1),
 (64,1),
 (65,1),
 (66,1),
 (67,1),
 (68,1),
 (70,1),
 (71,1),
 (73,1),
 (74,1);
/*!40000 ALTER TABLE `ezcobj_state_link` ENABLE KEYS */;


--
-- Dumping data for table `ezcollab_group`
--

/*!40000 ALTER TABLE `ezcollab_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezcollab_group` ENABLE KEYS */;


--
-- Dumping data for table `ezcollab_item`
--

/*!40000 ALTER TABLE `ezcollab_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezcollab_item` ENABLE KEYS */;


--
-- Dumping data for table `ezcollab_item_group_link`
--

/*!40000 ALTER TABLE `ezcollab_item_group_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezcollab_item_group_link` ENABLE KEYS */;


--
-- Dumping data for table `ezcollab_item_message_link`
--

/*!40000 ALTER TABLE `ezcollab_item_message_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezcollab_item_message_link` ENABLE KEYS */;


--
-- Dumping data for table `ezcollab_item_participant_link`
--

/*!40000 ALTER TABLE `ezcollab_item_participant_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezcollab_item_participant_link` ENABLE KEYS */;


--
-- Dumping data for table `ezcollab_item_status`
--

/*!40000 ALTER TABLE `ezcollab_item_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezcollab_item_status` ENABLE KEYS */;


--
-- Dumping data for table `ezcollab_notification_rule`
--

/*!40000 ALTER TABLE `ezcollab_notification_rule` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezcollab_notification_rule` ENABLE KEYS */;


--
-- Dumping data for table `ezcollab_profile`
--

/*!40000 ALTER TABLE `ezcollab_profile` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezcollab_profile` ENABLE KEYS */;


--
-- Dumping data for table `ezcollab_simple_message`
--

/*!40000 ALTER TABLE `ezcollab_simple_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezcollab_simple_message` ENABLE KEYS */;


--
-- Dumping data for table `ezcontent_language`
--

/*!40000 ALTER TABLE `ezcontent_language` DISABLE KEYS */;
INSERT INTO `ezcontent_language` (`disabled`,`id`,`locale`,`name`) VALUES 
 (0,2,'fre-FR','Français (France)'),
 (0,4,'eng-GB','English (United Kingdom)');
/*!40000 ALTER TABLE `ezcontent_language` ENABLE KEYS */;


--
-- Dumping data for table `ezcontentbrowsebookmark`
--

/*!40000 ALTER TABLE `ezcontentbrowsebookmark` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezcontentbrowsebookmark` ENABLE KEYS */;


--
-- Dumping data for table `ezcontentbrowserecent`
--

/*!40000 ALTER TABLE `ezcontentbrowserecent` DISABLE KEYS */;
INSERT INTO `ezcontentbrowserecent` (`created`,`id`,`name`,`node_id`,`user_id`) VALUES 
 (1306081523,1,'eZ Publish',2,14),
 (1305866665,2,'Users',5,14),
 (1305867536,3,'Peluches',61,14),
 (1305867739,4,'Poupées',64,14),
 (1307017623,5,'Multimedia',53,14);
/*!40000 ALTER TABLE `ezcontentbrowserecent` ENABLE KEYS */;


--
-- Dumping data for table `ezcontentclass`
--

/*!40000 ALTER TABLE `ezcontentclass` DISABLE KEYS */;
INSERT INTO `ezcontentclass` (`always_available`,`contentobject_name`,`created`,`creator_id`,`id`,`identifier`,`initial_language_id`,`is_container`,`language_mask`,`modified`,`modifier_id`,`remote_id`,`serialized_description_list`,`serialized_name_list`,`sort_field`,`sort_order`,`url_alias_name`,`version`) VALUES 
 (1,'<short_name|name>',1024392098,14,1,'folder',2,1,3,1082454875,14,'a3d405b81be900468eb153d774f4f0d2','a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:6:\"Folder\";}',1,1,'',0),
 (1,'<name>',1024392098,14,3,'user_group',2,1,3,1048494743,14,'25b4268cdcd01921b808a0d854b877ef','a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:10:\"User group\";}',1,1,'',0),
 (1,'<first_name> <last_name>',1024392098,14,4,'user',2,0,3,1082018364,14,'40faa822edc579b02c25f6bb7beec3ad','a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:4:\"User\";}',1,1,'',0),
 (0,'<subject>',1052385685,14,13,'comment',2,0,3,1082455144,14,'000c14f4f475e9f2955dedab72799941','a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:7:\"Comment\";}',1,1,'',0),
 (1,'<name>',1081858024,14,14,'common_ini_settings',2,0,3,1081858024,14,'ffedf2e73b1ea0c3e630e42e2db9c900','a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:19:\"Common ini settings\";}',1,1,'',0),
 (1,'<title>',1081858045,14,15,'template_look',2,0,3,1081858045,14,'59b43cd9feaaf0e45ac974fb4bbd3f92','a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:13:\"Template look\";}',1,1,'',0),
 (0,'<short_title|title>',1305866654,14,16,'article',4,1,5,1305866654,14,'c15b600eb9198b1924063b5a68758232','a:0:{}','a:2:{s:6:\"eng-GB\";s:7:\"Article\";s:16:\"always-available\";s:6:\"eng-GB\";}',1,1,'',0),
 (0,'<short_title|title>',1305866655,14,17,'article_mainpage',4,1,5,1305866655,14,'feaf24c0edae665e7ddaae1bc2b3fe5b','a:0:{}','a:2:{s:6:\"eng-GB\";s:19:\"Article (main-page)\";s:16:\"always-available\";s:6:\"eng-GB\";}',1,1,'',0),
 (0,'<title|index_title>',1305866655,14,18,'article_subpage',4,0,5,1305866655,14,'68f305a18c76d9d03df36b810f290732','a:0:{}','a:2:{s:6:\"eng-GB\";s:18:\"Article (sub-page)\";s:16:\"always-available\";s:6:\"eng-GB\";}',1,1,'',0),
 (0,'<name>',1305866655,14,19,'blog',4,1,5,1305866655,14,'3a6f9c1f075b3bf49d7345576b196fe8','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Blog\";s:16:\"always-available\";s:6:\"eng-GB\";}',1,1,'',0),
 (0,'<title>',1305866655,14,20,'blog_post',4,1,5,1305866655,14,'7ecb961056b7cbb30f22a91357e0a007','a:0:{}','a:2:{s:6:\"eng-GB\";s:9:\"Blog post\";s:16:\"always-available\";s:6:\"eng-GB\";}',1,1,'',0),
 (0,'<name>',1305866655,14,21,'product',4,0,5,1305866655,14,'77f3ede996a3a39c7159cc69189c5307','a:0:{}','a:2:{s:6:\"eng-GB\";s:7:\"Product\";s:16:\"always-available\";s:6:\"eng-GB\";}',1,1,'',0),
 (0,'<name>',1305866656,14,22,'feedback_form',4,1,5,1305866656,14,'df0257b8fc55f6b8ab179d6fb915455e','a:0:{}','a:2:{s:6:\"eng-GB\";s:13:\"Feedback form\";s:16:\"always-available\";s:6:\"eng-GB\";}',1,1,'',0),
 (0,'<name>',1305866656,14,23,'frontpage',4,1,5,1305866656,14,'e36c458e3e4a81298a0945f53a2c81f4','a:0:{}','a:2:{s:6:\"eng-GB\";s:9:\"Frontpage\";s:16:\"always-available\";s:6:\"eng-GB\";}',1,1,'',0),
 (0,'<title>',1305866656,14,24,'documentation_page',4,1,5,1305866656,14,'d4a05eed0402e4d70fedfda2023f1aa2','a:0:{}','a:2:{s:6:\"eng-GB\";s:18:\"Documentation page\";s:16:\"always-available\";s:6:\"eng-GB\";}',1,1,'',0),
 (0,'<header>',1305866656,14,25,'infobox',4,0,5,1305866656,14,'0b4e8accad5bec5ba2d430acb25c1ff6','a:0:{}','a:2:{s:6:\"eng-GB\";s:7:\"Infobox\";s:16:\"always-available\";s:6:\"eng-GB\";}',1,1,'',0),
 (0,'<name>',1305866656,14,26,'multicalendar',4,0,5,1305866656,14,'99aec4e5682414517ed929ecd969439f','a:0:{}','a:2:{s:6:\"eng-GB\";s:13:\"Multicalendar\";s:16:\"always-available\";s:6:\"eng-GB\";}',1,1,'',0),
 (0,'<name>',1305866656,14,27,'poll',4,0,5,1305866656,14,'232937a3a2eacbbf24e2601aebe16522','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Poll\";s:16:\"always-available\";s:6:\"eng-GB\";}',1,1,'',0),
 (0,'<name>',1305866656,14,28,'file',4,0,5,1305866656,14,'637d58bfddf164627bdfd265733280a0','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"File\";s:16:\"always-available\";s:6:\"eng-GB\";}',1,1,'',0),
 (0,'<name>',1305866656,14,29,'flash',4,0,5,1305866656,14,'6cd17b98a41ee9355371a376e8868ee0','a:0:{}','a:2:{s:6:\"eng-GB\";s:5:\"Flash\";s:16:\"always-available\";s:6:\"eng-GB\";}',1,1,'',0),
 (0,'<name>',1305866656,14,30,'flash_recorder',4,0,5,1305866656,14,'e349c947fd306299418be35b07b9a940','a:0:{}','a:2:{s:6:\"eng-GB\";s:14:\"Flash recorder\";s:16:\"always-available\";s:6:\"eng-GB\";}',1,1,'',0),
 (0,'<name>',1305866657,14,31,'flash_player',4,0,5,1305866657,14,'20b2ed0982343e6e0a550f7f0c137e06','a:0:{}','a:2:{s:6:\"eng-GB\";s:18:\"Video/Flash Player\";s:16:\"always-available\";s:6:\"eng-GB\";}',1,1,'',0),
 (0,'<name>',1305866657,14,32,'global_layout',4,0,5,1305866657,14,'f0271811b913befa8f062527e909f15e','a:0:{}','a:2:{s:6:\"eng-GB\";s:13:\"Global layout\";s:16:\"always-available\";s:6:\"eng-GB\";}',1,1,'',0),
 (0,'<name>',1305866657,14,33,'image',4,0,5,1305866657,14,'f6df12aa74e36230eb675f364fccd25a','a:0:{}','a:2:{s:6:\"eng-GB\";s:5:\"Image\";s:16:\"always-available\";s:6:\"eng-GB\";}',1,1,'',0),
 (0,'<name>',1305866657,14,34,'link',4,0,5,1305866657,14,'74ec6507063150bc813549b22534ad48','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Link\";s:16:\"always-available\";s:6:\"eng-GB\";}',1,1,'',0),
 (0,'<name>',1305866657,14,35,'quicktime',4,0,5,1305866657,14,'16d7b371979d6ba37894cc8dc306f38f','a:0:{}','a:2:{s:6:\"eng-GB\";s:9:\"Quicktime\";s:16:\"always-available\";s:6:\"eng-GB\";}',1,1,'',0),
 (0,'<name>',1305866657,14,36,'windows_media',4,0,5,1305866657,14,'223dd2551e85b63b55a72d02363faab6','a:0:{}','a:2:{s:6:\"eng-GB\";s:13:\"Windows media\";s:16:\"always-available\";s:6:\"eng-GB\";}',1,1,'',0),
 (0,'<name>',1305866657,14,37,'real_video',4,0,5,1305866657,14,'dba67bc20a4301aa04cc74e411310dfc','a:0:{}','a:2:{s:6:\"eng-GB\";s:10:\"Real video\";s:16:\"always-available\";s:6:\"eng-GB\";}',1,1,'',0),
 (0,'<name>',1305866658,14,38,'gallery',4,1,5,1305866658,14,'6a320cdc3e274841b82fcd63a86f80d1','a:0:{}','a:2:{s:6:\"eng-GB\";s:7:\"Gallery\";s:16:\"always-available\";s:6:\"eng-GB\";}',1,1,'',0),
 (0,'<short_title|title>',1305866658,14,39,'geo_article',4,1,5,1305866658,14,'a98ae5ac95365b958b01fb88dfab3330','a:0:{}','a:2:{s:6:\"eng-GB\";s:11:\"Geo Article\";s:16:\"always-available\";s:6:\"eng-GB\";}',1,1,'',0),
 (0,'<name>',1305866658,14,40,'forum',4,1,5,1305866658,14,'b241f924b96b267153f5f55904e0675a','a:0:{}','a:2:{s:6:\"eng-GB\";s:5:\"Forum\";s:16:\"always-available\";s:6:\"eng-GB\";}',1,1,'',0),
 (0,'<subject>',1305866658,14,41,'forum_topic',4,1,5,1305866658,14,'71f99c516743a33562c3893ef98c9b60','a:0:{}','a:2:{s:6:\"eng-GB\";s:11:\"Forum topic\";s:16:\"always-available\";s:6:\"eng-GB\";}',1,1,'',0),
 (0,'<subject>',1305866658,14,42,'forum_reply',4,0,5,1305866658,14,'80ee42a66b2b8b6ee15f5c5f4b361562','a:0:{}','a:2:{s:6:\"eng-GB\";s:11:\"Forum reply\";s:16:\"always-available\";s:6:\"eng-GB\";}',1,1,'',0),
 (0,'<short_title|title>',1305866658,14,43,'event',4,0,5,1305866658,14,'563cb5edc2adfd2b240efa456c81525f','a:0:{}','a:2:{s:6:\"eng-GB\";s:5:\"Event\";s:16:\"always-available\";s:6:\"eng-GB\";}',1,1,'',0),
 (0,'<short_title|title>',1305866658,14,44,'event_calendar',4,1,5,1305866658,14,'020cbeb6382c8c89dcec2cd406fb47a8','a:0:{}','a:2:{s:6:\"eng-GB\";s:14:\"Event calendar\";s:16:\"always-available\";s:6:\"eng-GB\";}',1,1,'',0),
 (0,'<name>',1305866658,14,45,'banner',4,0,5,1305866658,14,'9cb558e25fd946246bbb32950c00228e','a:0:{}','a:2:{s:6:\"eng-GB\";s:6:\"Banner\";s:16:\"always-available\";s:6:\"eng-GB\";}',1,1,'',0),
 (0,'<title>',1305866658,14,46,'forums',4,1,5,1305866658,14,'60a921e54c1efbb9456bd2283d9e66cb','a:0:{}','a:2:{s:6:\"eng-GB\";s:6:\"Forums\";s:16:\"always-available\";s:6:\"eng-GB\";}',1,1,'',0),
 (0,'<name>',1305866659,14,47,'silverlight',4,0,5,1305866659,14,'8ab17aae77dd4f24b5a8e835784e96e7','a:0:{}','a:2:{s:6:\"eng-GB\";s:11:\"Silverlight\";s:16:\"always-available\";s:6:\"eng-GB\";}',1,1,'',0),
 (0,'<short_title|title>',1305866938,14,48,'page',4,1,5,1305866974,14,'3ecfef3c2dacbc368f851a1b75155f62','a:1:{s:6:\"eng-GB\";s:0:\"\";}','a:2:{s:6:\"eng-GB\";s:4:\"Page\";s:16:\"always-available\";s:6:\"eng-GB\";}',1,1,'',0),
 (1,'<short_name|name>',1305867002,14,49,'categorie',2,1,3,1305867040,14,'f3af8bb3f649bac7e2cec6df3cb61e61','a:3:{i:0;s:0:\"\";s:16:\"always-available\";b:0;s:6:\"fre-FR\";s:0:\"\";}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:10:\"Catégorie\";}',1,1,'',0);
/*!40000 ALTER TABLE `ezcontentclass` ENABLE KEYS */;


--
-- Dumping data for table `ezcontentclass_attribute`
--

/*!40000 ALTER TABLE `ezcontentclass_attribute` DISABLE KEYS */;
INSERT INTO `ezcontentclass_attribute` (`can_translate`,`category`,`contentclass_id`,`data_float1`,`data_float2`,`data_float3`,`data_float4`,`data_int1`,`data_int2`,`data_int3`,`data_int4`,`data_text1`,`data_text2`,`data_text3`,`data_text4`,`data_text5`,`data_type_string`,`id`,`identifier`,`is_information_collector`,`is_required`,`is_searchable`,`placement`,`serialized_data_text`,`serialized_description_list`,`serialized_name_list`,`version`) VALUES 
 (1,'',1,0,0,0,0,255,0,0,0,'Folder','','','','','ezstring',4,'name',0,1,1,1,'a:2:{s:6:\"eng-GB\";s:0:\"\";s:16:\"always-available\";s:6:\"eng-GB\";}','a:2:{s:6:\"eng-GB\";s:0:\"\";s:16:\"always-available\";s:6:\"eng-GB\";}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:4:\"Name\";}',0),
 (1,'',3,0,0,0,0,255,0,0,0,'','','','','','ezstring',6,'name',0,1,1,1,'a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:4:\"Name\";}',0),
 (1,'',3,0,0,0,0,255,0,0,0,'','','','','','ezstring',7,'description',0,0,1,2,'a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:11:\"Description\";}',0),
 (1,'',4,0,0,0,0,255,0,0,0,'','','','','','ezstring',8,'first_name',0,1,1,1,'a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:10:\"First name\";}',0),
 (1,'',4,0,0,0,0,255,0,0,0,'','','','','','ezstring',9,'last_name',0,1,1,2,'a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:9:\"Last name\";}',0),
 (0,'',4,0,0,0,0,0,0,0,0,'','','','','','ezuser',12,'user_account',0,1,1,3,'a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:12:\"User account\";}',0),
 (1,'',1,0,0,0,0,5,0,0,0,'','','','','','ezxmltext',119,'short_description',0,0,1,3,'a:2:{s:6:\"eng-GB\";s:0:\"\";s:16:\"always-available\";s:6:\"eng-GB\";}','a:2:{s:6:\"eng-GB\";s:0:\"\";s:16:\"always-available\";s:6:\"eng-GB\";}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:7:\"Summary\";}',0),
 (1,'',13,0,0,0,0,100,0,0,0,'','','','','','ezstring',149,'subject',0,1,1,1,'a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:7:\"Subject\";}',0),
 (1,'',13,0,0,0,0,0,0,0,0,'','','','','','ezstring',150,'author',0,1,1,2,'a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:6:\"Author\";}',0),
 (1,'',13,0,0,0,0,20,0,0,0,'','','','','','eztext',151,'message',0,1,1,3,'a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:7:\"Message\";}',0),
 (1,'',1,0,0,0,0,100,0,0,0,'','','','','','ezstring',155,'short_name',0,0,1,2,'a:2:{s:6:\"eng-GB\";s:0:\"\";s:16:\"always-available\";s:6:\"eng-GB\";}','a:2:{s:6:\"eng-GB\";s:0:\"\";s:16:\"always-available\";s:6:\"eng-GB\";}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:10:\"Short name\";}',0),
 (1,'',1,0,0,0,0,20,0,0,0,'','','','','','ezxmltext',156,'description',0,0,1,4,'a:2:{s:6:\"eng-GB\";s:0:\"\";s:16:\"always-available\";s:6:\"eng-GB\";}','a:2:{s:6:\"eng-GB\";s:0:\"\";s:16:\"always-available\";s:6:\"eng-GB\";}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:11:\"Description\";}',0),
 (0,'',1,0,0,0,0,0,0,1,0,'','','','','','ezboolean',158,'show_children',0,0,0,5,'a:2:{s:6:\"eng-GB\";s:0:\"\";s:16:\"always-available\";s:6:\"eng-GB\";}','a:2:{s:6:\"eng-GB\";s:0:\"\";s:16:\"always-available\";s:6:\"eng-GB\";}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:17:\"Display sub items\";}',0),
 (1,'',14,0,0,0,0,0,0,0,0,'','','','','','ezstring',159,'name',0,0,1,1,'a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:4:\"Name\";}',0),
 (0,'',14,0,0,0,0,1,0,0,0,'site.ini','SiteSettings','IndexPage','','override;user;admin;demo','ezinisetting',160,'indexpage',0,0,0,2,'a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:10:\"Index Page\";}',0),
 (0,'',14,0,0,0,0,1,0,0,0,'site.ini','SiteSettings','DefaultPage','','override;user;admin;demo','ezinisetting',161,'defaultpage',0,0,0,3,'a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:12:\"Default Page\";}',0),
 (0,'',14,0,0,0,0,2,0,0,0,'site.ini','DebugSettings','DebugOutput','','override;user;admin;demo','ezinisetting',162,'debugoutput',0,0,0,4,'a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:12:\"Debug Output\";}',0),
 (0,'',14,0,0,0,0,2,0,0,0,'site.ini','DebugSettings','DebugByIP','','override;user;admin;demo','ezinisetting',163,'debugbyip',0,0,0,5,'a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:11:\"Debug By IP\";}',0),
 (0,'',14,0,0,0,0,6,0,0,0,'site.ini','DebugSettings','DebugIPList','','override;user;admin;demo','ezinisetting',164,'debugiplist',0,0,0,6,'a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:13:\"Debug IP List\";}',0),
 (0,'',14,0,0,0,0,2,0,0,0,'site.ini','DebugSettings','DebugRedirection','','override;user;admin;demo','ezinisetting',165,'debugredirection',0,0,0,7,'a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:17:\"Debug Redirection\";}',0),
 (0,'',14,0,0,0,0,2,0,0,0,'site.ini','ContentSettings','ViewCaching','','override;user;admin;demo','ezinisetting',166,'viewcaching',0,0,0,8,'a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:12:\"View Caching\";}',0),
 (0,'',14,0,0,0,0,2,0,0,0,'site.ini','TemplateSettings','TemplateCache','','override;user;admin;demo','ezinisetting',167,'templatecache',0,0,0,9,'a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:14:\"Template Cache\";}',0),
 (0,'',14,0,0,0,0,2,0,0,0,'site.ini','TemplateSettings','TemplateCompile','','override;user;admin;demo','ezinisetting',168,'templatecompile',0,0,0,10,'a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:16:\"Template Compile\";}',0),
 (0,'',14,0,0,0,0,6,0,0,0,'image.ini','small','Filters','','override;user;admin;demo','ezinisetting',169,'imagesmall',0,0,0,11,'a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:16:\"Image Small Size\";}',0),
 (0,'',14,0,0,0,0,6,0,0,0,'image.ini','medium','Filters','','override;user;admin;demo','ezinisetting',170,'imagemedium',0,0,0,12,'a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:17:\"Image Medium Size\";}',0),
 (0,'',14,0,0,0,0,6,0,0,0,'image.ini','large','Filters','','override;user;admin;demo','ezinisetting',171,'imagelarge',0,0,0,13,'a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:16:\"Image Large Size\";}',0),
 (0,'',15,0,0,0,0,1,0,0,0,'site.ini','SiteSettings','SiteName','','override;user;admin;demo','ezinisetting',172,'title',0,0,0,1,'a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:5:\"Title\";}',0),
 (0,'',15,0,0,0,0,6,0,0,0,'site.ini','SiteSettings','MetaDataArray','','override;user;admin;demo','ezinisetting',173,'meta_data',0,0,0,2,'a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:9:\"Meta data\";}',0),
 (1,'',15,0,0,0,0,0,0,0,0,'','','','','','ezimage',174,'image',0,0,0,3,'a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:5:\"Image\";}',0),
 (1,'',15,0,0,0,0,0,0,0,0,'sitestyle','','','','','ezpackage',175,'sitestyle',0,0,0,4,'a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:9:\"Sitestyle\";}',0),
 (0,'',15,0,0,0,0,1,0,0,0,'site.ini','MailSettings','AdminEmail','','override;user;admin;demo','ezinisetting',177,'email',0,0,0,6,'a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:5:\"Email\";}',0),
 (0,'',15,0,0,0,0,1,0,0,0,'site.ini','SiteSettings','SiteURL','','override;user;admin;demo','ezinisetting',178,'siteurl',0,0,0,7,'a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:8:\"Site URL\";}',0),
 (1,'',4,0,0,0,0,10,0,0,0,'','','','','','eztext',179,'signature',0,0,1,4,'a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:9:\"Signature\";}',0),
 (1,'',4,0,0,0,0,1,0,0,0,'','','','','','ezimage',180,'image',0,0,0,5,'a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{i:0;s:0:\"\";s:16:\"always-available\";b:0;}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:5:\"Image\";}',0),
 (1,'',1,0,0,0,0,0,0,0,0,'','','','','','ezkeyword',181,'tags',0,0,0,6,'a:2:{s:6:\"eng-GB\";s:0:\"\";s:16:\"always-available\";s:6:\"eng-GB\";}','a:2:{s:6:\"eng-GB\";s:0:\"\";s:16:\"always-available\";s:6:\"eng-GB\";}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:4:\"Tags\";}',0),
 (1,'',1,0,0,0,0,0,0,0,0,'','','','','','ezdatetime',182,'publish_date',0,0,0,7,'a:2:{s:6:\"eng-GB\";s:0:\"\";s:16:\"always-available\";s:6:\"eng-GB\";}','a:2:{s:6:\"eng-GB\";s:0:\"\";s:16:\"always-available\";s:6:\"eng-GB\";}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:12:\"Publish date\";}',0),
 (1,'',16,0,0,0,0,255,0,0,0,'New article','','','','','ezstring',183,'title',0,1,1,1,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:5:\"Title\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',16,0,0,0,0,255,0,0,0,'','','','','','ezstring',184,'short_title',0,0,1,2,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:11:\"Short title\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',16,0,0,0,0,0,0,0,0,'','','','','','ezauthor',185,'author',0,0,0,3,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:6:\"Author\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',16,0,0,0,0,10,0,0,0,'','','','','','ezxmltext',186,'intro',0,1,1,4,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:7:\"Summary\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',16,0,0,0,0,20,0,0,0,'','','','','','ezxmltext',187,'body',0,0,1,5,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Body\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (0,'',16,0,0,0,0,0,0,0,0,'','','','','','ezboolean',188,'enable_comments',0,0,0,6,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:15:\"Enable comments\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',16,0,0,0,0,0,0,0,0,'','','','','','ezimage',189,'image',0,0,1,7,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:5:\"Image\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',16,0,0,0,0,10,0,0,0,'','','','','','ezxmltext',190,'caption',0,0,1,8,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:15:\"Caption (Image)\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',16,0,0,0,0,0,0,0,0,'','','','','','ezdatetime',191,'publish_date',0,0,1,9,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:12:\"Publish date\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',16,0,0,0,0,0,0,0,0,'','','','','','ezdatetime',192,'unpublish_date',0,0,1,10,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:14:\"Unpublish date\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',16,0,0,0,0,0,0,0,0,'','','','','','ezkeyword',193,'tags',0,0,1,11,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Tags\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',16,0,0,0,0,0,0,0,0,'','','','','','ezsrrating',194,'star_rating',0,0,0,12,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:11:\"Star Rating\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',17,0,0,0,0,0,0,0,0,'','','','','','ezstring',195,'title',0,1,1,1,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:5:\"Title\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',17,0,0,0,0,0,0,0,0,'','','','','','ezstring',196,'short_title',0,0,1,2,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:11:\"Short title\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',17,0,0,0,0,0,0,0,0,'','','','','','ezstring',197,'index_title',0,0,1,3,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:11:\"Index title\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',17,0,0,0,0,0,0,0,0,'','','','','','ezauthor',198,'author',0,1,1,4,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:6:\"Author\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',17,0,0,0,0,10,0,0,0,'','','','','','ezxmltext',199,'intro',0,1,1,5,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:7:\"Summary\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',17,0,0,0,0,15,0,0,0,'','','','','','ezxmltext',200,'body',0,0,1,6,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Body\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',17,0,0,0,0,0,0,0,0,'','','','','','ezimage',201,'image',0,0,0,7,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:5:\"Image\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',17,0,0,0,0,5,0,0,0,'','','','','','ezxmltext',202,'caption',0,0,1,8,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:15:\"Caption (Image)\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',17,0,0,0,0,1,0,0,0,'','','','','','ezdatetime',203,'publish_date',0,0,1,9,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:12:\"Publish date\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',17,0,0,0,0,0,0,0,0,'','','','','','ezdatetime',204,'unpublish_date',0,0,1,10,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:14:\"Unpublish date\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',17,0,0,0,0,0,0,0,0,'','','','','','ezkeyword',205,'tags',0,0,1,11,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Tags\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',17,0,0,0,0,0,0,0,0,'','','','','','ezboolean',206,'enable_comments',0,0,1,12,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:15:\"Enable comments\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',18,0,0,0,0,0,0,0,0,'','','','','','ezstring',207,'title',0,1,1,1,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:5:\"Title\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',18,0,0,0,0,0,0,0,0,'','','','','','ezstring',208,'index_title',0,0,1,2,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:11:\"Index title\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',18,0,0,0,0,15,0,0,0,'','','','','','ezxmltext',209,'body',0,0,1,3,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"body\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',18,0,0,0,0,0,0,0,0,'','','','','','ezkeyword',210,'tags',0,0,1,4,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Tags\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',19,0,0,0,0,0,0,0,0,'','','','','','ezstring',211,'name',0,0,1,1,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Name\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',19,0,0,0,0,5,0,0,0,'','','','','','ezxmltext',212,'description',0,0,1,2,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:11:\"Description\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',19,0,0,0,0,0,0,0,0,'','','','','','ezkeyword',213,'tags',0,0,1,3,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Tags\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',20,0,0,0,0,0,0,0,0,'','','','','','ezstring',214,'title',0,0,1,1,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:5:\"Title\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',20,0,0,0,0,25,0,0,0,'','','','','','ezxmltext',215,'body',0,0,1,2,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Body\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',20,0,0,0,0,1,0,0,0,'','','','','','ezdatetime',216,'publication_date',0,0,1,3,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:16:\"Publication date\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',20,0,0,0,0,0,0,0,0,'','','','','','ezdatetime',217,'unpublish_date',0,0,1,4,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:14:\"Unpublish date\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',20,0,0,0,0,0,0,0,0,'','','','','','ezkeyword',218,'tags',0,0,1,5,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Tags\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',20,0,0,0,0,0,0,0,0,'','','','','','ezboolean',219,'enable_comments',0,0,1,6,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:15:\"Enable comments\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',21,0,0,0,0,0,0,0,0,'','','','','','ezstring',220,'name',0,0,1,1,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Name\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',21,0,0,0,0,0,0,0,0,'','','','','','ezstring',221,'product_number',0,0,1,2,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:14:\"Product number\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',21,0,0,0,0,5,0,0,0,'','','','','','ezxmltext',222,'short_description',0,0,1,3,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:17:\"Short description\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',21,0,0,0,0,10,0,0,0,'','','','','','ezxmltext',223,'description',0,0,1,4,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:11:\"Description\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',21,1,0,0,0,1,0,0,0,'','','','','','ezprice',224,'price',0,0,0,5,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:5:\"Price\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',21,0,0,0,0,0,0,0,0,'','','','','','ezimage',225,'image',0,0,0,6,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:5:\"Image\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',21,0,0,0,0,5,0,0,0,'','','','','','ezxmltext',226,'caption',0,0,1,7,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:15:\"Caption (Image)\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',21,0,0,0,0,0,0,0,0,'','','','','','ezmultioption',227,'additional_options',0,0,1,8,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:18:\"Additional options\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',21,0,0,0,0,0,0,0,0,'','','','','','ezkeyword',228,'tags',0,0,1,9,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Tags\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',22,0,0,0,0,0,0,0,0,'','','','','','ezstring',229,'name',0,1,1,1,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Name\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',22,0,0,0,0,10,0,0,0,'','','','','','ezxmltext',230,'description',0,0,1,2,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:11:\"Description\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (0,'',22,0,0,0,0,0,0,0,0,'','','','','','ezstring',231,'sender_name',1,1,0,3,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:11:\"Sender name\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',22,0,0,0,0,0,0,0,0,'','','','','','ezstring',232,'subject',1,1,1,4,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:7:\"Subject\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',22,0,0,0,0,10,0,0,0,'','','','','','eztext',233,'message',1,1,1,5,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:7:\"Message\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (0,'',22,0,0,0,0,0,0,0,0,'','','','','','ezemail',234,'email',1,1,0,6,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:5:\"Email\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (0,'',22,0,0,0,0,0,0,0,0,'','','','','','ezemail',235,'recipient',0,0,0,7,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:9:\"Recipient\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',23,0,0,0,0,0,0,0,0,'','','','','','ezstring',236,'name',0,1,1,1,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Name\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',23,0,0,0,0,0,0,0,0,'','','','','','ezpage',237,'page',0,0,1,2,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:6:\"Layout\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',23,0,0,0,0,0,0,0,0,'','','','','','ezkeyword',238,'tags',0,0,1,3,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Tags\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',24,0,0,0,0,0,0,0,0,'','','','','','ezstring',239,'title',0,1,1,1,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:5:\"Title\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',24,0,0,0,0,20,0,0,0,'','','','','','ezxmltext',240,'body',0,0,1,2,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Body\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',24,0,0,0,0,0,0,0,0,'','','','','','ezkeyword',241,'tags',0,0,1,3,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Tags\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',24,0,0,0,0,0,0,0,0,'','','','','','ezboolean',242,'show_children',0,0,0,4,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:17:\"Display sub items\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',25,0,0,0,0,0,0,0,0,'','','','','','ezstring',243,'header',0,1,0,1,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:6:\"Header\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',25,0,0,0,0,0,0,0,0,'','','','','','ezimage',244,'image',0,0,0,2,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:5:\"Image\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',25,0,0,0,0,0,0,0,0,'','','','','','ezstring',245,'image_url',0,0,1,3,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:11:\"URL (image)\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',25,0,0,0,0,10,0,0,0,'','','','','','ezxmltext',246,'content',0,0,0,4,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:7:\"Content\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',25,0,0,0,0,0,0,0,0,'','','','','','ezurl',247,'url',0,0,0,5,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:3:\"URL\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',26,0,0,0,0,0,0,0,0,'','','','','','ezstring',248,'name',0,0,1,1,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Name\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',26,0,0,0,0,10,0,0,0,'','','','','','ezxmltext',249,'description',0,0,1,2,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:11:\"Description\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',26,0,0,0,0,0,0,0,0,'','','','','<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<related-objects><constraints><allowed-class contentclass-identifier=\"event_calendar\"/></constraints><type value=\"2\"/><selection_type value=\"0\"/><object_class value=\"\"/><contentobject-placement/></related-objects>\n','ezobjectrelationlist',250,'calendars',0,0,1,3,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:9:\"Calendars\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',27,0,0,0,0,0,0,0,0,'','','','','','ezstring',251,'name',0,1,1,1,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Name\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',27,0,0,0,0,10,0,0,0,'','','','','','ezxmltext',252,'description',0,0,1,2,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:11:\"Description\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',27,0,0,0,0,0,0,0,0,'','','','','','ezoption',253,'question',1,1,0,3,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:8:\"Question\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',28,0,0,0,0,0,0,0,0,'New file','','','','','ezstring',254,'name',0,1,1,1,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Name\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',28,0,0,0,0,10,0,0,0,'','','','','','ezxmltext',255,'description',0,0,1,2,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:11:\"Description\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',28,0,0,0,0,0,0,0,0,'','','','','','ezbinaryfile',256,'file',0,1,0,3,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"File\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',28,0,0,0,0,0,0,0,0,'','','','','','ezkeyword',257,'tags',0,0,1,4,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Tags\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',29,0,0,0,0,0,0,0,0,'','','','','','ezstring',258,'name',0,1,1,1,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Name\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',29,0,0,0,0,10,0,0,0,'','','','','','ezxmltext',259,'description',0,0,1,2,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:11:\"Description\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',29,0,0,0,0,0,0,0,0,'flash','','','','','ezmedia',260,'file',0,1,0,3,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"File\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',29,0,0,0,0,0,0,0,0,'','','','','','ezkeyword',261,'tags',0,0,1,4,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Tags\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',30,0,0,0,0,0,0,0,0,'','','','','','ezstring',262,'name',0,0,1,1,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Name\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',30,0,0,0,0,0,0,0,0,'','','','','','ezstring',263,'stream_server',0,0,1,2,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:13:\"Stream server\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',30,0,0,0,0,0,0,0,0,'','','','','','ezstring',264,'file_server',0,0,1,3,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:11:\"File server\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',30,0,0,0,0,0,0,0,0,'ThisIsTheDefaultKeyChangeMe','','','','','ezstring',265,'key',0,0,1,4,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:3:\"Key\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',31,0,0,0,0,0,0,0,0,'','','','','','ezstring',266,'name',0,0,1,1,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Name\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',31,0,0,0,0,10,0,0,0,'','','','','','ezxmltext',267,'description',0,0,1,2,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:11:\"Description\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',31,0,0,0,0,0,0,0,0,'flash','','','','','ezmedia',268,'file',0,0,0,3,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"File\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',31,0,0,0,0,0,0,0,0,'','','','','','ezimage',269,'thumbnail',0,0,0,4,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:9:\"Thumbnail\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',32,0,0,0,0,0,0,0,0,'','','','','','ezstring',270,'name',0,0,1,1,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Name\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',32,0,0,0,0,0,0,0,0,'','','','','','ezpage',271,'page',0,0,1,2,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:6:\"Layout\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',33,0,0,0,0,150,0,0,0,'','','','','','ezstring',272,'name',0,1,1,1,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Name\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',33,0,0,0,0,10,0,0,0,'','','','','','ezxmltext',273,'caption',0,0,1,2,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:7:\"Caption\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',33,0,0,0,0,2,0,0,0,'','','','','','ezimage',274,'image',0,0,0,3,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:5:\"Image\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',33,0,0,0,0,0,0,0,0,'','','','','','ezkeyword',275,'tags',0,0,1,4,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Tags\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',34,0,0,0,0,255,0,0,0,'','','','','','ezstring',276,'name',0,1,1,1,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Name\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',34,0,0,0,0,20,0,0,0,'','','','','','ezxmltext',277,'description',0,0,1,2,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:11:\"Description\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',34,0,0,0,0,0,0,0,0,'','','','','','ezurl',278,'location',0,0,0,3,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:8:\"Location\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',34,0,0,0,0,0,0,1,0,'','','','','','ezboolean',279,'open_in_new_window',0,0,1,4,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:18:\"Open in new window\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',35,0,0,0,0,0,0,0,0,'','','','','','ezstring',280,'name',0,1,1,1,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Name\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',35,0,0,0,0,10,0,0,0,'','','','','','ezxmltext',281,'description',0,0,1,2,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:11:\"Description\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',35,0,0,0,0,0,0,0,0,'quick_time','','','','','ezmedia',282,'file',0,1,0,3,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"File\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',35,0,0,0,0,0,0,0,0,'','','','','','ezkeyword',283,'tags',0,0,1,4,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Tags\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',36,0,0,0,0,0,0,0,0,'','','','','','ezstring',284,'name',0,1,1,1,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Name\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',36,0,0,0,0,10,0,0,0,'','','','','','ezxmltext',285,'description',0,0,1,2,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:11:\"Description\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',36,0,0,0,0,0,0,0,0,'windows_media_player','','','','','ezmedia',286,'file',0,1,0,3,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"File\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',36,0,0,0,0,0,0,0,0,'','','','','','ezkeyword',287,'tags',0,0,1,4,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Tags\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',37,0,0,0,0,0,0,0,0,'','','','','','ezstring',288,'name',0,1,1,1,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Name\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',37,0,0,0,0,10,0,0,0,'','','','','','ezxmltext',289,'description',0,0,1,2,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:11:\"Description\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',37,0,0,0,0,0,0,0,0,'real_player','','','','','ezmedia',290,'file',0,1,0,3,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"File\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',37,0,0,0,0,0,0,0,0,'','','','','','ezkeyword',291,'tags',0,0,1,4,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Tags\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',38,0,0,0,0,0,0,0,0,'','','','','','ezstring',292,'name',0,1,1,1,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Name\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',38,0,0,0,0,10,0,0,0,'','','','','','ezxmltext',293,'short_description',0,0,1,2,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:17:\"Short description\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',38,0,0,0,0,10,0,0,0,'','','','','','ezxmltext',294,'description',0,0,1,3,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:11:\"Description\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',38,0,0,0,0,0,0,0,0,'','','','','','ezobjectrelation',295,'image',0,0,1,4,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:5:\"Image\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',39,0,0,0,0,255,0,0,0,'New article','','','','','ezstring',296,'title',0,1,1,1,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:5:\"Title\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',39,0,0,0,0,255,0,0,0,'','','','','','ezstring',297,'short_title',0,0,1,2,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:11:\"Short title\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',39,0,0,0,0,0,0,0,0,'','','','','','ezauthor',298,'author',0,0,0,3,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:6:\"Author\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',39,0,0,0,0,10,0,0,0,'','','','','','ezxmltext',299,'intro',0,1,1,4,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:7:\"Summary\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',39,0,0,0,0,20,0,0,0,'','','','','','ezxmltext',300,'body',0,0,1,5,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Body\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (0,'',39,0,0,0,0,0,0,0,0,'','','','','','ezboolean',301,'enable_comments',0,0,0,6,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:15:\"Enable comments\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',39,0,0,0,0,0,0,0,0,'','','','','','ezimage',302,'image',0,0,0,7,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:5:\"Image\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',39,0,0,0,0,10,0,0,0,'','','','','','ezxmltext',303,'caption',0,0,1,8,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:15:\"Caption (Image)\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',39,0,0,0,0,0,0,0,0,'','','','','','ezdatetime',304,'publish_date',0,0,1,9,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:12:\"Publish date\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',39,0,0,0,0,0,0,0,0,'','','','','','ezdatetime',305,'unpublish_date',0,0,1,10,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:14:\"Unpublish date\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',39,0,0,0,0,0,0,0,0,'','','','','','ezkeyword',306,'tags',0,0,1,11,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Tags\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',39,0,0,0,0,0,0,0,0,'','','','','','ezgmaplocation',307,'location',0,0,1,12,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:8:\"Location\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',40,0,0,0,0,0,0,0,0,'','','','','','ezstring',308,'name',0,1,1,1,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Name\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',40,0,0,0,0,10,0,0,0,'','','','','','ezxmltext',309,'description',0,0,1,2,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:11:\"Description\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',41,0,0,0,0,0,0,0,0,'','','','','','ezstring',310,'subject',0,1,1,1,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:7:\"Subject\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',41,0,0,0,0,10,0,0,0,'','','','','','eztext',311,'message',0,1,1,2,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:7:\"Message\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',41,0,0,0,0,0,0,0,0,'','','','','','ezboolean',312,'sticky',0,0,1,3,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:6:\"Sticky\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',41,0,0,0,0,0,0,0,0,'','','','','','ezsubtreesubscription',313,'notify_me',0,0,0,4,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:23:\"Notify me about updates\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',42,0,0,0,0,0,0,0,0,'','','','','','ezstring',314,'subject',0,1,1,1,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:7:\"Subject\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',42,0,0,0,0,10,0,0,0,'','','','','','eztext',315,'message',0,1,1,2,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:7:\"Message\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',43,0,0,0,0,55,0,0,0,'','','','','','ezstring',316,'title',0,0,1,1,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:10:\"Full title\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',43,0,0,0,0,19,0,0,0,'','','','','','ezstring',317,'short_title',0,1,1,2,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:11:\"Short title\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',43,0,0,0,0,10,0,0,0,'','','','','','ezxmltext',318,'text',0,0,1,3,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Text\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',43,0,0,0,0,0,0,0,0,'','','','','','ezkeyword',319,'category',0,0,1,4,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:8:\"Category\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (0,'',43,0,0,0,0,1,0,0,0,'','','','','','ezdatetime',320,'from_time',0,1,0,5,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:9:\"From Time\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (0,'',43,0,0,0,0,0,0,0,0,'','','','','','ezdatetime',321,'to_time',0,0,0,6,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:7:\"To Time\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',44,0,0,0,0,65,0,0,0,'','','','','','ezstring',322,'title',0,1,1,1,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:10:\"Full Title\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',44,0,0,0,0,25,0,0,0,'','','','','','ezstring',323,'short_title',0,0,1,2,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:11:\"Short Title\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (0,'',44,0,0,0,0,0,0,0,0,'','','','','<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<ezselection><options><option id=\"0\" name=\"Calendar\"/><option id=\"1\" name=\"Program\"/></options></ezselection>\n','ezselection',324,'view',0,1,0,3,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"View\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',45,0,0,0,0,0,0,0,0,'','','','','','ezstring',325,'name',0,1,0,1,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Name\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',45,0,0,0,0,0,0,0,0,'','','','','','ezstring',326,'url',0,0,0,2,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:3:\"URL\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',45,0,0,0,0,0,0,0,0,'','','','','','ezimage',327,'image',0,1,0,3,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:5:\"Image\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',45,0,0,0,0,10,0,0,0,'','','','','','eztext',328,'image_map',0,0,0,4,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:9:\"Image map\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',45,0,0,0,0,0,0,0,0,'','','','','','ezkeyword',329,'tags',0,0,1,5,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Tags\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',46,0,0,0,0,0,0,0,0,'','','','','','ezstring',330,'title',0,0,1,1,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:5:\"Title\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',46,0,0,0,0,10,0,0,0,'','','','','','ezxmltext',331,'description',0,0,1,2,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:11:\"Description\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',47,0,0,0,0,0,0,0,0,'','','','','','ezstring',332,'name',0,0,1,1,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"Name\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',47,0,0,0,0,5,0,0,0,'','','','','','ezxmltext',333,'description',0,0,1,2,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:11:\"Description\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',47,0,0,0,0,0,0,0,0,'silverlight','','','','','ezmedia',334,'file',0,0,0,3,'a:0:{}','a:0:{}','a:2:{s:6:\"eng-GB\";s:4:\"File\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',15,0,0,0,0,0,0,0,0,'','','','','','ezurl',335,'site_map_url',0,0,0,8,'a:2:{s:6:\"fre-FR\";s:0:\"\";s:16:\"always-available\";s:6:\"fre-FR\";}','a:2:{s:6:\"fre-FR\";s:0:\"\";s:16:\"always-available\";s:6:\"fre-FR\";}','a:2:{s:6:\"fre-FR\";s:12:\"Site map URL\";s:16:\"always-available\";s:6:\"fre-FR\";}',0),
 (1,'',15,0,0,0,0,0,0,0,0,'','','','','','ezurl',336,'tag_cloud_url',0,0,0,9,'a:2:{s:6:\"fre-FR\";s:0:\"\";s:16:\"always-available\";s:6:\"fre-FR\";}','a:2:{s:6:\"fre-FR\";s:0:\"\";s:16:\"always-available\";s:6:\"fre-FR\";}','a:2:{s:6:\"fre-FR\";s:13:\"Tag Cloud URL\";s:16:\"always-available\";s:6:\"fre-FR\";}',0),
 (1,'',15,0,0,0,0,0,0,0,0,'','','','','','ezstring',337,'login_label',0,0,0,10,'a:2:{s:6:\"fre-FR\";s:0:\"\";s:16:\"always-available\";s:6:\"fre-FR\";}','a:2:{s:6:\"fre-FR\";s:0:\"\";s:16:\"always-available\";s:6:\"fre-FR\";}','a:2:{s:6:\"fre-FR\";s:13:\"Login (label)\";s:16:\"always-available\";s:6:\"fre-FR\";}',0),
 (1,'',15,0,0,0,0,0,0,0,0,'','','','','','ezstring',338,'logout_label',0,0,0,11,'a:2:{s:6:\"fre-FR\";s:0:\"\";s:16:\"always-available\";s:6:\"fre-FR\";}','a:2:{s:6:\"fre-FR\";s:0:\"\";s:16:\"always-available\";s:6:\"fre-FR\";}','a:2:{s:6:\"fre-FR\";s:14:\"Logout (label)\";s:16:\"always-available\";s:6:\"fre-FR\";}',0),
 (1,'',15,0,0,0,0,0,0,0,0,'','','','','','ezstring',339,'my_profile_label',0,0,0,12,'a:2:{s:6:\"fre-FR\";s:0:\"\";s:16:\"always-available\";s:6:\"fre-FR\";}','a:2:{s:6:\"fre-FR\";s:0:\"\";s:16:\"always-available\";s:6:\"fre-FR\";}','a:2:{s:6:\"fre-FR\";s:18:\"My profile (label)\";s:16:\"always-available\";s:6:\"fre-FR\";}',0),
 (1,'',15,0,0,0,0,0,0,0,0,'','','','','','ezstring',340,'register_user_label',0,0,0,13,'a:2:{s:6:\"fre-FR\";s:0:\"\";s:16:\"always-available\";s:6:\"fre-FR\";}','a:2:{s:6:\"fre-FR\";s:0:\"\";s:16:\"always-available\";s:6:\"fre-FR\";}','a:2:{s:6:\"fre-FR\";s:25:\"Register new user (label)\";s:16:\"always-available\";s:6:\"fre-FR\";}',0),
 (1,'',15,0,0,0,0,0,0,0,0,'','','','','','ezstring',341,'rss_feed',0,0,0,14,'a:2:{s:6:\"fre-FR\";s:0:\"\";s:16:\"always-available\";s:6:\"fre-FR\";}','a:2:{s:6:\"fre-FR\";s:0:\"\";s:16:\"always-available\";s:6:\"fre-FR\";}','a:2:{s:6:\"fre-FR\";s:8:\"RSS feed\";s:16:\"always-available\";s:6:\"fre-FR\";}',0),
 (1,'',15,0,0,0,0,0,0,0,0,'','','','','','ezstring',342,'shopping_basket_label',0,0,0,15,'a:2:{s:6:\"fre-FR\";s:0:\"\";s:16:\"always-available\";s:6:\"fre-FR\";}','a:2:{s:6:\"fre-FR\";s:0:\"\";s:16:\"always-available\";s:6:\"fre-FR\";}','a:2:{s:6:\"fre-FR\";s:23:\"Shopping basket (label)\";s:16:\"always-available\";s:6:\"fre-FR\";}',0),
 (1,'',15,0,0,0,0,0,0,0,0,'','','','','','ezstring',343,'site_settings_label',0,0,0,16,'a:2:{s:6:\"fre-FR\";s:0:\"\";s:16:\"always-available\";s:6:\"fre-FR\";}','a:2:{s:6:\"fre-FR\";s:0:\"\";s:16:\"always-available\";s:6:\"fre-FR\";}','a:2:{s:6:\"fre-FR\";s:21:\"Site settings (label)\";s:16:\"always-available\";s:6:\"fre-FR\";}',0),
 (1,'',15,0,0,0,0,10,0,0,0,'','','','','','eztext',344,'footer_text',0,0,0,17,'a:2:{s:6:\"fre-FR\";s:0:\"\";s:16:\"always-available\";s:6:\"fre-FR\";}','a:2:{s:6:\"fre-FR\";s:0:\"\";s:16:\"always-available\";s:6:\"fre-FR\";}','a:2:{s:6:\"fre-FR\";s:11:\"Footer text\";s:16:\"always-available\";s:6:\"fre-FR\";}',0),
 (1,'',15,0,0,0,0,0,0,0,0,'','','','','','ezboolean',345,'hide_powered_by',0,0,0,18,'a:2:{s:6:\"fre-FR\";s:0:\"\";s:16:\"always-available\";s:6:\"fre-FR\";}','a:2:{s:6:\"fre-FR\";s:0:\"\";s:16:\"always-available\";s:6:\"fre-FR\";}','a:2:{s:6:\"fre-FR\";s:17:\"Hide \"Powered by\"\";s:16:\"always-available\";s:6:\"fre-FR\";}',0),
 (1,'',15,0,0,0,0,10,0,0,0,'','','','','','eztext',346,'footer_script',0,0,0,19,'a:2:{s:6:\"fre-FR\";s:0:\"\";s:16:\"always-available\";s:6:\"fre-FR\";}','a:2:{s:6:\"fre-FR\";s:0:\"\";s:16:\"always-available\";s:6:\"fre-FR\";}','a:2:{s:6:\"fre-FR\";s:17:\"Footer Javascript\";s:16:\"always-available\";s:6:\"fre-FR\";}',0),
 (1,'',48,0,0,0,0,255,0,0,0,'New article','','','','','ezstring',347,'title',0,1,1,1,'a:0:{}','a:1:{s:6:\"eng-GB\";s:0:\"\";}','a:2:{s:6:\"eng-GB\";s:5:\"Title\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',48,0,0,0,0,255,0,0,0,'','','','','','ezstring',348,'short_title',0,0,1,2,'a:0:{}','a:1:{s:6:\"eng-GB\";s:0:\"\";}','a:2:{s:6:\"eng-GB\";s:11:\"Short title\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',48,0,0,0,0,0,0,0,0,'','','','','','ezauthor',349,'author',0,0,0,3,'a:0:{}','a:1:{s:6:\"eng-GB\";s:0:\"\";}','a:2:{s:6:\"eng-GB\";s:6:\"Author\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',48,0,0,0,0,10,0,0,0,'','','','','','ezxmltext',350,'intro',0,1,1,4,'a:0:{}','a:1:{s:6:\"eng-GB\";s:0:\"\";}','a:2:{s:6:\"eng-GB\";s:7:\"Summary\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',48,0,0,0,0,20,0,0,0,'','','','','','ezxmltext',351,'body',0,0,1,5,'a:0:{}','a:1:{s:6:\"eng-GB\";s:0:\"\";}','a:2:{s:6:\"eng-GB\";s:4:\"Body\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (0,'',48,0,0,0,0,0,0,0,0,'','','','','','ezboolean',352,'enable_comments',0,0,0,6,'a:0:{}','a:1:{s:6:\"eng-GB\";s:0:\"\";}','a:2:{s:6:\"eng-GB\";s:15:\"Enable comments\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',48,0,0,0,0,0,0,0,0,'','','','','','ezimage',353,'image',0,0,0,7,'a:0:{}','a:1:{s:6:\"eng-GB\";s:0:\"\";}','a:2:{s:6:\"eng-GB\";s:5:\"Image\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',48,0,0,0,0,10,0,0,0,'','','','','','ezxmltext',354,'caption',0,0,1,8,'a:0:{}','a:1:{s:6:\"eng-GB\";s:0:\"\";}','a:2:{s:6:\"eng-GB\";s:15:\"Caption (Image)\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',48,0,0,0,0,0,0,0,0,'','','','','','ezdatetime',355,'publish_date',0,0,1,9,'a:0:{}','a:1:{s:6:\"eng-GB\";s:0:\"\";}','a:2:{s:6:\"eng-GB\";s:12:\"Publish date\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',48,0,0,0,0,0,0,0,0,'','','','','','ezdatetime',356,'unpublish_date',0,0,1,10,'a:0:{}','a:1:{s:6:\"eng-GB\";s:0:\"\";}','a:2:{s:6:\"eng-GB\";s:14:\"Unpublish date\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',48,0,0,0,0,0,0,0,0,'','','','','','ezkeyword',357,'tags',0,0,1,11,'a:0:{}','a:1:{s:6:\"eng-GB\";s:0:\"\";}','a:2:{s:6:\"eng-GB\";s:4:\"Tags\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',48,0,0,0,0,0,0,0,0,'','','','','','ezsrrating',358,'star_rating',0,0,0,12,'a:0:{}','a:1:{s:6:\"eng-GB\";s:0:\"\";}','a:2:{s:6:\"eng-GB\";s:11:\"Star Rating\";s:16:\"always-available\";s:6:\"eng-GB\";}',0),
 (1,'',49,0,0,0,0,255,0,0,0,'Folder','','','','','ezstring',359,'name',0,1,1,1,'a:2:{s:6:\"eng-GB\";s:0:\"\";s:16:\"always-available\";s:6:\"eng-GB\";}','a:3:{s:6:\"eng-GB\";s:0:\"\";s:16:\"always-available\";s:6:\"eng-GB\";s:6:\"fre-FR\";s:0:\"\";}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:4:\"Name\";}',0),
 (1,'',49,0,0,0,0,100,0,0,0,'','','','','','ezstring',360,'short_name',0,0,1,2,'a:2:{s:6:\"eng-GB\";s:0:\"\";s:16:\"always-available\";s:6:\"eng-GB\";}','a:3:{s:6:\"eng-GB\";s:0:\"\";s:16:\"always-available\";s:6:\"eng-GB\";s:6:\"fre-FR\";s:0:\"\";}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:10:\"Short name\";}',0),
 (1,'',49,0,0,0,0,5,0,0,0,'','','','','','ezxmltext',361,'short_description',0,0,1,3,'a:2:{s:6:\"eng-GB\";s:0:\"\";s:16:\"always-available\";s:6:\"eng-GB\";}','a:3:{s:6:\"eng-GB\";s:0:\"\";s:16:\"always-available\";s:6:\"eng-GB\";s:6:\"fre-FR\";s:0:\"\";}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:7:\"Summary\";}',0),
 (1,'',49,0,0,0,0,20,0,0,0,'','','','','','ezxmltext',362,'description',0,0,1,4,'a:2:{s:6:\"eng-GB\";s:0:\"\";s:16:\"always-available\";s:6:\"eng-GB\";}','a:3:{s:6:\"eng-GB\";s:0:\"\";s:16:\"always-available\";s:6:\"eng-GB\";s:6:\"fre-FR\";s:0:\"\";}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:11:\"Description\";}',0),
 (0,'',49,0,0,0,0,0,0,1,0,'','','','','','ezboolean',363,'show_children',0,0,0,5,'a:2:{s:6:\"eng-GB\";s:0:\"\";s:16:\"always-available\";s:6:\"eng-GB\";}','a:3:{s:6:\"eng-GB\";s:0:\"\";s:16:\"always-available\";s:6:\"eng-GB\";s:6:\"fre-FR\";s:0:\"\";}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:17:\"Display sub items\";}',0),
 (1,'',49,0,0,0,0,0,0,0,0,'','','','','','ezkeyword',364,'tags',0,0,0,6,'a:2:{s:6:\"eng-GB\";s:0:\"\";s:16:\"always-available\";s:6:\"eng-GB\";}','a:3:{s:6:\"eng-GB\";s:0:\"\";s:16:\"always-available\";s:6:\"eng-GB\";s:6:\"fre-FR\";s:0:\"\";}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:4:\"Tags\";}',0),
 (1,'',49,0,0,0,0,0,0,0,0,'','','','','','ezdatetime',365,'publish_date',0,0,0,7,'a:2:{s:6:\"eng-GB\";s:0:\"\";s:16:\"always-available\";s:6:\"eng-GB\";}','a:3:{s:6:\"eng-GB\";s:0:\"\";s:16:\"always-available\";s:6:\"eng-GB\";s:6:\"fre-FR\";s:0:\"\";}','a:2:{s:16:\"always-available\";s:6:\"fre-FR\";s:6:\"fre-FR\";s:12:\"Publish date\";}',0);
/*!40000 ALTER TABLE `ezcontentclass_attribute` ENABLE KEYS */;


--
-- Dumping data for table `ezcontentclass_classgroup`
--

/*!40000 ALTER TABLE `ezcontentclass_classgroup` DISABLE KEYS */;
INSERT INTO `ezcontentclass_classgroup` (`contentclass_id`,`contentclass_version`,`group_id`,`group_name`) VALUES 
 (1,0,1,'Content'),
 (3,0,2,'Users'),
 (4,0,2,'Users'),
 (13,0,1,'Content'),
 (14,0,4,'Setup'),
 (15,0,4,'Setup'),
 (16,0,1,'Content'),
 (17,0,1,'Content'),
 (18,0,1,'Content'),
 (19,0,1,'Content'),
 (20,0,1,'Content'),
 (21,0,1,'Content'),
 (22,0,1,'Content'),
 (23,0,1,'Content'),
 (24,0,1,'Content'),
 (25,0,1,'Content'),
 (26,0,1,'Content'),
 (27,0,1,'Content'),
 (28,0,3,'Media'),
 (29,0,3,'Media'),
 (30,0,3,'Media'),
 (31,0,3,'Media'),
 (32,0,1,'Content'),
 (33,0,3,'Media'),
 (34,0,1,'Content'),
 (35,0,3,'Media'),
 (36,0,3,'Media'),
 (37,0,3,'Media'),
 (38,0,1,'Content'),
 (39,0,1,'Content'),
 (40,0,1,'Content'),
 (41,0,1,'Content'),
 (42,0,1,'Content'),
 (43,0,1,'Content'),
 (44,0,1,'Content'),
 (45,0,1,'Content'),
 (46,0,1,'Content'),
 (47,0,3,'Media'),
 (48,0,1,'Content'),
 (49,0,1,'Content');
/*!40000 ALTER TABLE `ezcontentclass_classgroup` ENABLE KEYS */;


--
-- Dumping data for table `ezcontentclass_name`
--

/*!40000 ALTER TABLE `ezcontentclass_name` DISABLE KEYS */;
INSERT INTO `ezcontentclass_name` (`contentclass_id`,`contentclass_version`,`language_id`,`language_locale`,`name`) VALUES 
 (1,0,3,'fre-FR','Folder'),
 (3,0,3,'fre-FR','User group'),
 (4,0,3,'fre-FR','User'),
 (13,0,3,'fre-FR','Comment'),
 (14,0,3,'fre-FR','Common ini settings'),
 (15,0,3,'fre-FR','Template look'),
 (16,0,5,'eng-GB','Article'),
 (17,0,5,'eng-GB','Article (main-page)'),
 (18,0,5,'eng-GB','Article (sub-page)'),
 (19,0,5,'eng-GB','Blog'),
 (20,0,5,'eng-GB','Blog post'),
 (21,0,5,'eng-GB','Product'),
 (22,0,5,'eng-GB','Feedback form'),
 (23,0,5,'eng-GB','Frontpage'),
 (24,0,5,'eng-GB','Documentation page'),
 (25,0,5,'eng-GB','Infobox'),
 (26,0,5,'eng-GB','Multicalendar'),
 (27,0,5,'eng-GB','Poll'),
 (28,0,5,'eng-GB','File'),
 (29,0,5,'eng-GB','Flash'),
 (30,0,5,'eng-GB','Flash recorder'),
 (31,0,5,'eng-GB','Video/Flash Player'),
 (32,0,5,'eng-GB','Global layout'),
 (33,0,5,'eng-GB','Image'),
 (34,0,5,'eng-GB','Link'),
 (35,0,5,'eng-GB','Quicktime'),
 (36,0,5,'eng-GB','Windows media'),
 (37,0,5,'eng-GB','Real video'),
 (38,0,5,'eng-GB','Gallery'),
 (39,0,5,'eng-GB','Geo Article'),
 (40,0,5,'eng-GB','Forum'),
 (41,0,5,'eng-GB','Forum topic'),
 (42,0,5,'eng-GB','Forum reply'),
 (43,0,5,'eng-GB','Event'),
 (44,0,5,'eng-GB','Event calendar'),
 (45,0,5,'eng-GB','Banner'),
 (46,0,5,'eng-GB','Forums'),
 (47,0,5,'eng-GB','Silverlight'),
 (48,0,5,'eng-GB','Page'),
 (49,0,3,'fre-FR','Catégorie');
/*!40000 ALTER TABLE `ezcontentclass_name` ENABLE KEYS */;


--
-- Dumping data for table `ezcontentclassgroup`
--

/*!40000 ALTER TABLE `ezcontentclassgroup` DISABLE KEYS */;
INSERT INTO `ezcontentclassgroup` (`created`,`creator_id`,`id`,`modified`,`modifier_id`,`name`) VALUES 
 (1031216928,14,1,1033922106,14,'Content'),
 (1031216941,14,2,1033922113,14,'Users'),
 (1032009743,14,3,1033922120,14,'Media'),
 (1081858024,14,4,1081858024,14,'Setup');
/*!40000 ALTER TABLE `ezcontentclassgroup` ENABLE KEYS */;


--
-- Dumping data for table `ezcontentobject`
--

/*!40000 ALTER TABLE `ezcontentobject` DISABLE KEYS */;
INSERT INTO `ezcontentobject` (`contentclass_id`,`current_version`,`id`,`initial_language_id`,`language_mask`,`modified`,`name`,`owner_id`,`published`,`remote_id`,`section_id`,`status`) VALUES 
 (3,1,4,2,3,1033917596,'Users',14,1033917596,'f5c88a2209584891056f987fd965b0ba',2,1),
 (4,2,10,2,3,1072180405,'Anonymous User',14,1033920665,'faaeb9be3bd98ed09f606fc16d144eca',2,1),
 (3,2,11,2,3,1305866665,'Members',14,1033920746,'5f7f0bdb3381d6a461d8c29ff53d908f',2,1),
 (3,1,12,2,3,1033920775,'Administrator users',14,1033920775,'9b47a45624b023b1a76c73b74d704acf',2,1),
 (3,1,13,2,3,1033920794,'Editors',14,1033920794,'3c160cca19fb135f83bd02d911f04db2',2,1),
 (4,4,14,2,3,1305866663,'Administrator User',14,1033920830,'1bb4fe25487f05527efa8bfd394cecc7',2,1),
 (1,1,41,2,3,1060695457,'Media',14,1060695457,'a6e35cbcb7cd6ae4b691f3eee30cd262',3,1),
 (3,1,42,2,3,1072180330,'Anonymous Users',14,1072180330,'15b256dbea2ae72418ff5facc999e8f9',2,1),
 (1,1,45,2,3,1079684190,'Setup',14,1079684190,'241d538ce310074e602f29f49e44e938',4,1),
 (1,1,49,2,3,1080220197,'Images',14,1080220197,'e7ff633c6b8e0fd3531e74c6e712bead',3,1),
 (1,1,50,2,3,1080220220,'Files',14,1080220220,'732a5acd01b51a6fe6eab448ad4138a9',3,1),
 (1,1,51,2,3,1080220233,'Multimedia',14,1080220233,'09082deb98662a104f325aaa8c4933d3',3,1),
 (14,1,52,2,2,1082016591,'Common INI settings',14,1082016591,'27437f3547db19cf81a33c92578b2c89',4,1),
 (15,2,54,2,2,1301062376,'Nounours',14,1082016652,'8b8b22fe3c6061ed500fbd2b377b885f',5,1),
 (1,1,56,2,3,1103023132,'Design',14,1103023132,'08799e609893f7aba22f10cb466d9cc8',5,1),
 (23,12,57,2,3,1307017812,'Home',14,1195480486,'8a9c9c761004866fb458d89910f52bee',1,1),
 (3,1,58,2,3,1305866665,'Partners',14,1305866665,'7c34280b89b6ff4788cb8ebec78d52e0',1,1),
 (49,1,59,2,3,1305867225,'Peluches',14,1305867225,'fe6b4c28061675c84101ee8038a07e81',1,1),
 (48,1,61,2,2,1305867313,'Mentions légales',14,1305867313,'c8f417a82175962a2b089a99ba5dda72',1,1),
 (49,1,62,2,3,1305867354,'Poupées',14,1305867354,'cd3144d88feebe8248020f92600e1857',1,1),
 (48,1,63,2,2,1305867397,'La société',14,1305867397,'ecca088fe37d49ce7f7ffdb8d4e52580',1,1),
 (21,2,64,2,2,1305867657,'La peluche Mickey Mouse',14,1305867455,'4016e064864fda2e84801e779ba21b42',1,1),
 (21,1,65,2,2,1305867483,'La peluche Minnie Mouse',14,1305867483,'8130c4602d9edd3a03d2c29adb350fde',1,1),
 (21,2,66,2,2,1305979909,'La peluche Donald Duck',14,1305867536,'507aed1750b6079189efd0a0a9dbd09c',1,1),
 (21,1,67,2,2,1305867702,'Mélanie',14,1305867702,'f80b6a0c568cf31a9e209565660e32c1',1,1),
 (21,1,68,2,2,1305867740,'Arthur',14,1305867740,'fbaa8f3f85877cbd0fc20e440269b21f',1,1),
 (39,1,70,2,2,1306043684,'Test google analytics v3',14,1306043684,'3a2297f32a4305bf01a56ea28839ab32',1,1),
 (39,1,71,2,2,1306053770,'Champs elysées',14,1306053770,'c1a4bbff840120f5469e547a2d4a41df',1,1),
 (39,5,73,2,2,1306086687,'New article',14,1306081523,'41483a926b42da8c45730daf01f03898',1,1),
 (29,2,74,2,2,1307017647,'Banniere transparente',14,1307017623,'4825330f91c1e5bfd39379dfe16f0cf0',3,1);
/*!40000 ALTER TABLE `ezcontentobject` ENABLE KEYS */;


--
-- Dumping data for table `ezcontentobject_attribute`
--

/*!40000 ALTER TABLE `ezcontentobject_attribute` DISABLE KEYS */;
INSERT INTO `ezcontentobject_attribute` (`attribute_original_id`,`contentclassattribute_id`,`contentobject_id`,`data_float`,`data_int`,`data_text`,`data_type_string`,`id`,`language_code`,`language_id`,`sort_key_int`,`sort_key_string`,`version`) VALUES 
 (0,7,4,NULL,NULL,'Main group','ezstring',7,'fre-FR',3,0,'',1),
 (0,6,4,NULL,NULL,'Users','ezstring',8,'fre-FR',3,0,'',1),
 (0,8,10,0,0,'Anonymous','ezstring',19,'fre-FR',3,0,'anonymous',2),
 (0,9,10,0,0,'User','ezstring',20,'fre-FR',3,0,'user',2),
 (0,12,10,0,0,'','ezuser',21,'fre-FR',3,0,'',2),
 (0,6,11,0,0,'Guest accounts','ezstring',22,'fre-FR',3,0,'',1),
 (0,6,11,0,0,'Members','ezstring',22,'fre-FR',3,0,'members',2),
 (0,7,11,0,0,'','ezstring',23,'fre-FR',3,0,'',1),
 (0,7,11,0,0,'','ezstring',23,'fre-FR',3,0,'',2),
 (0,6,12,0,0,'Administrator users','ezstring',24,'fre-FR',3,0,'',1),
 (0,7,12,0,0,'','ezstring',25,'fre-FR',3,0,'',1),
 (0,6,13,0,0,'Editors','ezstring',26,'fre-FR',3,0,'',1),
 (0,7,13,0,0,'','ezstring',27,'fre-FR',3,0,'',1),
 (0,8,14,0,0,'Administrator','ezstring',28,'fre-FR',3,0,'administrator',3),
 (0,8,14,0,0,'Administrator','ezstring',28,'fre-FR',3,0,'administrator',4),
 (0,9,14,0,0,'User','ezstring',29,'fre-FR',3,0,'user',3),
 (0,9,14,0,0,'User','ezstring',29,'fre-FR',3,0,'user',4),
 (30,12,14,0,0,'','ezuser',30,'fre-FR',3,0,'',3),
 (30,12,14,0,0,'','ezuser',30,'fre-FR',3,0,'',4),
 (0,4,41,0,0,'Media','ezstring',98,'fre-FR',3,0,'',1),
 (0,119,41,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\"\n         xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\"\n         xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\" />','ezxmltext',99,'fre-FR',3,0,'',1),
 (0,6,42,0,0,'Anonymous Users','ezstring',100,'fre-FR',3,0,'anonymous users',1),
 (0,7,42,0,0,'User group for the anonymous user','ezstring',101,'fre-FR',3,0,'user group for the anonymous user',1),
 (0,155,41,0,0,'','ezstring',103,'fre-FR',3,0,'',1),
 (0,156,41,0,1045487555,'','ezxmltext',105,'fre-FR',3,0,'',1),
 (0,158,41,0,0,'','ezboolean',109,'fre-FR',3,0,'',1),
 (0,4,45,0,0,'Setup','ezstring',123,'fre-FR',3,0,'setup',1),
 (0,155,45,0,0,'','ezstring',124,'fre-FR',3,0,'',1),
 (0,119,45,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\"\n         xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\"\n         xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\" />','ezxmltext',125,'fre-FR',3,0,'',1),
 (0,156,45,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\"\n         xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\"\n         xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\" />','ezxmltext',126,'fre-FR',3,0,'',1),
 (0,158,45,0,0,'','ezboolean',128,'fre-FR',3,0,'',1),
 (0,4,49,0,0,'Images','ezstring',142,'fre-FR',3,0,'images',1),
 (0,155,49,0,0,'','ezstring',143,'fre-FR',3,0,'',1),
 (0,119,49,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\"\n         xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\"\n         xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\" />','ezxmltext',144,'fre-FR',3,0,'',1),
 (0,156,49,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\"\n         xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\"\n         xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\" />','ezxmltext',145,'fre-FR',3,0,'',1),
 (0,158,49,0,1,'','ezboolean',146,'fre-FR',3,1,'',1),
 (0,4,50,0,0,'Files','ezstring',147,'fre-FR',3,0,'files',1),
 (0,155,50,0,0,'','ezstring',148,'fre-FR',3,0,'',1),
 (0,119,50,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\"\n         xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\"\n         xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\" />','ezxmltext',149,'fre-FR',3,0,'',1),
 (0,156,50,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\"\n         xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\"\n         xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\" />','ezxmltext',150,'fre-FR',3,0,'',1),
 (0,158,50,0,1,'','ezboolean',151,'fre-FR',3,1,'',1),
 (0,4,51,0,0,'Multimedia','ezstring',152,'fre-FR',3,0,'multimedia',1),
 (0,155,51,0,0,'','ezstring',153,'fre-FR',3,0,'',1),
 (0,119,51,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\"\n         xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\"\n         xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\" />','ezxmltext',154,'fre-FR',3,0,'',1),
 (0,156,51,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\"\n         xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\"\n         xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\" />','ezxmltext',155,'fre-FR',3,0,'',1),
 (0,158,51,0,1,'','ezboolean',156,'fre-FR',3,1,'',1),
 (0,159,52,0,0,'Common INI settings','ezstring',157,'fre-FR',2,0,'common ini settings',1),
 (0,160,52,0,0,'/content/view/full/2/','ezinisetting',158,'fre-FR',2,0,'',1),
 (0,161,52,0,0,'/content/view/full/2','ezinisetting',159,'fre-FR',2,0,'',1),
 (0,162,52,0,0,'disabled','ezinisetting',160,'fre-FR',2,0,'',1),
 (0,163,52,0,0,'disabled','ezinisetting',161,'fre-FR',2,0,'',1),
 (0,164,52,0,0,'','ezinisetting',162,'fre-FR',2,0,'',1),
 (0,165,52,0,0,'enabled','ezinisetting',163,'fre-FR',2,0,'',1),
 (0,166,52,0,0,'disabled','ezinisetting',164,'fre-FR',2,0,'',1),
 (0,167,52,0,0,'enabled','ezinisetting',165,'fre-FR',2,0,'',1),
 (0,168,52,0,0,'enabled','ezinisetting',166,'fre-FR',2,0,'',1),
 (0,169,52,0,0,'=geometry/scale=100;100','ezinisetting',167,'fre-FR',2,0,'',1),
 (0,170,52,0,0,'=geometry/scale=200;200','ezinisetting',168,'fre-FR',2,0,'',1),
 (0,171,52,0,0,'=geometry/scale=300;300','ezinisetting',169,'fre-FR',2,0,'',1),
 (0,172,54,0,0,'Nounours','ezinisetting',170,'fre-FR',2,0,'',2),
 (0,173,54,0,0,'author=eZ Systems\r\ncopyright=eZ Systems\r\ndescription=Content Management System\r\nkeywords=cms, publish, e-commerce, content management, development framework','ezinisetting',171,'fre-FR',2,0,'',2),
 (0,174,54,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<ezimage serial_number=\"1\" is_valid=\"1\" filename=\"Nounours1.png\" suffix=\"png\" basename=\"Nounours1\" dirpath=\"var/ezflow_site/storage/images/design/plain-site/172-2-fre-FR\" url=\"var/ezflow_site/storage/images/design/plain-site/172-2-fre-FR/Nounours1.png\" original_filename=\"logo.png\" mime_type=\"image/png\" width=\"128\" height=\"39\" alternative_text=\"\" alias_key=\"1293033771\" timestamp=\"1305866665\"><original attribute_id=\"172\" attribute_version=\"2\" attribute_language=\"fre-FR\"/></ezimage>\n','ezimage',172,'fre-FR',2,0,'',2),
 (0,175,54,0,0,'0','ezpackage',173,'fre-FR',2,0,'0',2),
 (0,177,54,0,0,'admin@nounours.local','ezinisetting',175,'fre-FR',2,0,'',2),
 (0,178,54,0,0,'nounours.local/index.php','ezinisetting',176,'fre-FR',2,0,'',2),
 (0,179,10,0,0,'','eztext',177,'fre-FR',3,0,'',2),
 (0,179,14,0,0,'','eztext',178,'fre-FR',3,0,'',3),
 (0,179,14,0,0,'','eztext',178,'fre-FR',3,0,'',4),
 (0,180,10,0,0,'','ezimage',179,'fre-FR',3,0,'',2),
 (0,180,14,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<ezimage serial_number=\"1\" is_valid=\"\" filename=\"\" suffix=\"\" basename=\"\" dirpath=\"\" url=\"\" original_filename=\"\" mime_type=\"\" width=\"\" height=\"\" alternative_text=\"\" alias_key=\"1293033771\" timestamp=\"1301057722\"><original attribute_id=\"180\" attribute_version=\"3\" attribute_language=\"eng-GB\"/></ezimage>\n','ezimage',180,'fre-FR',3,0,'',3),
 (0,180,14,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<ezimage serial_number=\"1\" is_valid=\"\" filename=\"\" suffix=\"\" basename=\"\" dirpath=\"\" url=\"\" original_filename=\"\" mime_type=\"\" width=\"\" height=\"\" alternative_text=\"\" alias_key=\"1293033771\" timestamp=\"1301057722\"><original attribute_id=\"180\" attribute_version=\"3\" attribute_language=\"eng-GB\"/></ezimage>\n','ezimage',180,'fre-FR',3,0,'',4),
 (0,4,56,0,NULL,'Design','ezstring',181,'fre-FR',3,0,'design',1),
 (0,155,56,0,NULL,'','ezstring',182,'fre-FR',3,0,'',1),
 (0,119,56,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\"\n         xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\"\n         xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\" />','ezxmltext',183,'fre-FR',3,0,'',1),
 (0,156,56,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\"\n         xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\"\n         xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\" />','ezxmltext',184,'fre-FR',3,0,'',1),
 (0,158,56,0,1,'','ezboolean',185,'fre-FR',3,1,'',1),
 (0,181,41,0,NULL,'','ezkeyword',187,'fre-FR',3,0,'',1),
 (0,181,45,0,NULL,'','ezkeyword',188,'fre-FR',3,0,'',1),
 (0,181,49,0,NULL,'','ezkeyword',189,'fre-FR',3,0,'',1),
 (0,181,50,0,NULL,'','ezkeyword',190,'fre-FR',3,0,'',1),
 (0,181,51,0,NULL,'','ezkeyword',191,'fre-FR',3,0,'',1),
 (0,181,56,0,NULL,'','ezkeyword',192,'fre-FR',3,0,'',1),
 (0,182,41,0,0,'','ezdatetime',194,'fre-FR',3,0,'',1),
 (0,182,45,0,0,'','ezdatetime',195,'fre-FR',3,0,'',1),
 (0,182,49,0,0,'','ezdatetime',196,'fre-FR',3,0,'',1),
 (0,182,50,0,0,'','ezdatetime',197,'fre-FR',3,0,'',1),
 (0,182,51,0,0,'','ezdatetime',198,'fre-FR',3,0,'',1),
 (0,182,56,0,0,'','ezdatetime',199,'fre-FR',3,0,'',1),
 (0,236,57,0,NULL,'Home','ezstring',200,'fre-FR',3,0,'home',3),
 (0,236,57,0,NULL,'Home','ezstring',200,'fre-FR',3,0,'home',4),
 (0,236,57,0,NULL,'Home','ezstring',200,'fre-FR',3,0,'home',5),
 (0,236,57,0,NULL,'Home','ezstring',200,'fre-FR',3,0,'home',6),
 (0,236,57,0,NULL,'Home','ezstring',200,'fre-FR',3,0,'home',7),
 (0,236,57,0,NULL,'Home','ezstring',200,'fre-FR',3,0,'home',8),
 (0,236,57,0,NULL,'Home','ezstring',200,'fre-FR',3,0,'home',9),
 (0,236,57,0,NULL,'Home','ezstring',200,'fre-FR',3,0,'home',10),
 (0,236,57,0,NULL,'Home','ezstring',200,'fre-FR',3,0,'home',11),
 (0,236,57,0,NULL,'Home','ezstring',200,'fre-FR',3,0,'home',12),
 (0,237,57,0,NULL,'<?xml version=\"1.0\"?>\n<page>\n  <zone_layout>4ZonesLayout2</zone_layout>\n  <zone id=\"id_4f6d946ab48d95799d31179c3acde8cb\">\n    <zone_identifier>top</zone_identifier>\n    <block id=\"id_ab9e386be359563619c639ea52acd75d\">\n      <name></name>\n      <zone_id>4f6d946ab48d95799d31179c3acde8cb</zone_id>\n      <type>DemoBlock</type>\n      <view>demoblock</view>\n    </block>\n  </zone>\n  <zone id=\"id_a1117aa7fd4548568490cc7ab1271a4b\">\n    <zone_identifier>left</zone_identifier>\n    <block id=\"id_ac2a70064d084e1aeceb041389df5449\">\n      <name></name>\n      <zone_id>a1117aa7fd4548568490cc7ab1271a4b</zone_id>\n      <type>DemoBlock</type>\n      <view>demoblock</view>\n    </block>\n  </zone>\n  <zone id=\"id_038ffb3d0c9ba2a8dc1ecc6c3e6ea86d\">\n    <zone_identifier>right</zone_identifier>\n    <block id=\"id_7f759294385cf1456cbca0e4c50272ec\">\n      <name></name>\n      <zone_id>038ffb3d0c9ba2a8dc1ecc6c3e6ea86d</zone_id>\n      <type>DemoBlock</type>\n      <view>demoblock</view>\n    </block>\n  </zone>\n  <zone id=\"id_164b072e900f76653995211929541301\">\n    <zone_identifier>bottom</zone_identifier>\n    <block id=\"id_c5b6f9304fc85e1029ecf596ffd21030\">\n      <name></name>\n      <zone_id>164b072e900f76653995211929541301</zone_id>\n      <type>DemoBlock</type>\n      <view>demoblock</view>\n    </block>\n  </zone>\n</page>\n','ezpage',201,'fre-FR',3,0,'',3),
 (0,237,57,0,NULL,'<?xml version=\"1.0\"?>\n<page>\n  <zone_layout>4ZonesLayout2</zone_layout>\n  <zone id=\"id_4f6d946ab48d95799d31179c3acde8cb\">\n    <zone_identifier>top</zone_identifier>\n    <block id=\"id_ab9e386be359563619c639ea52acd75d\">\n      <name></name>\n      <zone_id>4f6d946ab48d95799d31179c3acde8cb</zone_id>\n      <type>DemoBlock</type>\n      <view>demoblock</view>\n    </block>\n  </zone>\n  <zone id=\"id_a1117aa7fd4548568490cc7ab1271a4b\">\n    <zone_identifier>left</zone_identifier>\n    <block id=\"id_ac2a70064d084e1aeceb041389df5449\">\n      <name></name>\n      <zone_id>a1117aa7fd4548568490cc7ab1271a4b</zone_id>\n      <type>DemoBlock</type>\n      <view>demoblock</view>\n    </block>\n  </zone>\n  <zone id=\"id_038ffb3d0c9ba2a8dc1ecc6c3e6ea86d\">\n    <zone_identifier>right</zone_identifier>\n    <block id=\"id_7f759294385cf1456cbca0e4c50272ec\">\n      <name></name>\n      <zone_id>038ffb3d0c9ba2a8dc1ecc6c3e6ea86d</zone_id>\n      <type>DemoBlock</type>\n      <view>demoblock</view>\n    </block>\n  </zone>\n  <zone id=\"id_164b072e900f76653995211929541301\">\n    <zone_identifier>bottom</zone_identifier>\n    <block id=\"id_c5b6f9304fc85e1029ecf596ffd21030\">\n      <name></name>\n      <zone_id>164b072e900f76653995211929541301</zone_id>\n      <type>DemoBlock</type>\n      <view>demoblock</view>\n    </block>\n    <block id=\"id_480655c28ee1aa2f14d76639cd774cfa\">\n      <name>La soci&#xE9;t&#xE9; T</name>\n      <zone_id>164b072e900f76653995211929541301</zone_id>\n      <type>GMap</type>\n      <custom_attributes>\n        <location>place du louvre </location>\n        <key></key>\n      </custom_attributes>\n      <view>gmap</view>\n    </block>\n  </zone>\n</page>\n','ezpage',201,'fre-FR',3,0,'',4),
 (0,237,57,0,NULL,'<?xml version=\"1.0\"?>\n<page>\n  <zone_layout>4ZonesLayout2</zone_layout>\n  <zone id=\"id_4f6d946ab48d95799d31179c3acde8cb\">\n    <zone_identifier>top</zone_identifier>\n    <block id=\"id_ab9e386be359563619c639ea52acd75d\">\n      <name></name>\n      <zone_id>4f6d946ab48d95799d31179c3acde8cb</zone_id>\n      <type>DemoBlock</type>\n      <view>demoblock</view>\n    </block>\n  </zone>\n  <zone id=\"id_a1117aa7fd4548568490cc7ab1271a4b\">\n    <zone_identifier>left</zone_identifier>\n    <block id=\"id_ac2a70064d084e1aeceb041389df5449\">\n      <name></name>\n      <zone_id>a1117aa7fd4548568490cc7ab1271a4b</zone_id>\n      <type>DemoBlock</type>\n      <view>demoblock</view>\n    </block>\n  </zone>\n  <zone id=\"id_038ffb3d0c9ba2a8dc1ecc6c3e6ea86d\">\n    <zone_identifier>right</zone_identifier>\n    <block id=\"id_7f759294385cf1456cbca0e4c50272ec\">\n      <name></name>\n      <zone_id>038ffb3d0c9ba2a8dc1ecc6c3e6ea86d</zone_id>\n      <type>DemoBlock</type>\n      <view>demoblock</view>\n    </block>\n  </zone>\n  <zone id=\"id_164b072e900f76653995211929541301\">\n    <zone_identifier>bottom</zone_identifier>\n    <block id=\"id_c5b6f9304fc85e1029ecf596ffd21030\">\n      <name></name>\n      <zone_id>164b072e900f76653995211929541301</zone_id>\n      <type>DemoBlock</type>\n      <view>demoblock</view>\n    </block>\n    <block id=\"id_480655c28ee1aa2f14d76639cd774cfa\">\n      <name>O&#xF9; nous trouver</name>\n      <zone_id>164b072e900f76653995211929541301</zone_id>\n      <type>GMap</type>\n      <custom_attributes>\n        <location>1 avenue des champs elys&#xE9;e 75008 paris</location>\n        <key>ABQIAAAAvZi_9OkvCL5hib4G6mxXVRTrtyCTXr34X7fp3FZlYu_6f1uBkhSGMugIl0RSuNzb_Ur-xZ3JRijKGQ</key>\n      </custom_attributes>\n      <view>gmap</view>\n    </block>\n  </zone>\n</page>\n','ezpage',201,'fre-FR',3,0,'',5),
 (0,237,57,0,NULL,'<?xml version=\"1.0\"?>\n<page>\n  <zone_layout>4ZonesLayout2</zone_layout>\n  <zone id=\"id_4f6d946ab48d95799d31179c3acde8cb\">\n    <zone_identifier>top</zone_identifier>\n  </zone>\n  <zone id=\"id_a1117aa7fd4548568490cc7ab1271a4b\">\n    <zone_identifier>left</zone_identifier>\n  </zone>\n  <zone id=\"id_038ffb3d0c9ba2a8dc1ecc6c3e6ea86d\">\n    <zone_identifier>right</zone_identifier>\n  </zone>\n  <zone id=\"id_164b072e900f76653995211929541301\">\n    <zone_identifier>bottom</zone_identifier>\n    <block id=\"id_480655c28ee1aa2f14d76639cd774cfa\">\n      <name>O&#xF9; nous trouver</name>\n      <zone_id>164b072e900f76653995211929541301</zone_id>\n      <type>GMap</type>\n      <custom_attributes>\n        <location>1 avenue des champs elys&#xE9;e 75008 paris</location>\n        <key>ABQIAAAAvZi_9OkvCL5hib4G6mxXVRTrtyCTXr34X7fp3FZlYu_6f1uBkhSGMugIl0RSuNzb_Ur-xZ3JRijKGQ</key>\n      </custom_attributes>\n      <view>gmap</view>\n    </block>\n  </zone>\n</page>\n','ezpage',201,'fre-FR',3,0,'',6),
 (0,237,57,0,NULL,'<?xml version=\"1.0\"?>\n<page>\n  <zone_layout>4ZonesLayout2</zone_layout>\n  <zone id=\"id_4f6d946ab48d95799d31179c3acde8cb\">\n    <zone_identifier>top</zone_identifier>\n    <block id=\"id_dc2295908cddb64c2095232bd2da5a23\">\n      <name>Qui sommes nous</name>\n      <zone_id>4f6d946ab48d95799d31179c3acde8cb</zone_id>\n      <type>Edito</type>\n      <custom_attributes>\n        <texte>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</texte>\n      </custom_attributes>\n      <view>edito</view>\n    </block>\n  </zone>\n  <zone id=\"id_a1117aa7fd4548568490cc7ab1271a4b\">\n    <zone_identifier>left</zone_identifier>\n  </zone>\n  <zone id=\"id_038ffb3d0c9ba2a8dc1ecc6c3e6ea86d\">\n    <zone_identifier>right</zone_identifier>\n  </zone>\n  <zone id=\"id_164b072e900f76653995211929541301\">\n    <zone_identifier>bottom</zone_identifier>\n    <block id=\"id_480655c28ee1aa2f14d76639cd774cfa\">\n      <name>O&#xF9; nous trouver</name>\n      <zone_id>164b072e900f76653995211929541301</zone_id>\n      <type>GMap</type>\n      <custom_attributes>\n        <location>1 avenue des champs elys&#xE9;e 75008 paris</location>\n        <key>ABQIAAAAvZi_9OkvCL5hib4G6mxXVRTrtyCTXr34X7fp3FZlYu_6f1uBkhSGMugIl0RSuNzb_Ur-xZ3JRijKGQ</key>\n      </custom_attributes>\n      <view>gmap</view>\n    </block>\n  </zone>\n</page>\n','ezpage',201,'fre-FR',3,0,'',7),
 (0,237,57,0,NULL,'<?xml version=\"1.0\"?>\n<page>\n  <zone_layout>4ZonesLayout2</zone_layout>\n  <zone id=\"id_4f6d946ab48d95799d31179c3acde8cb\">\n    <zone_identifier>top</zone_identifier>\n    <block id=\"id_dc2295908cddb64c2095232bd2da5a23\">\n      <name>Qui sommes nous</name>\n      <zone_id>4f6d946ab48d95799d31179c3acde8cb</zone_id>\n      <type>Edito</type>\n      <custom_attributes>\n        <texte>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</texte>\n      </custom_attributes>\n      <view>edito</view>\n    </block>\n  </zone>\n  <zone id=\"id_a1117aa7fd4548568490cc7ab1271a4b\">\n    <zone_identifier>left</zone_identifier>\n    <block id=\"id_dc32434bab785565f942f4100be260f2\">\n      <name>Promotion1</name>\n      <zone_id>a1117aa7fd4548568490cc7ab1271a4b</zone_id>\n      <type>NounoursPromotion</type>\n      <view>promotion1</view>\n      <overflow_id></overflow_id>\n    </block>\n  </zone>\n  <zone id=\"id_038ffb3d0c9ba2a8dc1ecc6c3e6ea86d\">\n    <zone_identifier>right</zone_identifier>\n    <block id=\"id_5201665176b2455e198b34425ec20cc6\">\n      <name>Promotions2</name>\n      <zone_id>038ffb3d0c9ba2a8dc1ecc6c3e6ea86d</zone_id>\n      <type>NounoursPromotion</type>\n      <view>promotion2</view>\n      <overflow_id></overflow_id>\n    </block>\n  </zone>\n  <zone id=\"id_164b072e900f76653995211929541301\">\n    <zone_identifier>bottom</zone_identifier>\n    <block id=\"id_480655c28ee1aa2f14d76639cd774cfa\">\n      <name>O&#xF9; nous trouver</name>\n      <zone_id>164b072e900f76653995211929541301</zone_id>\n      <type>GMap</type>\n      <custom_attributes>\n        <location>1 avenue des champs elys&#xE9;e 75008 paris</location>\n        <key>ABQIAAAAvZi_9OkvCL5hib4G6mxXVRTrtyCTXr34X7fp3FZlYu_6f1uBkhSGMugIl0RSuNzb_Ur-xZ3JRijKGQ</key>\n      </custom_attributes>\n      <view>gmap</view>\n    </block>\n  </zone>\n</page>\n','ezpage',201,'fre-FR',3,0,'',8),
 (0,237,57,0,NULL,'<?xml version=\"1.0\"?>\n<page>\n  <zone_layout>4ZonesLayout2</zone_layout>\n  <zone id=\"id_4f6d946ab48d95799d31179c3acde8cb\">\n    <zone_identifier>top</zone_identifier>\n    <block id=\"id_39f4886bbe6d162c01ab77b65b96ba2a\">\n      <name>Qui sommes nous</name>\n      <zone_id>4f6d946ab48d95799d31179c3acde8cb</zone_id>\n      <type>NounoursEdito</type>\n      <custom_attributes>\n        <texte>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</texte>\n      </custom_attributes>\n      <view>nounoursedito</view>\n    </block>\n  </zone>\n  <zone id=\"id_a1117aa7fd4548568490cc7ab1271a4b\">\n    <zone_identifier>left</zone_identifier>\n    <block id=\"id_dc32434bab785565f942f4100be260f2\">\n      <name>Promotion1</name>\n      <zone_id>a1117aa7fd4548568490cc7ab1271a4b</zone_id>\n      <type>NounoursPromotion</type>\n      <view>promotion1</view>\n      <overflow_id></overflow_id>\n    </block>\n  </zone>\n  <zone id=\"id_038ffb3d0c9ba2a8dc1ecc6c3e6ea86d\">\n    <zone_identifier>right</zone_identifier>\n    <block id=\"id_5201665176b2455e198b34425ec20cc6\">\n      <name>Promotions2</name>\n      <zone_id>038ffb3d0c9ba2a8dc1ecc6c3e6ea86d</zone_id>\n      <type>NounoursPromotion</type>\n      <view>promotion2</view>\n      <overflow_id></overflow_id>\n    </block>\n  </zone>\n  <zone id=\"id_164b072e900f76653995211929541301\">\n    <zone_identifier>bottom</zone_identifier>\n    <block id=\"id_480655c28ee1aa2f14d76639cd774cfa\">\n      <name>O&#xF9; nous trouver</name>\n      <zone_id>164b072e900f76653995211929541301</zone_id>\n      <type>GMap</type>\n      <custom_attributes>\n        <location>1 avenue des champs elys&#xE9;e 75008 paris</location>\n        <key>ABQIAAAAvZi_9OkvCL5hib4G6mxXVRTrtyCTXr34X7fp3FZlYu_6f1uBkhSGMugIl0RSuNzb_Ur-xZ3JRijKGQ</key>\n      </custom_attributes>\n      <view>gmap</view>\n    </block>\n  </zone>\n</page>\n','ezpage',201,'fre-FR',3,0,'',9),
 (0,237,57,0,NULL,'<?xml version=\"1.0\"?>\n<page>\n  <zone_layout>4ZonesLayout2</zone_layout>\n  <zone id=\"id_4f6d946ab48d95799d31179c3acde8cb\">\n    <zone_identifier>top</zone_identifier>\n    <block id=\"id_39f4886bbe6d162c01ab77b65b96ba2a\">\n      <name>Qui sommes nous</name>\n      <zone_id>4f6d946ab48d95799d31179c3acde8cb</zone_id>\n      <type>NounoursEdito</type>\n      <custom_attributes>\n        <texte>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</texte>\n      </custom_attributes>\n      <view>nounoursedito</view>\n    </block>\n  </zone>\n  <zone id=\"id_a1117aa7fd4548568490cc7ab1271a4b\">\n    <zone_identifier>left</zone_identifier>\n    <block id=\"id_dc32434bab785565f942f4100be260f2\">\n      <name>Promotion1</name>\n      <zone_id>a1117aa7fd4548568490cc7ab1271a4b</zone_id>\n      <type>NounoursPromotion</type>\n      <view>promotion1</view>\n      <overflow_id></overflow_id>\n    </block>\n  </zone>\n  <zone id=\"id_038ffb3d0c9ba2a8dc1ecc6c3e6ea86d\">\n    <zone_identifier>right</zone_identifier>\n    <block id=\"id_5201665176b2455e198b34425ec20cc6\">\n      <name>Promotions2</name>\n      <zone_id>038ffb3d0c9ba2a8dc1ecc6c3e6ea86d</zone_id>\n      <type>NounoursPromotion</type>\n      <view>promotion2</view>\n      <overflow_id></overflow_id>\n    </block>\n  </zone>\n  <zone id=\"id_164b072e900f76653995211929541301\">\n    <zone_identifier>bottom</zone_identifier>\n    <block id=\"id_480655c28ee1aa2f14d76639cd774cfa\">\n      <name>O&#xF9; nous trouver</name>\n      <zone_id>164b072e900f76653995211929541301</zone_id>\n      <type>GMap</type>\n      <custom_attributes>\n        <location>1 avenue des champs elys&#xE9;e 75008 paris</location>\n        <key>ABQIAAAAvZi_9OkvCL5hib4G6mxXVRTrtyCTXr34X7fp3FZlYu_6f1uBkhSGMugIl0RSuNzb_Ur-xZ3JRijKGQ</key>\n      </custom_attributes>\n      <view>gmap</view>\n    </block>\n    <block id=\"id_fe0e338284df3f6c59a61dd474d2f228\">\n      <name>map</name>\n      <zone_id>164b072e900f76653995211929541301</zone_id>\n      <type>GMapItems</type>\n      <custom_attributes>\n        <class>geo_article</class>\n        <attribute>location</attribute>\n        <limit>10</limit>\n        <width>300</width>\n        <height>300</height>\n        <parent_node_id>2</parent_node_id>\n      </custom_attributes>\n      <view>geo_located_content</view>\n    </block>\n  </zone>\n</page>\n','ezpage',201,'fre-FR',3,0,'',10),
 (0,237,57,0,NULL,'<?xml version=\"1.0\"?>\n<page>\n  <zone_layout>4ZonesLayout2</zone_layout>\n  <zone id=\"id_4f6d946ab48d95799d31179c3acde8cb\">\n    <zone_identifier>top</zone_identifier>\n    <block id=\"id_39f4886bbe6d162c01ab77b65b96ba2a\">\n      <name>Qui sommes nous</name>\n      <zone_id>4f6d946ab48d95799d31179c3acde8cb</zone_id>\n      <type>NounoursEdito</type>\n      <custom_attributes>\n        <texte>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</texte>\n      </custom_attributes>\n      <view>nounoursedito</view>\n    </block>\n  </zone>\n  <zone id=\"id_a1117aa7fd4548568490cc7ab1271a4b\">\n    <zone_identifier>left</zone_identifier>\n    <block id=\"id_dc32434bab785565f942f4100be260f2\">\n      <name>Promotion1</name>\n      <zone_id>a1117aa7fd4548568490cc7ab1271a4b</zone_id>\n      <type>NounoursPromotion</type>\n      <view>promotion1</view>\n      <overflow_id></overflow_id>\n    </block>\n  </zone>\n  <zone id=\"id_038ffb3d0c9ba2a8dc1ecc6c3e6ea86d\">\n    <zone_identifier>right</zone_identifier>\n    <block id=\"id_5201665176b2455e198b34425ec20cc6\">\n      <name>Promotions2</name>\n      <zone_id>038ffb3d0c9ba2a8dc1ecc6c3e6ea86d</zone_id>\n      <type>NounoursPromotion</type>\n      <view>promotion2</view>\n      <overflow_id></overflow_id>\n    </block>\n  </zone>\n  <zone id=\"id_164b072e900f76653995211929541301\">\n    <zone_identifier>bottom</zone_identifier>\n    <block id=\"id_480655c28ee1aa2f14d76639cd774cfa\">\n      <name>O&#xF9; nous trouver</name>\n      <zone_id>164b072e900f76653995211929541301</zone_id>\n      <type>GMap</type>\n      <custom_attributes>\n        <location>1 avenue des champs elys&#xE9;e 75008 paris</location>\n        <key>ABQIAAAAvZi_9OkvCL5hib4G6mxXVRTrtyCTXr34X7fp3FZlYu_6f1uBkhSGMugIl0RSuNzb_Ur-xZ3JRijKGQ</key>\n      </custom_attributes>\n      <view>gmap</view>\n    </block>\n  </zone>\n</page>\n','ezpage',201,'fre-FR',3,0,'',11),
 (0,237,57,0,NULL,'<?xml version=\"1.0\"?>\n<page>\n  <zone_layout>4ZonesLayout2</zone_layout>\n  <zone id=\"id_4f6d946ab48d95799d31179c3acde8cb\">\n    <zone_identifier>top</zone_identifier>\n    <block id=\"id_39f4886bbe6d162c01ab77b65b96ba2a\">\n      <name>Qui sommes nous</name>\n      <zone_id>4f6d946ab48d95799d31179c3acde8cb</zone_id>\n      <type>NounoursEdito</type>\n      <custom_attributes>\n        <texte>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</texte>\n      </custom_attributes>\n      <view>nounoursedito</view>\n    </block>\n    <block id=\"id_21446f4f233f3d5ca6b9072d03c60a40\">\n      <name>Transparent</name>\n      <zone_id>4f6d946ab48d95799d31179c3acde8cb</zone_id>\n      <type>astTransparentBanner</type>\n      <view>version1</view>\n      <overflow_id></overflow_id>\n    </block>\n  </zone>\n  <zone id=\"id_a1117aa7fd4548568490cc7ab1271a4b\">\n    <zone_identifier>left</zone_identifier>\n    <block id=\"id_dc32434bab785565f942f4100be260f2\">\n      <name>Promotion1</name>\n      <zone_id>a1117aa7fd4548568490cc7ab1271a4b</zone_id>\n      <type>NounoursPromotion</type>\n      <view>promotion1</view>\n      <overflow_id></overflow_id>\n    </block>\n  </zone>\n  <zone id=\"id_038ffb3d0c9ba2a8dc1ecc6c3e6ea86d\">\n    <zone_identifier>right</zone_identifier>\n    <block id=\"id_5201665176b2455e198b34425ec20cc6\">\n      <name>Promotions2</name>\n      <zone_id>038ffb3d0c9ba2a8dc1ecc6c3e6ea86d</zone_id>\n      <type>NounoursPromotion</type>\n      <view>promotion2</view>\n      <overflow_id></overflow_id>\n    </block>\n  </zone>\n  <zone id=\"id_164b072e900f76653995211929541301\">\n    <zone_identifier>bottom</zone_identifier>\n    <block id=\"id_480655c28ee1aa2f14d76639cd774cfa\">\n      <name>O&#xF9; nous trouver</name>\n      <zone_id>164b072e900f76653995211929541301</zone_id>\n      <type>GMap</type>\n      <custom_attributes>\n        <location>1 avenue des champs elys&#xE9;e 75008 paris</location>\n        <key>ABQIAAAAvZi_9OkvCL5hib4G6mxXVRTrtyCTXr34X7fp3FZlYu_6f1uBkhSGMugIl0RSuNzb_Ur-xZ3JRijKGQ</key>\n      </custom_attributes>\n      <view>gmap</view>\n    </block>\n  </zone>\n</page>\n','ezpage',201,'fre-FR',3,0,'',12),
 (0,238,57,0,NULL,'','ezkeyword',202,'fre-FR',3,0,'',3),
 (0,238,57,0,NULL,'','ezkeyword',202,'fre-FR',3,0,'',4),
 (0,238,57,0,NULL,'','ezkeyword',202,'fre-FR',3,0,'',5),
 (0,238,57,0,NULL,'','ezkeyword',202,'fre-FR',3,0,'',6),
 (0,238,57,0,NULL,'','ezkeyword',202,'fre-FR',3,0,'',7),
 (0,238,57,0,NULL,'','ezkeyword',202,'fre-FR',3,0,'',8),
 (0,238,57,0,NULL,'','ezkeyword',202,'fre-FR',3,0,'',9),
 (0,238,57,0,NULL,'','ezkeyword',202,'fre-FR',3,0,'',10),
 (0,238,57,0,NULL,'','ezkeyword',202,'fre-FR',3,0,'',11),
 (0,238,57,0,NULL,'','ezkeyword',202,'fre-FR',3,0,'',12),
 (0,335,54,0,23,'Site map','ezurl',203,'fre-FR',2,0,'',2),
 (0,336,54,0,24,'Tag cloud','ezurl',204,'fre-FR',2,0,'',2),
 (0,337,54,0,NULL,'Login','ezstring',205,'fre-FR',2,0,'login',2),
 (0,338,54,0,NULL,'Logout','ezstring',206,'fre-FR',2,0,'logout',2),
 (0,339,54,0,NULL,'My profile','ezstring',207,'fre-FR',2,0,'my profile',2),
 (0,340,54,0,NULL,'Register','ezstring',208,'fre-FR',2,0,'register',2),
 (0,341,54,0,NULL,'/rss/feed/my_feed','ezstring',209,'fre-FR',2,0,'/rss/feed/my_feed',2),
 (0,342,54,0,NULL,'Shopping basket','ezstring',210,'fre-FR',2,0,'shopping basket',2),
 (0,343,54,0,NULL,'Site settings','ezstring',211,'fre-FR',2,0,'site settings',2),
 (0,344,54,0,NULL,'Copyright &#169; 2011 <a href=\"http://ez.no\" title=\"eZ Systems\">eZ Systems AS</a> (except where otherwise noted). All rights reserved.','eztext',212,'fre-FR',2,0,'',2),
 (0,345,54,0,0,'','ezboolean',213,'fre-FR',2,0,'',2),
 (0,346,54,0,NULL,'','eztext',214,'fre-FR',2,0,'',2),
 (0,6,58,0,NULL,'Partners','ezstring',215,'fre-FR',3,0,'partners',1),
 (0,7,58,0,NULL,'','ezstring',216,'fre-FR',3,0,'',1),
 (0,359,59,0,NULL,'Peluches','ezstring',217,'fre-FR',3,0,'peluches',1),
 (0,360,59,0,NULL,'','ezstring',218,'fre-FR',3,0,'',1),
 (0,361,59,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"/>\n','ezxmltext',219,'fre-FR',3,0,'',1),
 (0,362,59,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"/>\n','ezxmltext',220,'fre-FR',3,0,'',1),
 (221,363,59,0,1,'','ezboolean',221,'fre-FR',3,1,'',1),
 (0,364,59,0,NULL,'','ezkeyword',222,'fre-FR',3,0,'',1),
 (0,365,59,0,0,'','ezdatetime',223,'fre-FR',3,0,'',1),
 (0,347,61,0,NULL,'Mentions légales','ezstring',231,'fre-FR',2,0,'mentions légales',1),
 (0,348,61,0,NULL,'','ezstring',232,'fre-FR',2,0,'',1),
 (0,349,61,0,NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<ezauthor><authors><author id=\"0\" name=\"Administrator User\" email=\"admin@nounours.local\"/></authors></ezauthor>\n','ezauthor',233,'fre-FR',2,0,'',1),
 (0,350,61,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"><paragraph>c</paragraph></section>\n','ezxmltext',234,'fre-FR',2,0,'',1),
 (0,351,61,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"/>\n','ezxmltext',235,'fre-FR',2,0,'',1),
 (0,352,61,0,0,'','ezboolean',236,'fre-FR',2,0,'',1),
 (0,353,61,0,NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<ezimage serial_number=\"1\" is_valid=\"\" filename=\"\" suffix=\"\" basename=\"\" dirpath=\"\" url=\"\" original_filename=\"\" mime_type=\"\" width=\"\" height=\"\" alternative_text=\"\" alias_key=\"1293033771\" timestamp=\"1305867278\"><original attribute_id=\"237\" attribute_version=\"1\" attribute_language=\"fre-FR\"/></ezimage>\n','ezimage',237,'fre-FR',2,0,'',1),
 (0,354,61,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"/>\n','ezxmltext',238,'fre-FR',2,0,'',1),
 (0,355,61,0,0,'','ezdatetime',239,'fre-FR',2,0,'',1),
 (0,356,61,0,0,'','ezdatetime',240,'fre-FR',2,0,'',1),
 (0,357,61,0,NULL,'','ezkeyword',241,'fre-FR',2,0,'',1),
 (0,358,61,0,1,'','ezsrrating',242,'fre-FR',2,0,'',1),
 (0,359,62,0,NULL,'Poupées','ezstring',243,'fre-FR',3,0,'poupées',1),
 (0,360,62,0,NULL,'','ezstring',244,'fre-FR',3,0,'',1),
 (0,361,62,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"/>\n','ezxmltext',245,'fre-FR',3,0,'',1),
 (0,362,62,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"/>\n','ezxmltext',246,'fre-FR',3,0,'',1),
 (247,363,62,0,1,'','ezboolean',247,'fre-FR',3,1,'',1),
 (0,364,62,0,NULL,'','ezkeyword',248,'fre-FR',3,0,'',1),
 (0,365,62,0,0,'','ezdatetime',249,'fre-FR',3,0,'',1),
 (0,347,63,0,NULL,'La société','ezstring',250,'fre-FR',2,0,'la société',1),
 (0,348,63,0,NULL,'','ezstring',251,'fre-FR',2,0,'',1),
 (0,349,63,0,NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<ezauthor><authors><author id=\"0\" name=\"Administrator User\" email=\"admin@nounours.local\"/></authors></ezauthor>\n','ezauthor',252,'fre-FR',2,0,'',1),
 (0,350,63,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"><paragraph>c</paragraph></section>\n','ezxmltext',253,'fre-FR',2,0,'',1),
 (0,351,63,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"/>\n','ezxmltext',254,'fre-FR',2,0,'',1),
 (0,352,63,0,0,'','ezboolean',255,'fre-FR',2,0,'',1),
 (0,353,63,0,NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<ezimage serial_number=\"1\" is_valid=\"\" filename=\"\" suffix=\"\" basename=\"\" dirpath=\"\" url=\"\" original_filename=\"\" mime_type=\"\" width=\"\" height=\"\" alternative_text=\"\" alias_key=\"1293033771\" timestamp=\"1305867372\"><original attribute_id=\"256\" attribute_version=\"1\" attribute_language=\"fre-FR\"/></ezimage>\n','ezimage',256,'fre-FR',2,0,'',1),
 (0,354,63,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"/>\n','ezxmltext',257,'fre-FR',2,0,'',1),
 (0,355,63,0,0,'','ezdatetime',258,'fre-FR',2,0,'',1),
 (0,356,63,0,0,'','ezdatetime',259,'fre-FR',2,0,'',1),
 (0,357,63,0,NULL,'','ezkeyword',260,'fre-FR',2,0,'',1),
 (0,358,63,0,1,'','ezsrrating',261,'fre-FR',2,0,'',1),
 (0,220,64,0,NULL,'La peluche Mickey mouse','ezstring',262,'fre-FR',2,0,'la peluche mickey mouse',1),
 (0,220,64,0,NULL,'La peluche Mickey Mouse','ezstring',262,'fre-FR',2,0,'la peluche mickey mouse',2),
 (0,221,64,0,NULL,'','ezstring',263,'fre-FR',2,0,'',1),
 (0,221,64,0,NULL,'','ezstring',263,'fre-FR',2,0,'',2),
 (0,222,64,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"/>\n','ezxmltext',264,'fre-FR',2,0,'',1),
 (0,222,64,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"/>\n','ezxmltext',264,'fre-FR',2,0,'',2),
 (0,223,64,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"/>\n','ezxmltext',265,'fre-FR',2,0,'',1),
 (0,223,64,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"/>\n','ezxmltext',265,'fre-FR',2,0,'',2),
 (0,224,64,0,NULL,'1,1','ezprice',266,'fre-FR',2,0,'',1),
 (0,224,64,0,NULL,'1,1','ezprice',266,'fre-FR',2,0,'',2),
 (0,225,64,0,NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<ezimage serial_number=\"1\" is_valid=\"\" filename=\"\" suffix=\"\" basename=\"\" dirpath=\"\" url=\"\" original_filename=\"\" mime_type=\"\" width=\"\" height=\"\" alternative_text=\"\" alias_key=\"1293033771\" timestamp=\"1305867437\"><original attribute_id=\"267\" attribute_version=\"1\" attribute_language=\"fre-FR\"/></ezimage>\n','ezimage',267,'fre-FR',2,0,'',1),
 (0,225,64,0,NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<ezimage serial_number=\"1\" is_valid=\"\" filename=\"\" suffix=\"\" basename=\"\" dirpath=\"\" url=\"\" original_filename=\"\" mime_type=\"\" width=\"\" height=\"\" alternative_text=\"\" alias_key=\"1293033771\" timestamp=\"1305867437\"><original attribute_id=\"267\" attribute_version=\"1\" attribute_language=\"fre-FR\"/></ezimage>\n','ezimage',267,'fre-FR',2,0,'',2),
 (0,226,64,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"/>\n','ezxmltext',268,'fre-FR',2,0,'',1),
 (0,226,64,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"/>\n','ezxmltext',268,'fre-FR',2,0,'',2),
 (0,227,64,0,NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<ezmultioption option_counter=\"0\"><name></name><multioptions/></ezmultioption>\n','ezmultioption',269,'fre-FR',2,0,'',1),
 (0,227,64,0,NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<ezmultioption option_counter=\"0\"><name></name><multioptions/></ezmultioption>\n','ezmultioption',269,'fre-FR',2,0,'',2),
 (0,228,64,0,NULL,'','ezkeyword',270,'fre-FR',2,0,'',1),
 (0,228,64,0,NULL,'','ezkeyword',270,'fre-FR',2,0,'',2),
 (0,220,65,0,NULL,'La peluche Minnie Mouse','ezstring',271,'fre-FR',2,0,'la peluche minnie mouse',1),
 (0,221,65,0,NULL,'','ezstring',272,'fre-FR',2,0,'',1),
 (0,222,65,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"/>\n','ezxmltext',273,'fre-FR',2,0,'',1),
 (0,223,65,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"/>\n','ezxmltext',274,'fre-FR',2,0,'',1),
 (0,224,65,0,NULL,'1,1','ezprice',275,'fre-FR',2,0,'',1),
 (0,225,65,0,NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<ezimage serial_number=\"1\" is_valid=\"\" filename=\"\" suffix=\"\" basename=\"\" dirpath=\"\" url=\"\" original_filename=\"\" mime_type=\"\" width=\"\" height=\"\" alternative_text=\"\" alias_key=\"1293033771\" timestamp=\"1305867470\"><original attribute_id=\"276\" attribute_version=\"1\" attribute_language=\"fre-FR\"/></ezimage>\n','ezimage',276,'fre-FR',2,0,'',1),
 (0,226,65,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"/>\n','ezxmltext',277,'fre-FR',2,0,'',1),
 (0,227,65,0,NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<ezmultioption option_counter=\"0\"><name></name><multioptions/></ezmultioption>\n','ezmultioption',278,'fre-FR',2,0,'',1),
 (0,228,65,0,NULL,'','ezkeyword',279,'fre-FR',2,0,'',1),
 (0,220,66,0,NULL,'La peluche Donald Duck','ezstring',280,'fre-FR',2,0,'la peluche donald duck',1),
 (0,220,66,0,NULL,'La peluche Donald Duck','ezstring',280,'fre-FR',2,0,'la peluche donald duck',2),
 (0,221,66,0,NULL,'','ezstring',281,'fre-FR',2,0,'',1),
 (0,221,66,0,NULL,'','ezstring',281,'fre-FR',2,0,'',2),
 (0,222,66,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"/>\n','ezxmltext',282,'fre-FR',2,0,'',1),
 (0,222,66,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"><paragraph>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many</paragraph></section>\n','ezxmltext',282,'fre-FR',2,0,'',2),
 (0,223,66,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"/>\n','ezxmltext',283,'fre-FR',2,0,'',1),
 (0,223,66,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"><paragraph>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. ManyIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. ManyIt is a long established fact that a reader will be distracted</paragraph><paragraph>by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. ManyIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many</paragraph></section>\n','ezxmltext',283,'fre-FR',2,0,'',2),
 (0,224,66,0,NULL,'1,1','ezprice',284,'fre-FR',2,0,'',1),
 (0,224,66,0,NULL,'1,2','ezprice',284,'fre-FR',2,0,'',2),
 (0,225,66,0,NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<ezimage serial_number=\"1\" is_valid=\"\" filename=\"\" suffix=\"\" basename=\"\" dirpath=\"\" url=\"\" original_filename=\"\" mime_type=\"\" width=\"\" height=\"\" alternative_text=\"\" alias_key=\"1293033771\" timestamp=\"1305867516\"><original attribute_id=\"285\" attribute_version=\"1\" attribute_language=\"fre-FR\"/></ezimage>\n','ezimage',285,'fre-FR',2,0,'',1),
 (0,225,66,0,NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<ezimage serial_number=\"1\" is_valid=\"1\" filename=\"La-peluche-Donald-Duck.jpg\" suffix=\"jpg\" basename=\"La-peluche-Donald-Duck\" dirpath=\"var/ezflow_site/storage/images/peluches/la-peluche-donald-duck/285-2-fre-FR\" url=\"var/ezflow_site/storage/images/peluches/la-peluche-donald-duck/285-2-fre-FR/La-peluche-Donald-Duck.jpg\" original_filename=\"donald-duck1.jpg\" mime_type=\"image/jpeg\" width=\"220\" height=\"220\" alternative_text=\"\" alias_key=\"1293033771\" timestamp=\"1305979909\"><original attribute_id=\"285\" attribute_version=\"2\" attribute_language=\"fre-FR\"/><alias name=\"medium\" filename=\"La-peluche-Donald-Duck_medium.jpg\" suffix=\"jpg\" dirpath=\"var/ezflow_site/storage/images/peluches/la-peluche-donald-duck/285-2-fre-FR\" url=\"var/ezflow_site/storage/images/peluches/la-peluche-donald-duck/285-2-fre-FR/La-peluche-Donald-Duck_medium.jpg\" mime_type=\"image/jpeg\" width=\"200\" height=\"200\" alias_key=\"3736024005\" timestamp=\"1305979913\" is_valid=\"1\"/><alias name=\"small\" filename=\"La-peluche-Donald-Duck_small.jpg\" suffix=\"jpg\" dirpath=\"var/ezflow_site/storage/images/peluches/la-peluche-donald-duck/285-2-fre-FR\" url=\"var/ezflow_site/storage/images/peluches/la-peluche-donald-duck/285-2-fre-FR/La-peluche-Donald-Duck_small.jpg\" mime_type=\"image/jpeg\" width=\"100\" height=\"100\" alias_key=\"18164146\" timestamp=\"1305979927\" is_valid=\"1\"/></ezimage>\n','ezimage',285,'fre-FR',2,0,'',2),
 (0,226,66,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"/>\n','ezxmltext',286,'fre-FR',2,0,'',1),
 (0,226,66,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"/>\n','ezxmltext',286,'fre-FR',2,0,'',2),
 (0,227,66,0,NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<ezmultioption option_counter=\"0\"><name></name><multioptions/></ezmultioption>\n','ezmultioption',287,'fre-FR',2,0,'',1),
 (0,227,66,0,NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<ezmultioption option_counter=\"0\"><name></name><multioptions/></ezmultioption>\n','ezmultioption',287,'fre-FR',2,0,'',2),
 (0,228,66,0,NULL,'','ezkeyword',288,'fre-FR',2,0,'',1),
 (0,228,66,0,NULL,'','ezkeyword',288,'fre-FR',2,0,'',2),
 (0,220,67,0,NULL,'Mélanie','ezstring',289,'fre-FR',2,0,'mélanie',1),
 (0,221,67,0,NULL,'','ezstring',290,'fre-FR',2,0,'',1),
 (0,222,67,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"/>\n','ezxmltext',291,'fre-FR',2,0,'',1),
 (0,223,67,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"/>\n','ezxmltext',292,'fre-FR',2,0,'',1),
 (0,224,67,0,NULL,'1,1','ezprice',293,'fre-FR',2,0,'',1),
 (0,225,67,0,NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<ezimage serial_number=\"1\" is_valid=\"\" filename=\"\" suffix=\"\" basename=\"\" dirpath=\"\" url=\"\" original_filename=\"\" mime_type=\"\" width=\"\" height=\"\" alternative_text=\"\" alias_key=\"1293033771\" timestamp=\"1305867683\"><original attribute_id=\"294\" attribute_version=\"1\" attribute_language=\"fre-FR\"/></ezimage>\n','ezimage',294,'fre-FR',2,0,'',1),
 (0,226,67,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"/>\n','ezxmltext',295,'fre-FR',2,0,'',1),
 (0,227,67,0,NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<ezmultioption option_counter=\"0\"><name></name><multioptions/></ezmultioption>\n','ezmultioption',296,'fre-FR',2,0,'',1),
 (0,228,67,0,NULL,'','ezkeyword',297,'fre-FR',2,0,'',1),
 (0,220,68,0,NULL,'Arthur','ezstring',298,'fre-FR',2,0,'arthur',1),
 (0,221,68,0,NULL,'','ezstring',299,'fre-FR',2,0,'',1),
 (0,222,68,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"/>\n','ezxmltext',300,'fre-FR',2,0,'',1),
 (0,223,68,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"/>\n','ezxmltext',301,'fre-FR',2,0,'',1),
 (0,224,68,0,NULL,'1,1','ezprice',302,'fre-FR',2,0,'',1),
 (0,225,68,0,NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<ezimage serial_number=\"1\" is_valid=\"\" filename=\"\" suffix=\"\" basename=\"\" dirpath=\"\" url=\"\" original_filename=\"\" mime_type=\"\" width=\"\" height=\"\" alternative_text=\"\" alias_key=\"1293033771\" timestamp=\"1305867725\"><original attribute_id=\"303\" attribute_version=\"1\" attribute_language=\"fre-FR\"/></ezimage>\n','ezimage',303,'fre-FR',2,0,'',1),
 (0,226,68,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"/>\n','ezxmltext',304,'fre-FR',2,0,'',1),
 (0,227,68,0,NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<ezmultioption option_counter=\"0\"><name></name><multioptions/></ezmultioption>\n','ezmultioption',305,'fre-FR',2,0,'',1),
 (0,228,68,0,NULL,'','ezkeyword',306,'fre-FR',2,0,'',1),
 (0,296,70,0,NULL,'Test google analytics v3','ezstring',319,'fre-FR',2,0,'test google analytics v3',1),
 (0,297,70,0,NULL,'','ezstring',320,'fre-FR',2,0,'',1),
 (0,298,70,0,NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<ezauthor><authors><author id=\"0\" name=\"Administrator User\" email=\"admin@nounours.local\"/></authors></ezauthor>\n','ezauthor',321,'fre-FR',2,0,'',1),
 (0,299,70,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"><paragraph>qsdfqsdfqsdf qsdfqsdfqsd</paragraph></section>\n','ezxmltext',322,'fre-FR',2,0,'',1),
 (0,300,70,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"/>\n','ezxmltext',323,'fre-FR',2,0,'',1),
 (0,301,70,0,0,'','ezboolean',324,'fre-FR',2,0,'',1),
 (0,302,70,0,NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<ezimage serial_number=\"1\" is_valid=\"\" filename=\"\" suffix=\"\" basename=\"\" dirpath=\"\" url=\"\" original_filename=\"\" mime_type=\"\" width=\"\" height=\"\" alternative_text=\"\" alias_key=\"1293033771\" timestamp=\"1306043632\"><original attribute_id=\"325\" attribute_version=\"1\" attribute_language=\"fre-FR\"/></ezimage>\n','ezimage',325,'fre-FR',2,0,'',1),
 (0,303,70,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"/>\n','ezxmltext',326,'fre-FR',2,0,'',1),
 (0,304,70,0,0,'','ezdatetime',327,'fre-FR',2,0,'',1),
 (0,305,70,0,0,'','ezdatetime',328,'fre-FR',2,0,'',1),
 (0,306,70,0,NULL,'','ezkeyword',329,'fre-FR',2,0,'',1),
 (0,307,70,0,1,'','ezgmaplocation',330,'fre-FR',2,0,'1 rue de belleville paris',1),
 (0,296,71,0,NULL,'Champs elysées','ezstring',331,'fre-FR',2,0,'champs elysées',1),
 (0,297,71,0,NULL,'','ezstring',332,'fre-FR',2,0,'',1),
 (0,298,71,0,NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<ezauthor><authors><author id=\"0\" name=\"Administrator User\" email=\"admin@nounours.local\"/></authors></ezauthor>\n','ezauthor',333,'fre-FR',2,0,'',1),
 (0,299,71,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"><paragraph>qsdfqs qsdf qsdfqsdf qsdf qsdf</paragraph></section>\n','ezxmltext',334,'fre-FR',2,0,'',1),
 (0,300,71,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"/>\n','ezxmltext',335,'fre-FR',2,0,'',1),
 (0,301,71,0,0,'','ezboolean',336,'fre-FR',2,0,'',1),
 (0,302,71,0,NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<ezimage serial_number=\"1\" is_valid=\"\" filename=\"\" suffix=\"\" basename=\"\" dirpath=\"\" url=\"\" original_filename=\"\" mime_type=\"\" width=\"\" height=\"\" alternative_text=\"\" alias_key=\"1293033771\" timestamp=\"1306053682\"><original attribute_id=\"337\" attribute_version=\"1\" attribute_language=\"fre-FR\"/></ezimage>\n','ezimage',337,'fre-FR',2,0,'',1),
 (0,303,71,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"/>\n','ezxmltext',338,'fre-FR',2,0,'',1),
 (0,304,71,0,0,'','ezdatetime',339,'fre-FR',2,0,'',1),
 (0,305,71,0,0,'','ezdatetime',340,'fre-FR',2,0,'',1),
 (0,306,71,0,NULL,'','ezkeyword',341,'fre-FR',2,0,'',1),
 (0,307,71,0,1,'','ezgmaplocation',342,'fre-FR',2,0,'1, avenue des champs elys&eacute;es 75008 ,paris',1),
 (0,296,73,0,NULL,'New article','ezstring',355,'fre-FR',2,0,'new article',1),
 (0,296,73,0,NULL,'New article','ezstring',355,'fre-FR',2,0,'new article',2),
 (0,296,73,0,NULL,'New article','ezstring',355,'fre-FR',2,0,'new article',3),
 (0,296,73,0,NULL,'New article','ezstring',355,'fre-FR',2,0,'new article',4),
 (0,296,73,0,NULL,'New article','ezstring',355,'fre-FR',2,0,'new article',5),
 (0,297,73,0,NULL,'','ezstring',356,'fre-FR',2,0,'',1),
 (0,297,73,0,NULL,'','ezstring',356,'fre-FR',2,0,'',2),
 (0,297,73,0,NULL,'','ezstring',356,'fre-FR',2,0,'',3),
 (0,297,73,0,NULL,'','ezstring',356,'fre-FR',2,0,'',4),
 (0,297,73,0,NULL,'','ezstring',356,'fre-FR',2,0,'',5),
 (0,298,73,0,NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<ezauthor><authors><author id=\"0\" name=\"Administrator User\" email=\"admin@nounours.local\"/></authors></ezauthor>\n','ezauthor',357,'fre-FR',2,0,'',1),
 (0,298,73,0,NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<ezauthor><authors><author id=\"0\" name=\"Administrator User\" email=\"admin@nounours.local\"/></authors></ezauthor>\n','ezauthor',357,'fre-FR',2,0,'',2),
 (0,298,73,0,NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<ezauthor><authors><author id=\"0\" name=\"Administrator User\" email=\"admin@nounours.local\"/></authors></ezauthor>\n','ezauthor',357,'fre-FR',2,0,'',3),
 (0,298,73,0,NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<ezauthor><authors><author id=\"0\" name=\"Administrator User\" email=\"admin@nounours.local\"/></authors></ezauthor>\n','ezauthor',357,'fre-FR',2,0,'',4),
 (0,298,73,0,NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<ezauthor><authors><author id=\"0\" name=\"Administrator User\" email=\"admin@nounours.local\"/></authors></ezauthor>\n','ezauthor',357,'fre-FR',2,0,'',5),
 (0,299,73,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"><paragraph>test</paragraph></section>\n','ezxmltext',358,'fre-FR',2,0,'',1),
 (0,299,73,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"><paragraph>test</paragraph></section>\n','ezxmltext',358,'fre-FR',2,0,'',2),
 (0,299,73,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"><paragraph>test</paragraph></section>\n','ezxmltext',358,'fre-FR',2,0,'',3),
 (0,299,73,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"><paragraph>test</paragraph></section>\n','ezxmltext',358,'fre-FR',2,0,'',4),
 (0,299,73,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"><paragraph>test</paragraph></section>\n','ezxmltext',358,'fre-FR',2,0,'',5),
 (0,300,73,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"/>\n','ezxmltext',359,'fre-FR',2,0,'',1),
 (0,300,73,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"/>\n','ezxmltext',359,'fre-FR',2,0,'',2),
 (0,300,73,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"/>\n','ezxmltext',359,'fre-FR',2,0,'',3),
 (0,300,73,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"/>\n','ezxmltext',359,'fre-FR',2,0,'',4),
 (0,300,73,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"/>\n','ezxmltext',359,'fre-FR',2,0,'',5),
 (0,301,73,0,0,'','ezboolean',360,'fre-FR',2,0,'',1),
 (0,301,73,0,0,'','ezboolean',360,'fre-FR',2,0,'',2),
 (0,301,73,0,0,'','ezboolean',360,'fre-FR',2,0,'',3),
 (0,301,73,0,0,'','ezboolean',360,'fre-FR',2,0,'',4),
 (0,301,73,0,0,'','ezboolean',360,'fre-FR',2,0,'',5),
 (0,302,73,0,NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<ezimage serial_number=\"1\" is_valid=\"\" filename=\"\" suffix=\"\" basename=\"\" dirpath=\"\" url=\"\" original_filename=\"\" mime_type=\"\" width=\"\" height=\"\" alternative_text=\"\" alias_key=\"1293033771\" timestamp=\"1306066036\"><original attribute_id=\"361\" attribute_version=\"1\" attribute_language=\"fre-FR\"/></ezimage>\n','ezimage',361,'fre-FR',2,0,'',1),
 (0,302,73,0,NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<ezimage serial_number=\"1\" is_valid=\"\" filename=\"\" suffix=\"\" basename=\"\" dirpath=\"\" url=\"\" original_filename=\"\" mime_type=\"\" width=\"\" height=\"\" alternative_text=\"\" alias_key=\"1293033771\" timestamp=\"1306066036\"><original attribute_id=\"361\" attribute_version=\"1\" attribute_language=\"fre-FR\"/></ezimage>\n','ezimage',361,'fre-FR',2,0,'',2),
 (0,302,73,0,NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<ezimage serial_number=\"1\" is_valid=\"\" filename=\"\" suffix=\"\" basename=\"\" dirpath=\"\" url=\"\" original_filename=\"\" mime_type=\"\" width=\"\" height=\"\" alternative_text=\"\" alias_key=\"1293033771\" timestamp=\"1306066036\"><original attribute_id=\"361\" attribute_version=\"1\" attribute_language=\"fre-FR\"/></ezimage>\n','ezimage',361,'fre-FR',2,0,'',3);
INSERT INTO `ezcontentobject_attribute` (`attribute_original_id`,`contentclassattribute_id`,`contentobject_id`,`data_float`,`data_int`,`data_text`,`data_type_string`,`id`,`language_code`,`language_id`,`sort_key_int`,`sort_key_string`,`version`) VALUES 
 (0,302,73,0,NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<ezimage serial_number=\"1\" is_valid=\"\" filename=\"\" suffix=\"\" basename=\"\" dirpath=\"\" url=\"\" original_filename=\"\" mime_type=\"\" width=\"\" height=\"\" alternative_text=\"\" alias_key=\"1293033771\" timestamp=\"1306066036\"><original attribute_id=\"361\" attribute_version=\"1\" attribute_language=\"fre-FR\"/></ezimage>\n','ezimage',361,'fre-FR',2,0,'',4),
 (0,302,73,0,NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<ezimage serial_number=\"1\" is_valid=\"\" filename=\"\" suffix=\"\" basename=\"\" dirpath=\"\" url=\"\" original_filename=\"\" mime_type=\"\" width=\"\" height=\"\" alternative_text=\"\" alias_key=\"1293033771\" timestamp=\"1306066036\"><original attribute_id=\"361\" attribute_version=\"1\" attribute_language=\"fre-FR\"/></ezimage>\n','ezimage',361,'fre-FR',2,0,'',5),
 (0,303,73,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"/>\n','ezxmltext',362,'fre-FR',2,0,'',1),
 (0,303,73,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"/>\n','ezxmltext',362,'fre-FR',2,0,'',2),
 (0,303,73,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"/>\n','ezxmltext',362,'fre-FR',2,0,'',3),
 (0,303,73,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"/>\n','ezxmltext',362,'fre-FR',2,0,'',4),
 (0,303,73,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"/>\n','ezxmltext',362,'fre-FR',2,0,'',5),
 (0,304,73,0,0,'','ezdatetime',363,'fre-FR',2,0,'',1),
 (0,304,73,0,0,'','ezdatetime',363,'fre-FR',2,0,'',2),
 (0,304,73,0,0,'','ezdatetime',363,'fre-FR',2,0,'',3),
 (0,304,73,0,0,'','ezdatetime',363,'fre-FR',2,0,'',4),
 (0,304,73,0,0,'','ezdatetime',363,'fre-FR',2,0,'',5),
 (0,305,73,0,0,'','ezdatetime',364,'fre-FR',2,0,'',1),
 (0,305,73,0,0,'','ezdatetime',364,'fre-FR',2,0,'',2),
 (0,305,73,0,0,'','ezdatetime',364,'fre-FR',2,0,'',3),
 (0,305,73,0,0,'','ezdatetime',364,'fre-FR',2,0,'',4),
 (0,305,73,0,0,'','ezdatetime',364,'fre-FR',2,0,'',5),
 (0,306,73,0,NULL,'','ezkeyword',365,'fre-FR',2,0,'',1),
 (0,306,73,0,NULL,'','ezkeyword',365,'fre-FR',2,0,'',2),
 (0,306,73,0,NULL,'','ezkeyword',365,'fre-FR',2,0,'',3),
 (0,306,73,0,NULL,'','ezkeyword',365,'fre-FR',2,0,'',4),
 (0,306,73,0,NULL,'','ezkeyword',365,'fre-FR',2,0,'',5),
 (0,307,73,0,0,'','ezgmaplocation',366,'fre-FR',2,0,'',1),
 (0,307,73,0,0,'','ezgmaplocation',366,'fre-FR',2,0,'',2),
 (0,307,73,0,1,'','ezgmaplocation',366,'fre-FR',2,0,'Londres',3),
 (0,307,73,0,1,'','ezgmaplocation',366,'fre-FR',2,0,'',4),
 (0,307,73,0,1,'','ezgmaplocation',366,'fre-FR',2,0,'',5),
 (0,258,74,0,NULL,'Banniere transparente','ezstring',367,'fre-FR',2,0,'banniere transparente',1),
 (0,258,74,0,NULL,'Banniere transparente','ezstring',367,'fre-FR',2,0,'banniere transparente',2),
 (0,259,74,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"/>\n','ezxmltext',368,'fre-FR',2,0,'',1),
 (0,259,74,0,1045487555,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<section xmlns:image=\"http://ez.no/namespaces/ezpublish3/image/\" xmlns:xhtml=\"http://ez.no/namespaces/ezpublish3/xhtml/\" xmlns:custom=\"http://ez.no/namespaces/ezpublish3/custom/\"/>\n','ezxmltext',368,'fre-FR',2,0,'',2),
 (0,260,74,0,NULL,'','ezmedia',369,'fre-FR',2,0,'',1),
 (0,260,74,0,NULL,'','ezmedia',369,'fre-FR',2,0,'',2),
 (0,261,74,0,NULL,'','ezkeyword',370,'fre-FR',2,0,'',1),
 (0,261,74,0,NULL,'','ezkeyword',370,'fre-FR',2,0,'',2);
/*!40000 ALTER TABLE `ezcontentobject_attribute` ENABLE KEYS */;


--
-- Dumping data for table `ezcontentobject_link`
--

/*!40000 ALTER TABLE `ezcontentobject_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezcontentobject_link` ENABLE KEYS */;


--
-- Dumping data for table `ezcontentobject_name`
--

/*!40000 ALTER TABLE `ezcontentobject_name` DISABLE KEYS */;
INSERT INTO `ezcontentobject_name` (`content_translation`,`content_version`,`contentobject_id`,`language_id`,`name`,`real_translation`) VALUES 
 ('fre-FR',1,4,3,'Users','fre-FR'),
 ('fre-FR',2,10,3,'Anonymous User','fre-FR'),
 ('fre-FR',1,11,3,'Guest accounts','fre-FR'),
 ('fre-FR',2,11,3,'Members','fre-FR'),
 ('fre-FR',1,12,3,'Administrator users','fre-FR'),
 ('fre-FR',1,13,3,'Editors','fre-FR'),
 ('fre-FR',3,14,3,'Administrator User','fre-FR'),
 ('fre-FR',4,14,3,'Administrator User','fre-FR'),
 ('fre-FR',1,41,3,'Media','fre-FR'),
 ('fre-FR',1,42,3,'Anonymous Users','fre-FR'),
 ('fre-FR',1,45,3,'Setup','fre-FR'),
 ('fre-FR',1,49,3,'Images','fre-FR'),
 ('fre-FR',1,50,3,'Files','fre-FR'),
 ('fre-FR',1,51,3,'Multimedia','fre-FR'),
 ('fre-FR',1,52,2,'Common INI settings','fre-FR'),
 ('fre-FR',2,54,2,'Nounours','fre-FR'),
 ('fre-FR',1,56,3,'Design','fre-FR'),
 ('fre-FR',3,57,3,'Home','fre-FR'),
 ('fre-FR',4,57,3,'Home','fre-FR'),
 ('fre-FR',5,57,3,'Home','fre-FR'),
 ('fre-FR',6,57,3,'Home','fre-FR'),
 ('fre-FR',7,57,3,'Home','fre-FR'),
 ('fre-FR',8,57,3,'Home','fre-FR'),
 ('fre-FR',9,57,3,'Home','fre-FR'),
 ('fre-FR',10,57,3,'Home','fre-FR'),
 ('fre-FR',11,57,3,'Home','fre-FR'),
 ('fre-FR',12,57,3,'Home','fre-FR'),
 ('fre-FR',1,58,3,'Partners','fre-FR'),
 ('fre-FR',1,59,3,'Peluches','fre-FR'),
 ('fre-FR',1,61,2,'Mentions légales','fre-FR'),
 ('fre-FR',1,62,3,'Poupées','fre-FR'),
 ('fre-FR',1,63,2,'La société','fre-FR'),
 ('fre-FR',1,64,2,'La peluche Mickey mouse','fre-FR'),
 ('fre-FR',2,64,2,'La peluche Mickey Mouse','fre-FR'),
 ('fre-FR',1,65,2,'La peluche Minnie Mouse','fre-FR'),
 ('fre-FR',1,66,2,'La peluche Donald Duck','fre-FR'),
 ('fre-FR',2,66,2,'La peluche Donald Duck','fre-FR'),
 ('fre-FR',1,67,2,'Mélanie','fre-FR'),
 ('fre-FR',1,68,2,'Arthur','fre-FR'),
 ('fre-FR',1,70,2,'Test google analytics v3','fre-FR'),
 ('fre-FR',1,71,2,'Champs elysées','fre-FR'),
 ('fre-FR',1,73,2,'New article','fre-FR'),
 ('fre-FR',2,73,2,'New article','fre-FR'),
 ('fre-FR',3,73,2,'New article','fre-FR'),
 ('fre-FR',4,73,2,'New article','fre-FR'),
 ('fre-FR',5,73,2,'New article','fre-FR'),
 ('fre-FR',1,74,2,'Banniere transparente','fre-FR'),
 ('fre-FR',2,74,2,'Banniere transparente','fre-FR');
/*!40000 ALTER TABLE `ezcontentobject_name` ENABLE KEYS */;


--
-- Dumping data for table `ezcontentobject_trash`
--

/*!40000 ALTER TABLE `ezcontentobject_trash` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezcontentobject_trash` ENABLE KEYS */;


--
-- Dumping data for table `ezcontentobject_tree`
--

/*!40000 ALTER TABLE `ezcontentobject_tree` DISABLE KEYS */;
INSERT INTO `ezcontentobject_tree` (`contentobject_id`,`contentobject_is_published`,`contentobject_version`,`depth`,`is_hidden`,`is_invisible`,`main_node_id`,`modified_subnode`,`node_id`,`parent_node_id`,`path_identification_string`,`path_string`,`priority`,`remote_id`,`sort_field`,`sort_order`) VALUES 
 (0,1,1,0,0,0,1,1307017812,1,1,'','/1/',0,'629709ba256fe317c3ddcee35453a96a',1,1),
 (57,1,12,1,0,0,2,1307017812,2,1,'','/1/2/',0,'f3e90596361e31d496d4026eb624c983',8,1),
 (4,1,1,1,0,0,5,1305866665,5,1,'users','/1/5/',0,'3f6d92f8044aed134f32153517850f5a',1,1),
 (11,1,2,2,0,0,12,1305866665,12,5,'users/members','/1/5/12/',0,'602dcf84765e56b7f999eaafd3821dd3',1,1),
 (12,1,1,2,0,0,13,1305866663,13,5,'users/administrator_users','/1/5/13/',0,'769380b7aa94541679167eab817ca893',1,1),
 (13,1,1,2,0,0,14,1081860719,14,5,'users/editors','/1/5/14/',0,'f7dda2854fc68f7c8455d9cb14bd04a9',1,1),
 (14,1,4,3,0,0,15,1305866663,15,13,'users/administrator_users/administrator_user','/1/5/13/15/',0,'e5161a99f733200b9ed4e80f9c16187b',1,1),
 (41,1,1,1,0,0,43,1307017647,43,1,'media','/1/43/',0,'75c715a51699d2d309a924eca6a95145',9,1),
 (42,1,1,2,0,0,44,1081860719,44,5,'users/anonymous_users','/1/5/44/',0,'4fdf0072da953bb276c0c7e0141c5c9b',9,1),
 (10,1,2,3,0,0,45,1081860719,45,44,'users/anonymous_users/anonymous_user','/1/5/44/45/',0,'2cf8343bee7b482bab82b269d8fecd76',9,1),
 (45,1,1,1,0,0,48,1184592117,48,1,'setup2','/1/48/',0,'182ce1b5af0c09fa378557c462ba2617',9,1),
 (49,1,1,2,0,0,51,1081860720,51,43,'media/images','/1/43/51/',0,'1b26c0454b09bb49dfb1b9190ffd67cb',9,1),
 (50,1,1,2,0,0,52,1081860720,52,43,'media/files','/1/43/52/',0,'0b113a208f7890f9ad3c24444ff5988c',9,1),
 (51,1,1,2,0,0,53,1307017647,53,43,'media/multimedia','/1/43/53/',0,'4f18b82c75f10aad476cae5adf98c11f',9,1),
 (52,1,1,2,0,0,54,1184592117,54,48,'setup2/common_ini_settings','/1/48/54/',0,'fa9f3cff9cf90ecfae335718dcbddfe2',1,1),
 (54,1,2,2,0,0,56,1305866664,56,58,'design/plain_site','/1/58/56/',0,'772da20ecf88b3035d73cbdfcea0f119',1,1),
 (56,1,1,1,0,0,58,1305866664,58,1,'design','/1/58/',0,'79f2d67372ab56f59b5d65bb9e0ca3b9',2,0),
 (58,1,1,2,0,0,60,1305866665,60,5,'users/partners','/1/5/60/',0,'9ba1ce7f5ce25b39d1cc5916586915d7',1,1),
 (59,1,1,2,0,0,61,1305979909,61,2,'peluches','/1/2/61/',0,'e551e0aff8ed77eb13314c45b7ede2b5',1,1),
 (61,1,1,2,0,0,63,1305867313,63,2,'mentions_legales','/1/2/63/',0,'643fbfe4e609268cd3dfeb26248ad10e',1,1),
 (62,1,1,2,0,0,64,1305867740,64,2,'poupees','/1/2/64/',0,'3dad146c1bf6e7497f572def5189afb0',1,1),
 (63,1,1,2,0,0,65,1305867397,65,2,'la_societe','/1/2/65/',0,'41d9eb1c69a0271e462db600f08188e5',1,1),
 (64,1,2,3,0,0,66,1305867657,66,61,'peluches/la_peluche_mickey_mouse','/1/2/61/66/',0,'545bb2bf13f184ead8a5c15b6f936f0e',1,1),
 (65,1,1,3,0,0,67,1305867483,67,61,'peluches/la_peluche_minnie_mouse','/1/2/61/67/',0,'37359016fc41701aa9fafb8ce9198aab',1,1),
 (66,1,2,3,0,0,68,1305979909,68,61,'peluches/la_peluche_donald_duck','/1/2/61/68/',0,'fe2506982627e23e78e8d016656c4f5a',1,1),
 (67,1,1,3,0,0,69,1305867702,69,64,'poupees/melanie','/1/2/64/69/',0,'f91c3a9d21f5af9631525b9f006950d4',1,1),
 (68,1,1,3,0,0,70,1305867740,70,64,'poupees/arthur','/1/2/64/70/',0,'9926b15098877324bf439bd74e9f54ac',1,1),
 (70,1,1,2,0,0,71,1306043687,71,2,'test_google_analytics_v3','/1/2/71/',0,'3e84f98943fe9e34c05782a493bbb16b',1,1),
 (71,1,1,2,0,0,72,1306053772,72,2,'champs_elysees','/1/2/72/',0,'f195382129bbb4e52e67ef489b71d355',1,1),
 (73,1,5,2,0,0,73,1306086687,73,2,'new_article','/1/2/73/',0,'fc28faae12aa9f40f288b7fb7f1a55b8',1,1),
 (74,1,2,3,0,0,74,1307017647,74,53,'media/multimedia/banniere_transparente','/1/43/53/74/',0,'f075a229feca505d314fe6c358b95cea',1,1);
/*!40000 ALTER TABLE `ezcontentobject_tree` ENABLE KEYS */;


--
-- Dumping data for table `ezcontentobject_version`
--

/*!40000 ALTER TABLE `ezcontentobject_version` DISABLE KEYS */;
INSERT INTO `ezcontentobject_version` (`contentobject_id`,`created`,`creator_id`,`id`,`initial_language_id`,`language_mask`,`modified`,`status`,`user_id`,`version`,`workflow_event_pos`) VALUES 
 (4,0,14,4,2,3,0,1,0,1,1),
 (11,1033920737,14,439,2,3,1033920746,3,0,1,0),
 (12,1033920760,14,440,2,3,1033920775,1,0,1,0),
 (13,1033920786,14,441,2,3,1033920794,1,0,1,0),
 (41,1060695450,14,472,2,3,1060695457,1,0,1,0),
 (42,1072180278,14,473,2,3,1072180330,1,0,1,0),
 (10,1072180337,14,474,2,3,1072180405,1,0,2,0),
 (45,1079684084,14,477,2,3,1079684190,1,0,1,0),
 (49,1080220181,14,488,2,3,1080220197,1,0,1,0),
 (50,1080220211,14,489,2,3,1080220220,1,0,1,0),
 (51,1080220225,14,490,2,3,1080220233,1,0,1,0),
 (52,1082016497,14,491,2,2,1082016591,1,0,1,0),
 (56,1103023120,14,495,2,3,1103023120,1,0,1,0),
 (14,1301061783,14,499,2,3,1301062024,3,0,3,0),
 (54,1301062300,14,500,2,2,1301062375,1,0,2,0),
 (14,1305866662,14,505,2,3,1305866662,1,0,4,0),
 (58,1305866665,14,506,2,3,1305866665,1,0,1,0),
 (11,1305866665,14,507,2,3,1305866665,1,0,2,0),
 (59,1305867077,14,508,2,3,1305867225,1,0,1,0),
 (61,1305867276,14,510,2,3,1305867313,1,0,1,0),
 (62,1305867343,14,511,2,3,1305867354,1,0,1,0),
 (63,1305867372,14,512,2,3,1305867397,1,0,1,0),
 (64,1305867436,14,513,2,3,1305867455,3,0,1,0),
 (65,1305867470,14,514,2,3,1305867483,1,0,1,0),
 (66,1305867515,14,515,2,3,1305867536,3,0,1,0),
 (64,1305867639,14,516,2,3,1305867657,1,0,2,0),
 (67,1305867683,14,517,2,3,1305867702,1,0,1,0),
 (68,1305867724,14,518,2,3,1305867739,1,0,1,0),
 (57,1305868262,14,520,2,3,1305868836,3,0,3,0),
 (57,1305873317,14,521,2,3,1305873368,3,0,4,0),
 (57,1305964708,14,522,2,3,1305964809,3,0,5,0),
 (57,1305964822,14,523,2,3,1305964856,3,0,6,0),
 (57,1305969947,14,524,2,3,1305970278,3,0,7,0),
 (57,1305978983,14,525,2,3,1305979288,3,0,8,0),
 (57,1305979305,14,526,2,3,1305979422,3,0,9,0),
 (66,1305979762,14,527,2,3,1305979908,1,0,2,0),
 (70,1306043629,14,529,2,3,1306043684,1,0,1,0),
 (57,1306043703,14,530,2,3,1306044411,3,0,10,0),
 (71,1306053679,14,531,2,3,1306053769,1,0,1,0),
 (73,1306066034,14,533,2,3,1306081523,3,0,1,0),
 (73,1306081544,14,534,2,3,1306084491,3,0,2,0),
 (73,1306084504,14,535,2,3,1306085846,3,0,3,0),
 (73,1306085859,14,536,2,3,1306085886,3,0,4,0),
 (73,1306085900,14,537,2,3,1306086687,1,0,5,0),
 (57,1306503839,14,538,2,3,1306503855,3,0,11,0),
 (57,1307017468,14,539,2,3,1307017812,1,0,12,0),
 (74,1307017566,14,540,2,3,1307017623,3,0,1,0),
 (74,1307017635,14,541,2,3,1307017647,1,0,2,0);
/*!40000 ALTER TABLE `ezcontentobject_version` ENABLE KEYS */;


--
-- Dumping data for table `ezcurrencydata`
--

/*!40000 ALTER TABLE `ezcurrencydata` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezcurrencydata` ENABLE KEYS */;


--
-- Dumping data for table `ezdiscountrule`
--

/*!40000 ALTER TABLE `ezdiscountrule` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezdiscountrule` ENABLE KEYS */;


--
-- Dumping data for table `ezdiscountsubrule`
--

/*!40000 ALTER TABLE `ezdiscountsubrule` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezdiscountsubrule` ENABLE KEYS */;


--
-- Dumping data for table `ezdiscountsubrule_value`
--

/*!40000 ALTER TABLE `ezdiscountsubrule_value` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezdiscountsubrule_value` ENABLE KEYS */;


--
-- Dumping data for table `ezenumobjectvalue`
--

/*!40000 ALTER TABLE `ezenumobjectvalue` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezenumobjectvalue` ENABLE KEYS */;


--
-- Dumping data for table `ezenumvalue`
--

/*!40000 ALTER TABLE `ezenumvalue` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezenumvalue` ENABLE KEYS */;


--
-- Dumping data for table `ezforgot_password`
--

/*!40000 ALTER TABLE `ezforgot_password` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezforgot_password` ENABLE KEYS */;


--
-- Dumping data for table `ezgeneral_digest_user_settings`
--

/*!40000 ALTER TABLE `ezgeneral_digest_user_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezgeneral_digest_user_settings` ENABLE KEYS */;


--
-- Dumping data for table `ezgmaplocation`
--

/*!40000 ALTER TABLE `ezgmaplocation` DISABLE KEYS */;
INSERT INTO `ezgmaplocation` (`contentobject_attribute_id`,`contentobject_version`,`latitude`,`longitude`,`address`) VALUES 
 (330,1,48.872208,2.377111,'1 rue de belleville paris'),
 (342,1,48.869279,2.309085,'1, avenue des champs elys&eacute;es 75008 ,paris'),
 (366,3,51.500152,-0.126236,'Londres'),
 (366,4,48.856666,2.350987,''),
 (366,5,48.856666,2.350987,'');
/*!40000 ALTER TABLE `ezgmaplocation` ENABLE KEYS */;


--
-- Dumping data for table `ezimagefile`
--

/*!40000 ALTER TABLE `ezimagefile` DISABLE KEYS */;
INSERT INTO `ezimagefile` (`contentobject_attribute_id`,`filepath`,`id`) VALUES 
 (172,'var/storage/images/setup/ez_publish/172-1-eng-GB/ez_publish.',1),
 (172,'var/ezflow_site/storage/images/design/plain-site/172-2-fre-FR/Nounours1.png',2),
 (285,'var/ezflow_site/storage/images/peluches/la-peluche-donald-duck/285-2-fre-FR/La-peluche-Donald-Duck.jpg',4),
 (285,'var/ezflow_site/storage/images/peluches/la-peluche-donald-duck/285-2-fre-FR/La-peluche-Donald-Duck_medium.jpg',5),
 (285,'var/ezflow_site/storage/images/peluches/la-peluche-donald-duck/285-2-fre-FR/La-peluche-Donald-Duck_small.jpg',6);
/*!40000 ALTER TABLE `ezimagefile` ENABLE KEYS */;


--
-- Dumping data for table `ezinfocollection`
--

/*!40000 ALTER TABLE `ezinfocollection` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezinfocollection` ENABLE KEYS */;


--
-- Dumping data for table `ezinfocollection_attribute`
--

/*!40000 ALTER TABLE `ezinfocollection_attribute` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezinfocollection_attribute` ENABLE KEYS */;


--
-- Dumping data for table `ezisbn_group`
--

/*!40000 ALTER TABLE `ezisbn_group` DISABLE KEYS */;
INSERT INTO `ezisbn_group` (`description`,`group_number`,`id`) VALUES 
 ('English language',0,1),
 ('English language',1,2),
 ('French language',2,3),
 ('German language',3,4),
 ('Japan',4,5),
 ('Russian Federation and former USSR',5,6),
 ('Iran',600,7),
 ('Kazakhstan',601,8),
 ('Indonesia',602,9),
 ('Saudi Arabia',603,10),
 ('Vietnam',604,11),
 ('Turkey',605,12),
 ('Romania',606,13),
 ('Mexico',607,14),
 ('Macedonia',608,15),
 ('Lithuania',609,16),
 ('Thailand',611,17),
 ('Peru',612,18),
 ('Mauritius',613,19),
 ('Lebanon',614,20),
 ('Hungary',615,21),
 ('Thailand',616,22),
 ('Ukraine',617,23),
 ('China, People\'s Republic',7,24),
 ('Czech Republic and Slovakia',80,25),
 ('India',81,26),
 ('Norway',82,27),
 ('Poland',83,28),
 ('Spain',84,29),
 ('Brazil',85,30),
 ('Serbia and Montenegro',86,31),
 ('Denmark',87,32),
 ('Italy',88,33),
 ('Korea, Republic',89,34),
 ('Netherlands',90,35),
 ('Sweden',91,36),
 ('International NGO Publishers and EC Organizations',92,37),
 ('India',93,38),
 ('Netherlands',94,39),
 ('Argentina',950,40),
 ('Finland',951,41),
 ('Finland',952,42),
 ('Croatia',953,43),
 ('Bulgaria',954,44),
 ('Sri Lanka',955,45),
 ('Chile',956,46),
 ('Taiwan',957,47),
 ('Colombia',958,48),
 ('Cuba',959,49),
 ('Greece',960,50),
 ('Slovenia',961,51),
 ('Hong Kong, China',962,52),
 ('Hungary',963,53),
 ('Iran',964,54),
 ('Israel',965,55),
 ('Ukraine',966,56),
 ('Malaysia',967,57),
 ('Mexico',968,58),
 ('Pakistan',969,59),
 ('Mexico',970,60),
 ('Philippines',971,61),
 ('Portugal',972,62),
 ('Romania',973,63),
 ('Thailand',974,64),
 ('Turkey',975,65),
 ('Caribbean Community',976,66),
 ('Egypt',977,67),
 ('Nigeria',978,68),
 ('Indonesia',979,69),
 ('Venezuela',980,70),
 ('Singapore',981,71),
 ('South Pacific',982,72),
 ('Malaysia',983,73),
 ('Bangladesh',984,74),
 ('Belarus',985,75),
 ('Taiwan',986,76),
 ('Argentina',987,77),
 ('Hong Kong, China',988,78),
 ('Portugal',989,79),
 ('Qatar',9927,80),
 ('Albania',9928,81),
 ('Guatemala',9929,82),
 ('Costa Rica',9930,83),
 ('Algeria',9931,84),
 ('Lao People\'s Democratic Republic',9932,85),
 ('Syria',9933,86),
 ('Latvia',9934,87),
 ('Iceland',9935,88),
 ('Afghanistan',9936,89),
 ('Nepal',9937,90),
 ('Tunisia',9938,91),
 ('Armenia',9939,92),
 ('Montenegro',9940,93),
 ('Georgia',9941,94),
 ('Ecuador',9942,95),
 ('Uzbekistan',9943,96),
 ('Turkey',9944,97),
 ('Dominican Republic',9945,98),
 ('Korea, P.D.R.',9946,99),
 ('Algeria',9947,100),
 ('United Arab Emirates',9948,101),
 ('Estonia',9949,102),
 ('Palestine',9950,103),
 ('Kosova',9951,104),
 ('Azerbaijan',9952,105),
 ('Lebanon',9953,106),
 ('Morocco',9954,107),
 ('Lithuania',9955,108),
 ('Cameroon',9956,109),
 ('Jordan',9957,110),
 ('Bosnia and Herzegovina',9958,111),
 ('Libya',9959,112),
 ('Saudi Arabia',9960,113),
 ('Algeria',9961,114),
 ('Panama',9962,115),
 ('Cyprus',9963,116),
 ('Ghana',9964,117),
 ('Kazakhstan',9965,118),
 ('Kenya',9966,119),
 ('Kyrgyz Republic',9967,120),
 ('Costa Rica',9968,121),
 ('Uganda',9970,122),
 ('Singapore',9971,123),
 ('Peru',9972,124),
 ('Tunisia',9973,125),
 ('Uruguay',9974,126),
 ('Moldova',9975,127),
 ('Tanzania',9976,128),
 ('Costa Rica',9977,129),
 ('Ecuador',9978,130),
 ('Iceland',9979,131),
 ('Papua New Guinea',9980,132),
 ('Morocco',9981,133),
 ('Zambia',9982,134),
 ('Gambia',9983,135),
 ('Latvia',9984,136),
 ('Estonia',9985,137),
 ('Lithuania',9986,138),
 ('Tanzania',9987,139),
 ('Ghana',9988,140),
 ('Macedonia',9989,141),
 ('Bahrain',99901,142),
 ('Gabon',99902,143),
 ('Mauritius',99903,144),
 ('Netherlands Antilles and Aruba',99904,145),
 ('Bolivia',99905,146),
 ('Kuwait',99906,147),
 ('Malawi',99908,148),
 ('Malta',99909,149),
 ('Sierra Leone',99910,150),
 ('Lesotho',99911,151),
 ('Botswana',99912,152),
 ('Andorra',99913,153),
 ('Suriname',99914,154),
 ('Maldives',99915,155),
 ('Namibia',99916,156),
 ('Brunei Darussalam',99917,157),
 ('Faroe Islands',99918,158),
 ('Benin',99919,159),
 ('Andorra',99920,160),
 ('Qatar',99921,161),
 ('Guatemala',99922,162),
 ('El Salvador',99923,163),
 ('Nicaragua',99924,164),
 ('Paraguay',99925,165),
 ('Honduras',99926,166),
 ('Albania',99927,167),
 ('Georgia',99928,168),
 ('Mongolia',99929,169),
 ('Armenia',99930,170),
 ('Seychelles',99931,171),
 ('Malta',99932,172),
 ('Nepal',99933,173),
 ('Dominican Republic',99934,174),
 ('Haiti',99935,175),
 ('Bhutan',99936,176),
 ('Macau',99937,177),
 ('Srpska, Republic of',99938,178),
 ('Guatemala',99939,179),
 ('Georgia',99940,180),
 ('Armenia',99941,181),
 ('Sudan',99942,182),
 ('Albania',99943,183),
 ('Ethiopia',99944,184),
 ('Namibia',99945,185),
 ('Nepal',99946,186),
 ('Tajikistan',99947,187),
 ('Eritrea',99948,188),
 ('Mauritius',99949,189),
 ('Cambodia',99950,190),
 ('Congo',99951,191),
 ('Mali',99952,192),
 ('Paraguay',99953,193),
 ('Bolivia',99954,194),
 ('Srpska, Republic of',99955,195),
 ('Albania',99956,196),
 ('Malta',99957,197),
 ('Bahrain',99958,198),
 ('Luxembourg',99959,199),
 ('Malawi',99960,200),
 ('El Salvador',99961,201),
 ('Mongolia',99962,202),
 ('Cambodia',99963,203),
 ('Nicaragua',99964,204),
 ('Macau',99965,205),
 ('Kuwait',99966,206),
 ('Paraguay',99967,207),
 ('Botswana',99968,208),
 ('France',10,209);
/*!40000 ALTER TABLE `ezisbn_group` ENABLE KEYS */;


--
-- Dumping data for table `ezisbn_group_range`
--

/*!40000 ALTER TABLE `ezisbn_group_range` DISABLE KEYS */;
INSERT INTO `ezisbn_group_range` (`from_number`,`group_from`,`group_length`,`group_to`,`id`,`to_number`) VALUES 
 (0,'0',1,'5',1,59999),
 (60000,'600',3,'649',2,64999),
 (70000,'7',1,'7',3,79999),
 (80000,'80',2,'94',4,94999),
 (95000,'950',3,'989',5,98999),
 (99000,'9900',4,'9989',6,99899),
 (99900,'99900',5,'99999',7,99999),
 (10000,'10',2,'10',8,10999);
/*!40000 ALTER TABLE `ezisbn_group_range` ENABLE KEYS */;


--
-- Dumping data for table `ezisbn_registrant_range`
--

/*!40000 ALTER TABLE `ezisbn_registrant_range` DISABLE KEYS */;
INSERT INTO `ezisbn_registrant_range` (`from_number`,`id`,`isbn_group_id`,`registrant_from`,`registrant_length`,`registrant_to`,`to_number`) VALUES 
 (0,1,1,'00',2,'19',19999),
 (20000,2,1,'200',3,'699',69999),
 (70000,3,1,'7000',4,'8499',84999),
 (85000,4,1,'85000',5,'89999',89999),
 (90000,5,1,'900000',6,'949999',94999),
 (95000,6,1,'9500000',7,'9999999',99999),
 (0,7,2,'00',2,'09',9999),
 (10000,8,2,'100',3,'399',39999),
 (40000,9,2,'4000',4,'5499',54999),
 (55000,10,2,'55000',5,'86979',86979),
 (86980,11,2,'869800',6,'998999',99899),
 (99900,12,2,'9990000',7,'9999999',99999),
 (0,13,3,'00',2,'19',19999),
 (20000,14,3,'200',3,'349',34999),
 (35000,15,3,'35000',5,'39999',39999),
 (40000,16,3,'400',3,'699',69999),
 (70000,17,3,'7000',4,'8399',83999),
 (84000,18,3,'84000',5,'89999',89999),
 (90000,19,3,'900000',6,'949999',94999),
 (95000,20,3,'9500000',7,'9999999',99999),
 (0,21,4,'00',2,'02',2999),
 (3000,22,4,'030',3,'033',3399),
 (3400,23,4,'0340',4,'0369',3699),
 (3700,24,4,'03700',5,'03999',3999),
 (4000,25,4,'04',2,'19',19999),
 (20000,26,4,'200',3,'699',69999),
 (70000,27,4,'7000',4,'8499',84999),
 (85000,28,4,'85000',5,'89999',89999),
 (90000,29,4,'900000',6,'949999',94999),
 (95000,30,4,'9500000',7,'9539999',95399),
 (95400,31,4,'95400',5,'96999',96999),
 (97000,32,4,'9700000',7,'9899999',98999),
 (99000,33,4,'99000',5,'99499',99499),
 (99500,34,4,'99500',5,'99999',99999),
 (0,35,5,'00',2,'19',19999),
 (20000,36,5,'200',3,'699',69999),
 (70000,37,5,'7000',4,'8499',84999),
 (85000,38,5,'85000',5,'89999',89999),
 (90000,39,5,'900000',6,'949999',94999),
 (95000,40,5,'9500000',7,'9999999',99999),
 (0,41,6,'00',2,'19',19999),
 (20000,42,6,'200',3,'420',42099),
 (42100,43,6,'4210',4,'4299',42999),
 (43000,44,6,'430',3,'430',43099),
 (43100,45,6,'4310',4,'4399',43999),
 (44000,46,6,'440',3,'440',44099),
 (44100,47,6,'4410',4,'4499',44999),
 (45000,48,6,'450',3,'699',69999),
 (70000,49,6,'7000',4,'8499',84999),
 (85000,50,6,'85000',5,'89999',89999),
 (90000,51,6,'900000',6,'909999',90999),
 (91000,52,6,'91000',5,'91999',91999),
 (92000,53,6,'9200',4,'9299',92999),
 (93000,54,6,'93000',5,'94999',94999),
 (95000,55,6,'9500000',7,'9500999',95009),
 (95010,56,6,'9501',4,'9799',97999),
 (98000,57,6,'98000',5,'98999',98999),
 (99000,58,6,'9900000',7,'9909999',99099),
 (99100,59,6,'9910',4,'9999',99999),
 (0,60,7,'00',2,'09',9999),
 (10000,61,7,'100',3,'499',49999),
 (50000,62,7,'5000',4,'8999',89999),
 (90000,63,7,'90000',5,'99999',99999),
 (0,64,8,'00',2,'19',19999),
 (20000,65,8,'200',3,'699',69999),
 (70000,66,8,'7000',4,'7999',79999),
 (80000,67,8,'80000',5,'84999',84999),
 (85000,68,8,'85',2,'99',99999),
 (0,69,9,'00',2,'19',19999),
 (20000,70,9,'200',3,'799',79999),
 (80000,71,9,'8000',4,'9499',94999),
 (95000,72,9,'95000',5,'99999',99999),
 (0,73,10,'00',2,'04',4999),
 (5000,74,10,'05',2,'49',49999),
 (50000,75,10,'500',3,'799',79999),
 (80000,76,10,'8000',4,'8999',89999),
 (90000,77,10,'90000',5,'99999',99999),
 (0,78,11,'0',1,'4',49999),
 (50000,79,11,'50',2,'89',89999),
 (90000,80,11,'900',3,'979',97999),
 (98000,81,11,'9800',4,'9999',99999),
 (1000,82,12,'01',2,'09',9999),
 (10000,83,12,'100',3,'399',39999),
 (40000,84,12,'4000',4,'5999',59999),
 (60000,85,12,'60000',5,'89999',89999),
 (90000,86,12,'90',2,'99',99999),
 (0,87,13,'0',1,'0',9999),
 (10000,88,13,'10',2,'49',49999),
 (50000,89,13,'500',3,'799',79999),
 (80000,90,13,'8000',4,'9199',91999),
 (92000,91,13,'92000',5,'99999',99999),
 (0,92,14,'00',2,'39',39999),
 (40000,93,14,'400',3,'749',74999),
 (75000,94,14,'7500',4,'9499',94999),
 (95000,95,14,'95000',5,'99999',99999),
 (0,96,15,'0',1,'0',9999),
 (10000,97,15,'10',2,'19',19999),
 (20000,98,15,'200',3,'449',44999),
 (45000,99,15,'4500',4,'6499',64999),
 (65000,100,15,'65000',5,'69999',69999),
 (70000,101,15,'7',1,'9',99999),
 (0,102,16,'00',2,'39',39999),
 (40000,103,16,'400',3,'799',79999),
 (80000,104,16,'8000',4,'9499',94999),
 (95000,105,16,'95000',5,'99999',99999),
 (0,106,18,'00',2,'29',29999),
 (30000,107,18,'300',3,'399',39999),
 (40000,108,18,'4000',4,'4499',44999),
 (45000,109,18,'45000',5,'49999',49999),
 (50000,110,18,'50',2,'99',99999),
 (0,111,19,'0',1,'9',99999),
 (0,112,20,'00',2,'39',39999),
 (40000,113,20,'400',3,'799',79999),
 (80000,114,20,'8000',4,'9499',94999),
 (95000,115,20,'95000',5,'99999',99999),
 (0,116,21,'00',2,'09',9999),
 (10000,117,21,'100',3,'499',49999),
 (50000,118,21,'5000',4,'7999',79999),
 (80000,119,21,'80000',5,'89999',89999),
 (0,120,22,'00',2,'19',19999),
 (20000,121,22,'200',3,'699',69999),
 (70000,122,22,'7000',4,'8999',89999),
 (90000,123,22,'90000',5,'99999',99999),
 (0,124,23,'00',2,'49',49999),
 (50000,125,23,'500',3,'699',69999),
 (70000,126,23,'7000',4,'8999',89999),
 (90000,127,23,'90000',5,'99999',99999),
 (0,128,24,'00',2,'09',9999),
 (10000,129,24,'100',3,'499',49999),
 (50000,130,24,'5000',4,'7999',79999),
 (80000,131,24,'80000',5,'89999',89999),
 (90000,132,24,'900000',6,'999999',99999),
 (0,133,25,'00',2,'19',19999),
 (20000,134,25,'200',3,'699',69999),
 (70000,135,25,'7000',4,'8499',84999),
 (85000,136,25,'85000',5,'89999',89999),
 (90000,137,25,'900000',6,'999999',99999),
 (0,138,26,'00',2,'19',19999),
 (20000,139,26,'200',3,'699',69999),
 (70000,140,26,'7000',4,'8499',84999),
 (85000,141,26,'85000',5,'89999',89999),
 (90000,142,26,'900000',6,'999999',99999),
 (0,143,27,'00',2,'19',19999),
 (20000,144,27,'200',3,'699',69999),
 (70000,145,27,'7000',4,'8999',89999),
 (90000,146,27,'90000',5,'98999',98999),
 (99000,147,27,'990000',6,'999999',99999),
 (0,148,28,'00',2,'19',19999),
 (20000,149,28,'200',3,'599',59999),
 (60000,150,28,'60000',5,'69999',69999),
 (70000,151,28,'7000',4,'8499',84999),
 (85000,152,28,'85000',5,'89999',89999),
 (90000,153,28,'900000',6,'999999',99999),
 (0,154,29,'00',2,'14',14999),
 (15000,155,29,'15000',5,'19999',19999),
 (20000,156,29,'200',3,'699',69999),
 (70000,157,29,'7000',4,'8499',84999),
 (85000,158,29,'85000',5,'89999',89999),
 (90000,159,29,'9000',4,'9199',91999),
 (92000,160,29,'920000',6,'923999',92399),
 (92400,161,29,'92400',5,'92999',92999),
 (93000,162,29,'930000',6,'949999',94999),
 (95000,163,29,'95000',5,'96999',96999),
 (97000,164,29,'9700',4,'9999',99999),
 (0,165,30,'00',2,'19',19999),
 (20000,166,30,'200',3,'599',59999),
 (60000,167,30,'60000',5,'69999',69999),
 (70000,168,30,'7000',4,'8499',84999),
 (85000,169,30,'85000',5,'89999',89999),
 (90000,170,30,'900000',6,'979999',97999),
 (98000,171,30,'98000',5,'99999',99999),
 (0,172,31,'00',2,'29',29999),
 (30000,173,31,'300',3,'599',59999),
 (60000,174,31,'6000',4,'7999',79999),
 (80000,175,31,'80000',5,'89999',89999),
 (90000,176,31,'900000',6,'999999',99999),
 (0,177,32,'00',2,'29',29999),
 (40000,178,32,'400',3,'649',64999),
 (70000,179,32,'7000',4,'7999',79999),
 (85000,180,32,'85000',5,'94999',94999),
 (97000,181,32,'970000',6,'999999',99999),
 (0,182,33,'00',2,'19',19999),
 (20000,183,33,'200',3,'599',59999),
 (60000,184,33,'6000',4,'8499',84999),
 (85000,185,33,'85000',5,'89999',89999),
 (90000,186,33,'900000',6,'949999',94999),
 (95000,187,33,'95000',5,'99999',99999),
 (0,188,34,'00',2,'24',24999),
 (25000,189,34,'250',3,'549',54999),
 (55000,190,34,'5500',4,'8499',84999),
 (85000,191,34,'85000',5,'94999',94999),
 (95000,192,34,'950000',6,'969999',96999),
 (97000,193,34,'97000',5,'98999',98999),
 (99000,194,34,'990',3,'999',99999),
 (0,195,35,'00',2,'19',19999),
 (20000,196,35,'200',3,'499',49999),
 (50000,197,35,'5000',4,'6999',69999),
 (70000,198,35,'70000',5,'79999',79999),
 (80000,199,35,'800000',6,'849999',84999),
 (85000,200,35,'8500',4,'8999',89999),
 (90000,201,35,'90',2,'90',90999),
 (91000,202,35,'910000',6,'939999',93999),
 (94000,203,35,'94',2,'94',94999),
 (95000,204,35,'950000',6,'999999',99999),
 (0,205,36,'0',1,'1',19999),
 (20000,206,36,'20',2,'49',49999),
 (50000,207,36,'500',3,'649',64999),
 (70000,208,36,'7000',4,'7999',79999),
 (85000,209,36,'85000',5,'94999',94999),
 (97000,210,36,'970000',6,'999999',99999),
 (0,211,37,'0',1,'5',59999),
 (60000,212,37,'60',2,'79',79999),
 (80000,213,37,'800',3,'899',89999),
 (90000,214,37,'9000',4,'9499',94999),
 (95000,215,37,'95000',5,'98999',98999),
 (99000,216,37,'990000',6,'999999',99999),
 (0,217,38,'00',2,'09',9999),
 (10000,218,38,'100',3,'499',49999),
 (50000,219,38,'5000',4,'7999',79999),
 (80000,220,38,'80000',5,'94999',94999),
 (95000,221,38,'950000',6,'999999',99999),
 (0,222,39,'000',3,'599',59999),
 (60000,223,39,'6000',4,'8999',89999),
 (90000,224,39,'90000',5,'99999',99999),
 (0,225,40,'00',2,'49',49999),
 (50000,226,40,'500',3,'899',89999),
 (90000,227,40,'9000',4,'9899',98999),
 (99000,228,40,'99000',5,'99999',99999),
 (0,229,41,'0',1,'1',19999),
 (20000,230,41,'20',2,'54',54999),
 (55000,231,41,'550',3,'889',88999),
 (89000,232,41,'8900',4,'9499',94999),
 (95000,233,41,'95000',5,'99999',99999),
 (0,234,42,'00',2,'19',19999),
 (20000,235,42,'200',3,'499',49999),
 (50000,236,42,'5000',4,'5999',59999),
 (60000,237,42,'60',2,'65',65999),
 (66000,238,42,'6600',4,'6699',66999),
 (67000,239,42,'67000',5,'69999',69999),
 (70000,240,42,'7000',4,'7999',79999),
 (80000,241,42,'80',2,'94',94999),
 (95000,242,42,'9500',4,'9899',98999),
 (99000,243,42,'99000',5,'99999',99999),
 (0,244,43,'0',1,'0',9999),
 (10000,245,43,'10',2,'14',14999),
 (15000,246,43,'150',3,'549',54999),
 (55000,247,43,'55000',5,'59999',59999),
 (60000,248,43,'6000',4,'9499',94999),
 (95000,249,43,'95000',5,'99999',99999),
 (0,250,44,'00',2,'28',28999),
 (29000,251,44,'2900',4,'2999',29999),
 (30000,252,44,'300',3,'799',79999),
 (80000,253,44,'8000',4,'8999',89999),
 (90000,254,44,'90000',5,'92999',92999),
 (93000,255,44,'9300',4,'9999',99999),
 (0,256,45,'0000',4,'1999',19999),
 (20000,257,45,'20',2,'49',49999),
 (50000,258,45,'50000',5,'54999',54999),
 (55000,259,45,'550',3,'799',79999),
 (80000,260,45,'8000',4,'9499',94999),
 (95000,261,45,'95000',5,'99999',99999),
 (0,262,46,'00',2,'19',19999),
 (20000,263,46,'200',3,'699',69999),
 (70000,264,46,'7000',4,'9999',99999),
 (0,265,47,'00',2,'02',2999),
 (3000,266,47,'0300',4,'0499',4999),
 (5000,267,47,'05',2,'19',19999),
 (20000,268,47,'2000',4,'2099',20999),
 (21000,269,47,'21',2,'27',27999),
 (28000,270,47,'28000',5,'30999',30999),
 (31000,271,47,'31',2,'43',43999),
 (44000,272,47,'440',3,'819',81999),
 (82000,273,47,'8200',4,'9699',96999),
 (97000,274,47,'97000',5,'99999',99999),
 (0,275,48,'00',2,'56',56999),
 (57000,276,48,'57000',5,'59999',59999),
 (60000,277,48,'600',3,'799',79999),
 (80000,278,48,'8000',4,'9499',94999),
 (95000,279,48,'95000',5,'99999',99999),
 (0,280,49,'00',2,'19',19999),
 (20000,281,49,'200',3,'699',69999),
 (70000,282,49,'7000',4,'8499',84999),
 (85000,283,49,'85000',5,'99999',99999),
 (0,284,50,'00',2,'19',19999),
 (20000,285,50,'200',3,'659',65999),
 (66000,286,50,'6600',4,'6899',68999),
 (69000,287,50,'690',3,'699',69999),
 (70000,288,50,'7000',4,'8499',84999),
 (85000,289,50,'85000',5,'92999',92999),
 (93000,290,50,'93',2,'93',93999),
 (94000,291,50,'9400',4,'9799',97999),
 (98000,292,50,'98000',5,'99999',99999),
 (0,293,51,'00',2,'19',19999),
 (20000,294,51,'200',3,'599',59999),
 (60000,295,51,'6000',4,'8999',89999),
 (90000,296,51,'90000',5,'94999',94999),
 (0,297,52,'00',2,'19',19999),
 (20000,298,52,'200',3,'699',69999),
 (70000,299,52,'7000',4,'8499',84999),
 (85000,300,52,'85000',5,'86999',86999),
 (87000,301,52,'8700',4,'8999',89999),
 (90000,302,52,'900',3,'999',99999),
 (0,303,53,'00',2,'19',19999),
 (20000,304,53,'200',3,'699',69999),
 (70000,305,53,'7000',4,'8499',84999),
 (85000,306,53,'85000',5,'89999',89999),
 (90000,307,53,'9000',4,'9999',99999),
 (0,308,54,'00',2,'14',14999),
 (15000,309,54,'150',3,'249',24999),
 (25000,310,54,'2500',4,'2999',29999),
 (30000,311,54,'300',3,'549',54999),
 (55000,312,54,'5500',4,'8999',89999),
 (90000,313,54,'90000',5,'96999',96999),
 (97000,314,54,'970',3,'989',98999),
 (99000,315,54,'9900',4,'9999',99999),
 (0,316,55,'00',2,'19',19999),
 (20000,317,55,'200',3,'599',59999),
 (70000,318,55,'7000',4,'7999',79999),
 (90000,319,55,'90000',5,'99999',99999),
 (0,320,56,'00',2,'14',14999),
 (15000,321,56,'1500',4,'1699',16999),
 (17000,322,56,'170',3,'199',19999),
 (20000,323,56,'2000',4,'2999',29999),
 (30000,324,56,'300',3,'699',69999),
 (70000,325,56,'7000',4,'8999',89999),
 (90000,326,56,'90000',5,'99999',99999),
 (0,327,57,'00',2,'00',999),
 (1000,328,57,'0100',4,'0999',9999),
 (10000,329,57,'10000',5,'19999',19999),
 (30000,330,57,'300',3,'499',49999),
 (50000,331,57,'5000',4,'5999',59999),
 (60000,332,57,'60',2,'89',89999),
 (90000,333,57,'900',3,'989',98999),
 (99000,334,57,'9900',4,'9989',99899),
 (99900,335,57,'99900',5,'99999',99999),
 (1000,336,58,'01',2,'39',39999),
 (40000,337,58,'400',3,'499',49999),
 (50000,338,58,'5000',4,'7999',79999),
 (80000,339,58,'800',3,'899',89999),
 (90000,340,58,'9000',4,'9999',99999),
 (0,341,59,'0',1,'1',19999),
 (20000,342,59,'20',2,'39',39999),
 (40000,343,59,'400',3,'799',79999),
 (80000,344,59,'8000',4,'9999',99999),
 (1000,345,60,'01',2,'59',59999),
 (60000,346,60,'600',3,'899',89999),
 (90000,347,60,'9000',4,'9099',90999),
 (91000,348,60,'91000',5,'96999',96999),
 (97000,349,60,'9700',4,'9999',99999),
 (0,350,61,'000',3,'015',1599),
 (1600,351,61,'0160',4,'0199',1999),
 (2000,352,61,'02',2,'02',2999),
 (3000,353,61,'0300',4,'0599',5999),
 (6000,354,61,'06',2,'09',9999),
 (10000,355,61,'10',2,'49',49999),
 (50000,356,61,'500',3,'849',84999),
 (85000,357,61,'8500',4,'9099',90999),
 (91000,358,61,'91000',5,'98999',98999),
 (99000,359,61,'9900',4,'9999',99999),
 (0,360,62,'0',1,'1',19999),
 (20000,361,62,'20',2,'54',54999),
 (55000,362,62,'550',3,'799',79999),
 (80000,363,62,'8000',4,'9499',94999),
 (95000,364,62,'95000',5,'99999',99999),
 (0,365,63,'0',1,'0',9999),
 (10000,366,63,'100',3,'169',16999),
 (17000,367,63,'1700',4,'1999',19999),
 (20000,368,63,'20',2,'54',54999),
 (55000,369,63,'550',3,'759',75999),
 (76000,370,63,'7600',4,'8499',84999),
 (85000,371,63,'85000',5,'88999',88999),
 (89000,372,63,'8900',4,'9499',94999),
 (95000,373,63,'95000',5,'99999',99999),
 (0,374,64,'00',2,'19',19999),
 (20000,375,64,'200',3,'699',69999),
 (70000,376,64,'7000',4,'8499',84999),
 (85000,377,64,'85000',5,'89999',89999),
 (90000,378,64,'90000',5,'94999',94999),
 (95000,379,64,'9500',4,'9999',99999),
 (0,380,65,'00000',5,'01999',1999),
 (2000,381,65,'02',2,'24',24999),
 (25000,382,65,'250',3,'599',59999),
 (60000,383,65,'6000',4,'9199',91999),
 (92000,384,65,'92000',5,'98999',98999),
 (99000,385,65,'990',3,'999',99999),
 (0,386,66,'0',1,'3',39999),
 (40000,387,66,'40',2,'59',59999),
 (60000,388,66,'600',3,'799',79999),
 (80000,389,66,'8000',4,'9499',94999),
 (95000,390,66,'95000',5,'99999',99999),
 (0,391,67,'00',2,'19',19999),
 (20000,392,67,'200',3,'499',49999),
 (50000,393,67,'5000',4,'6999',69999),
 (70000,394,67,'700',3,'999',99999),
 (0,395,68,'000',3,'199',19999),
 (20000,396,68,'2000',4,'2999',29999),
 (30000,397,68,'30000',5,'79999',79999),
 (80000,398,68,'8000',4,'8999',89999),
 (90000,399,68,'900',3,'999',99999),
 (0,400,69,'000',3,'099',9999),
 (10000,401,69,'1000',4,'1499',14999),
 (15000,402,69,'15000',5,'19999',19999),
 (20000,403,69,'20',2,'29',29999),
 (30000,404,69,'3000',4,'3999',39999),
 (40000,405,69,'400',3,'799',79999),
 (80000,406,69,'8000',4,'9499',94999),
 (95000,407,69,'95000',5,'99999',99999),
 (0,408,70,'00',2,'19',19999),
 (20000,409,70,'200',3,'599',59999),
 (60000,410,70,'6000',4,'9999',99999),
 (0,411,71,'00',2,'11',11999),
 (12000,412,71,'1200',4,'1999',19999),
 (20000,413,71,'200',3,'289',28999),
 (29000,414,71,'2900',4,'9999',99999),
 (0,415,72,'00',2,'09',9999),
 (10000,416,72,'100',3,'699',69999),
 (70000,417,72,'70',2,'89',89999),
 (90000,418,72,'9000',4,'9799',97999),
 (98000,419,72,'98000',5,'99999',99999),
 (0,420,73,'00',2,'01',1999),
 (2000,421,73,'020',3,'199',19999),
 (20000,422,73,'2000',4,'3999',39999),
 (40000,423,73,'40000',5,'44999',44999),
 (45000,424,73,'45',2,'49',49999),
 (50000,425,73,'50',2,'79',79999),
 (80000,426,73,'800',3,'899',89999),
 (90000,427,73,'9000',4,'9899',98999),
 (99000,428,73,'99000',5,'99999',99999),
 (0,429,74,'00',2,'39',39999),
 (40000,430,74,'400',3,'799',79999),
 (80000,431,74,'8000',4,'8999',89999),
 (90000,432,74,'90000',5,'99999',99999),
 (0,433,75,'00',2,'39',39999),
 (40000,434,75,'400',3,'599',59999),
 (60000,435,75,'6000',4,'8999',89999),
 (90000,436,75,'90000',5,'99999',99999),
 (0,437,76,'00',2,'11',11999),
 (12000,438,76,'120',3,'559',55999),
 (56000,439,76,'5600',4,'7999',79999),
 (80000,440,76,'80000',5,'99999',99999),
 (0,441,77,'00',2,'09',9999),
 (10000,442,77,'1000',4,'1999',19999),
 (20000,443,77,'20000',5,'29999',29999),
 (30000,444,77,'30',2,'49',49999),
 (50000,445,77,'500',3,'899',89999),
 (90000,446,77,'9000',4,'9499',94999),
 (95000,447,77,'95000',5,'99999',99999),
 (0,448,78,'00',2,'14',14999),
 (15000,449,78,'15000',5,'16999',16999),
 (17000,450,78,'17000',5,'19999',19999),
 (20000,451,78,'200',3,'799',79999),
 (80000,452,78,'8000',4,'9699',96999),
 (97000,453,78,'97000',5,'99999',99999),
 (0,454,79,'0',1,'1',19999),
 (20000,455,79,'20',2,'54',54999),
 (55000,456,79,'550',3,'799',79999),
 (80000,457,79,'8000',4,'9499',94999),
 (95000,458,79,'95000',5,'99999',99999),
 (0,459,80,'00',2,'09',9999),
 (10000,460,80,'100',3,'399',39999),
 (40000,461,80,'4000',4,'4999',49999),
 (0,462,81,'00',2,'09',9999),
 (10000,463,81,'100',3,'399',39999),
 (40000,464,81,'4000',4,'4999',49999),
 (0,465,82,'0',1,'3',39999),
 (40000,466,82,'40',2,'54',54999),
 (55000,467,82,'550',3,'799',79999),
 (80000,468,82,'8000',4,'9999',99999),
 (0,469,83,'00',2,'49',49999),
 (50000,470,83,'500',3,'939',93999),
 (94000,471,83,'9400',4,'9999',99999),
 (0,472,84,'00',2,'29',29999),
 (30000,473,84,'300',3,'899',89999),
 (90000,474,84,'9000',4,'9999',99999),
 (0,475,85,'00',2,'39',39999),
 (40000,476,85,'400',3,'849',84999),
 (85000,477,85,'8500',4,'9999',99999),
 (0,478,86,'0',1,'0',9999),
 (10000,479,86,'10',2,'39',39999),
 (40000,480,86,'400',3,'899',89999),
 (90000,481,86,'9000',4,'9999',99999),
 (0,482,87,'0',1,'0',9999),
 (10000,483,87,'10',2,'49',49999),
 (50000,484,87,'500',3,'799',79999),
 (80000,485,87,'8000',4,'9999',99999),
 (0,486,88,'0',1,'0',9999),
 (10000,487,88,'10',2,'39',39999),
 (40000,488,88,'400',3,'899',89999),
 (90000,489,88,'9000',4,'9999',99999),
 (0,490,89,'0',1,'1',19999),
 (20000,491,89,'20',2,'39',39999),
 (40000,492,89,'400',3,'799',79999),
 (80000,493,89,'8000',4,'9999',99999),
 (0,494,90,'0',1,'2',29999),
 (30000,495,90,'30',2,'49',49999),
 (50000,496,90,'500',3,'799',79999),
 (80000,497,90,'8000',4,'9999',99999),
 (0,498,91,'00',2,'79',79999),
 (80000,499,91,'800',3,'949',94999),
 (95000,500,91,'9500',4,'9999',99999),
 (0,501,92,'0',1,'4',49999),
 (50000,502,92,'50',2,'79',79999),
 (80000,503,92,'800',3,'899',89999),
 (90000,504,92,'9000',4,'9999',99999),
 (0,505,93,'0',1,'1',19999),
 (20000,506,93,'20',2,'49',49999),
 (50000,507,93,'500',3,'899',89999),
 (90000,508,93,'9000',4,'9999',99999),
 (0,509,94,'0',1,'0',9999),
 (10000,510,94,'10',2,'39',39999),
 (40000,511,94,'400',3,'899',89999),
 (90000,512,94,'9000',4,'9999',99999),
 (0,513,95,'00',2,'89',89999),
 (90000,514,95,'900',3,'984',98499),
 (98500,515,95,'9850',4,'9999',99999),
 (0,516,96,'00',2,'29',29999),
 (30000,517,96,'300',3,'399',39999),
 (40000,518,96,'4000',4,'9999',99999),
 (0,519,97,'0000',4,'0999',9999),
 (10000,520,97,'100',3,'499',49999),
 (50000,521,97,'5000',4,'5999',59999),
 (60000,522,97,'60',2,'69',69999),
 (70000,523,97,'700',3,'799',79999),
 (80000,524,97,'80',2,'89',89999),
 (90000,525,97,'900',3,'999',99999),
 (0,526,98,'00',2,'00',999),
 (1000,527,98,'010',3,'079',7999),
 (8000,528,98,'08',2,'39',39999),
 (40000,529,98,'400',3,'569',56999),
 (57000,530,98,'57',2,'57',57999),
 (58000,531,98,'580',3,'849',84999),
 (85000,532,98,'8500',4,'9999',99999),
 (0,533,99,'0',1,'1',19999),
 (20000,534,99,'20',2,'39',39999),
 (40000,535,99,'400',3,'899',89999),
 (90000,536,99,'9000',4,'9999',99999),
 (0,537,100,'0',1,'1',19999),
 (20000,538,100,'20',2,'79',79999),
 (80000,539,100,'800',3,'999',99999),
 (0,540,101,'00',2,'39',39999),
 (40000,541,101,'400',3,'849',84999),
 (85000,542,101,'8500',4,'9999',99999),
 (0,543,102,'0',1,'0',9999),
 (10000,544,102,'10',2,'39',39999),
 (40000,545,102,'400',3,'899',89999),
 (90000,546,102,'9000',4,'9999',99999),
 (0,547,103,'00',2,'29',29999),
 (30000,548,103,'300',3,'849',84999),
 (85000,549,103,'8500',4,'9999',99999),
 (0,550,104,'00',2,'39',39999),
 (40000,551,104,'400',3,'849',84999),
 (85000,552,104,'8500',4,'9999',99999),
 (0,553,105,'0',1,'1',19999),
 (20000,554,105,'20',2,'39',39999),
 (40000,555,105,'400',3,'799',79999),
 (80000,556,105,'8000',4,'9999',99999),
 (0,557,106,'0',1,'0',9999),
 (10000,558,106,'10',2,'39',39999),
 (40000,559,106,'400',3,'599',59999),
 (60000,560,106,'60',2,'89',89999),
 (90000,561,106,'9000',4,'9999',99999),
 (0,562,107,'0',1,'1',19999),
 (20000,563,107,'20',2,'39',39999),
 (40000,564,107,'400',3,'799',79999),
 (80000,565,107,'8000',4,'9999',99999),
 (0,566,108,'00',2,'39',39999),
 (40000,567,108,'400',3,'929',92999),
 (93000,568,108,'9300',4,'9999',99999),
 (0,569,109,'0',1,'0',9999),
 (10000,570,109,'10',2,'39',39999),
 (40000,571,109,'400',3,'899',89999),
 (90000,572,109,'9000',4,'9999',99999),
 (0,573,110,'00',2,'39',39999),
 (40000,574,110,'400',3,'699',69999),
 (70000,575,110,'70',2,'84',84999),
 (85000,576,110,'8500',4,'8799',87999),
 (88000,577,110,'88',2,'99',99999),
 (0,578,111,'0',1,'0',9999),
 (10000,579,111,'10',2,'18',18999),
 (19000,580,111,'1900',4,'1999',19999),
 (20000,581,111,'20',2,'49',49999),
 (50000,582,111,'500',3,'899',89999),
 (90000,583,111,'9000',4,'9999',99999),
 (0,584,112,'0',1,'1',19999),
 (20000,585,112,'20',2,'79',79999),
 (80000,586,112,'800',3,'949',94999),
 (95000,587,112,'9500',4,'9999',99999),
 (0,588,113,'00',2,'59',59999),
 (60000,589,113,'600',3,'899',89999),
 (90000,590,113,'9000',4,'9999',99999),
 (0,591,114,'0',1,'2',29999),
 (30000,592,114,'30',2,'69',69999),
 (70000,593,114,'700',3,'949',94999),
 (95000,594,114,'9500',4,'9999',99999),
 (0,595,115,'00',2,'54',54999),
 (55000,596,115,'5500',4,'5599',55999),
 (56000,597,115,'56',2,'59',59999),
 (60000,598,115,'600',3,'849',84999),
 (85000,599,115,'8500',4,'9999',99999),
 (0,600,116,'0',1,'2',29999),
 (30000,601,116,'30',2,'54',54999),
 (55000,602,116,'550',3,'734',73499),
 (73500,603,116,'7350',4,'7499',74999),
 (75000,604,116,'7500',4,'9999',99999),
 (0,605,117,'0',1,'6',69999),
 (70000,606,117,'70',2,'94',94999),
 (95000,607,117,'950',3,'999',99999),
 (0,608,118,'00',2,'39',39999),
 (40000,609,118,'400',3,'899',89999),
 (90000,610,118,'9000',4,'9999',99999),
 (0,611,119,'000',3,'149',14999),
 (15000,612,119,'1500',4,'1999',19999),
 (20000,613,119,'20',2,'69',69999),
 (70000,614,119,'7000',4,'7499',74999),
 (75000,615,119,'750',3,'959',95999),
 (96000,616,119,'9600',4,'9999',99999),
 (0,617,120,'00',2,'39',39999),
 (40000,618,120,'400',3,'899',89999),
 (90000,619,120,'9000',4,'9999',99999),
 (0,620,121,'00',2,'49',49999),
 (50000,621,121,'500',3,'939',93999),
 (94000,622,121,'9400',4,'9999',99999),
 (0,623,122,'00',2,'39',39999),
 (40000,624,122,'400',3,'899',89999),
 (90000,625,122,'9000',4,'9999',99999),
 (0,626,123,'0',1,'5',59999),
 (60000,627,123,'60',2,'89',89999),
 (90000,628,123,'900',3,'989',98999),
 (99000,629,123,'9900',4,'9999',99999),
 (0,630,124,'00',2,'09',9999),
 (10000,631,124,'1',1,'1',19999),
 (20000,632,124,'200',3,'249',24999),
 (25000,633,124,'2500',4,'2999',29999),
 (30000,634,124,'30',2,'59',59999),
 (60000,635,124,'600',3,'899',89999),
 (90000,636,124,'9000',4,'9999',99999),
 (0,637,125,'00',2,'05',5999),
 (6000,638,125,'060',3,'089',8999),
 (9000,639,125,'0900',4,'0999',9999),
 (10000,640,125,'10',2,'69',69999),
 (70000,641,125,'700',3,'969',96999),
 (97000,642,125,'9700',4,'9999',99999),
 (0,643,126,'0',1,'2',29999),
 (30000,644,126,'30',2,'54',54999),
 (55000,645,126,'550',3,'749',74999),
 (75000,646,126,'7500',4,'9499',94999),
 (95000,647,126,'95',2,'99',99999),
 (0,648,127,'0',1,'0',9999),
 (10000,649,127,'100',3,'399',39999),
 (40000,650,127,'4000',4,'4499',44999),
 (45000,651,127,'45',2,'89',89999),
 (90000,652,127,'900',3,'949',94999),
 (95000,653,127,'9500',4,'9999',99999),
 (0,654,128,'0',1,'5',59999),
 (60000,655,128,'60',2,'89',89999),
 (90000,656,128,'900',3,'989',98999),
 (99000,657,128,'9900',4,'9999',99999),
 (0,658,129,'00',2,'89',89999),
 (90000,659,129,'900',3,'989',98999),
 (99000,660,129,'9900',4,'9999',99999),
 (0,661,130,'00',2,'29',29999),
 (30000,662,130,'300',3,'399',39999),
 (40000,663,130,'40',2,'94',94999),
 (95000,664,130,'950',3,'989',98999),
 (99000,665,130,'9900',4,'9999',99999),
 (0,666,131,'0',1,'4',49999),
 (50000,667,131,'50',2,'64',64999),
 (65000,668,131,'650',3,'659',65999),
 (66000,669,131,'66',2,'75',75999),
 (76000,670,131,'760',3,'899',89999),
 (90000,671,131,'9000',4,'9999',99999),
 (0,672,132,'0',1,'3',39999),
 (40000,673,132,'40',2,'89',89999),
 (90000,674,132,'900',3,'989',98999),
 (99000,675,132,'9900',4,'9999',99999),
 (0,676,133,'00',2,'09',9999),
 (10000,677,133,'100',3,'159',15999),
 (16000,678,133,'1600',4,'1999',19999),
 (20000,679,133,'20',2,'79',79999),
 (80000,680,133,'800',3,'949',94999),
 (95000,681,133,'9500',4,'9999',99999),
 (0,682,134,'00',2,'79',79999),
 (80000,683,134,'800',3,'989',98999),
 (99000,684,134,'9900',4,'9999',99999),
 (80000,685,135,'80',2,'94',94999),
 (95000,686,135,'950',3,'989',98999),
 (99000,687,135,'9900',4,'9999',99999),
 (0,688,136,'00',2,'49',49999),
 (50000,689,136,'500',3,'899',89999),
 (90000,690,136,'9000',4,'9999',99999),
 (0,691,137,'0',1,'4',49999),
 (50000,692,137,'50',2,'79',79999),
 (80000,693,137,'800',3,'899',89999),
 (90000,694,137,'9000',4,'9999',99999),
 (0,695,138,'00',2,'39',39999),
 (40000,696,138,'400',3,'899',89999),
 (90000,697,138,'9000',4,'9399',93999),
 (94000,698,138,'940',3,'969',96999),
 (97000,699,138,'97',2,'99',99999),
 (0,700,139,'00',2,'39',39999),
 (40000,701,139,'400',3,'879',87999),
 (88000,702,139,'8800',4,'9999',99999),
 (0,703,140,'0',1,'2',29999),
 (30000,704,140,'30',2,'54',54999),
 (55000,705,140,'550',3,'749',74999),
 (75000,706,140,'7500',4,'9999',99999),
 (0,707,141,'0',1,'0',9999),
 (10000,708,141,'100',3,'199',19999),
 (20000,709,141,'2000',4,'2999',29999),
 (30000,710,141,'30',2,'59',59999),
 (60000,711,141,'600',3,'949',94999),
 (95000,712,141,'9500',4,'9999',99999),
 (0,713,142,'00',2,'49',49999),
 (50000,714,142,'500',3,'799',79999),
 (80000,715,142,'80',2,'99',99999),
 (0,716,144,'0',1,'1',19999),
 (20000,717,144,'20',2,'89',89999),
 (90000,718,144,'900',3,'999',99999),
 (0,719,145,'0',1,'5',59999),
 (60000,720,145,'60',2,'89',89999),
 (90000,721,145,'900',3,'999',99999),
 (0,722,146,'0',1,'3',39999),
 (40000,723,146,'40',2,'79',79999),
 (80000,724,146,'800',3,'999',99999),
 (0,725,147,'0',1,'2',29999),
 (30000,726,147,'30',2,'59',59999),
 (60000,727,147,'600',3,'699',69999),
 (70000,728,147,'70',2,'89',89999),
 (90000,729,147,'90',2,'94',94999),
 (95000,730,147,'950',3,'999',99999),
 (0,731,148,'0',1,'0',9999),
 (10000,732,148,'10',2,'89',89999),
 (90000,733,148,'900',3,'999',99999),
 (0,734,149,'0',1,'3',39999),
 (40000,735,149,'40',2,'94',94999),
 (95000,736,149,'950',3,'999',99999),
 (0,737,150,'0',1,'2',29999),
 (30000,738,150,'30',2,'89',89999),
 (90000,739,150,'900',3,'999',99999),
 (0,740,151,'00',2,'59',59999),
 (60000,741,151,'600',3,'999',99999),
 (0,742,152,'0',1,'3',39999),
 (40000,743,152,'400',3,'599',59999),
 (60000,744,152,'60',2,'89',89999),
 (90000,745,152,'900',3,'999',99999),
 (0,746,153,'0',1,'2',29999),
 (30000,747,153,'30',2,'35',35999),
 (60000,748,153,'600',3,'604',60499),
 (0,749,154,'0',1,'4',49999),
 (50000,750,154,'50',2,'89',89999),
 (90000,751,154,'900',3,'999',99999),
 (0,752,155,'0',1,'4',49999),
 (50000,753,155,'50',2,'79',79999),
 (80000,754,155,'800',3,'999',99999),
 (0,755,156,'0',1,'2',29999),
 (30000,756,156,'30',2,'69',69999),
 (70000,757,156,'700',3,'999',99999),
 (0,758,157,'0',1,'2',29999),
 (30000,759,157,'30',2,'89',89999),
 (90000,760,157,'900',3,'999',99999),
 (0,761,158,'0',1,'3',39999),
 (40000,762,158,'40',2,'79',79999),
 (80000,763,158,'800',3,'999',99999),
 (0,764,159,'0',1,'2',29999),
 (30000,765,159,'300',3,'399',39999),
 (40000,766,159,'40',2,'69',69999),
 (90000,767,159,'900',3,'999',99999),
 (0,768,160,'0',1,'4',49999),
 (50000,769,160,'50',2,'89',89999),
 (90000,770,160,'900',3,'999',99999),
 (0,771,161,'0',1,'1',19999),
 (20000,772,161,'20',2,'69',69999),
 (70000,773,161,'700',3,'799',79999),
 (80000,774,161,'8',1,'8',89999),
 (90000,775,161,'90',2,'99',99999),
 (0,776,162,'0',1,'3',39999),
 (40000,777,162,'40',2,'69',69999),
 (70000,778,162,'700',3,'999',99999),
 (0,779,163,'0',1,'1',19999),
 (20000,780,163,'20',2,'79',79999),
 (80000,781,163,'800',3,'999',99999),
 (0,782,164,'0',1,'1',19999),
 (20000,783,164,'20',2,'79',79999),
 (80000,784,164,'800',3,'999',99999),
 (0,785,165,'0',1,'3',39999),
 (40000,786,165,'40',2,'79',79999),
 (80000,787,165,'800',3,'999',99999),
 (0,788,166,'0',1,'0',9999),
 (10000,789,166,'10',2,'59',59999),
 (60000,790,166,'600',3,'999',99999),
 (0,791,167,'0',1,'2',29999),
 (30000,792,167,'30',2,'59',59999),
 (60000,793,167,'600',3,'999',99999),
 (0,794,168,'0',1,'0',9999),
 (10000,795,168,'10',2,'79',79999),
 (80000,796,168,'800',3,'999',99999),
 (0,797,169,'0',1,'4',49999),
 (50000,798,169,'50',2,'79',79999),
 (80000,799,169,'800',3,'999',99999),
 (0,800,170,'0',1,'4',49999),
 (50000,801,170,'50',2,'79',79999),
 (80000,802,170,'800',3,'999',99999),
 (0,803,171,'0',1,'4',49999),
 (50000,804,171,'50',2,'79',79999),
 (80000,805,171,'800',3,'999',99999),
 (0,806,172,'0',1,'0',9999),
 (10000,807,172,'10',2,'59',59999),
 (60000,808,172,'600',3,'699',69999),
 (70000,809,172,'7',1,'7',79999),
 (80000,810,172,'80',2,'99',99999),
 (0,811,173,'0',1,'2',29999),
 (30000,812,173,'30',2,'59',59999),
 (60000,813,173,'600',3,'999',99999),
 (0,814,174,'0',1,'1',19999),
 (20000,815,174,'20',2,'79',79999),
 (80000,816,174,'800',3,'999',99999),
 (0,817,175,'0',1,'2',29999),
 (30000,818,175,'30',2,'59',59999),
 (60000,819,175,'600',3,'699',69999),
 (70000,820,175,'7',1,'8',89999),
 (90000,821,175,'90',2,'99',99999),
 (0,822,176,'0',1,'0',9999),
 (10000,823,176,'10',2,'59',59999),
 (60000,824,176,'600',3,'999',99999),
 (0,825,177,'0',1,'1',19999),
 (20000,826,177,'20',2,'59',59999),
 (60000,827,177,'600',3,'999',99999),
 (0,828,178,'0',1,'1',19999),
 (20000,829,178,'20',2,'59',59999),
 (60000,830,178,'600',3,'899',89999),
 (90000,831,178,'90',2,'99',99999),
 (0,832,179,'0',1,'5',59999),
 (60000,833,179,'60',2,'89',89999),
 (90000,834,179,'900',3,'999',99999),
 (0,835,180,'0',1,'0',9999),
 (10000,836,180,'10',2,'69',69999),
 (70000,837,180,'700',3,'999',99999),
 (0,838,181,'0',1,'2',29999),
 (30000,839,181,'30',2,'79',79999),
 (80000,840,181,'800',3,'999',99999),
 (0,841,182,'0',1,'4',49999),
 (50000,842,182,'50',2,'79',79999),
 (80000,843,182,'800',3,'999',99999),
 (0,844,183,'0',1,'2',29999),
 (30000,845,183,'30',2,'59',59999),
 (60000,846,183,'600',3,'999',99999),
 (0,847,184,'0',1,'4',49999),
 (50000,848,184,'50',2,'79',79999),
 (80000,849,184,'800',3,'999',99999),
 (0,850,185,'0',1,'5',59999),
 (60000,851,185,'60',2,'89',89999),
 (90000,852,185,'900',3,'999',99999),
 (0,853,186,'0',1,'2',29999),
 (30000,854,186,'30',2,'59',59999),
 (60000,855,186,'600',3,'999',99999),
 (0,856,187,'0',1,'2',29999),
 (30000,857,187,'30',2,'69',69999),
 (70000,858,187,'700',3,'999',99999),
 (0,859,188,'0',1,'4',49999),
 (50000,860,188,'50',2,'79',79999),
 (80000,861,188,'800',3,'999',99999),
 (0,862,189,'0',1,'1',19999),
 (20000,863,189,'20',2,'89',89999),
 (90000,864,189,'900',3,'999',99999),
 (0,865,190,'0',1,'4',49999),
 (50000,866,190,'50',2,'79',79999),
 (80000,867,190,'800',3,'999',99999),
 (0,868,192,'0',1,'4',49999),
 (50000,869,192,'50',2,'79',79999),
 (80000,870,192,'800',3,'999',99999),
 (0,871,193,'0',1,'2',29999),
 (30000,872,193,'30',2,'79',79999),
 (80000,873,193,'800',3,'939',93999),
 (94000,874,193,'94',2,'99',99999),
 (0,875,194,'0',1,'2',29999),
 (30000,876,194,'30',2,'69',69999),
 (70000,877,194,'700',3,'999',99999),
 (0,878,195,'0',1,'1',19999),
 (20000,879,195,'20',2,'59',59999),
 (60000,880,195,'600',3,'799',79999),
 (80000,881,195,'80',2,'89',89999),
 (90000,882,195,'90',2,'99',99999),
 (0,883,196,'00',2,'59',59999),
 (60000,884,196,'600',3,'859',85999),
 (86000,885,196,'86',2,'99',99999),
 (0,886,197,'0',1,'1',19999),
 (20000,887,197,'20',2,'79',79999),
 (80000,888,197,'800',3,'999',99999),
 (0,889,198,'0',1,'4',49999),
 (50000,890,198,'50',2,'94',94999),
 (95000,891,198,'950',3,'999',99999),
 (0,892,199,'0',1,'2',29999),
 (30000,893,199,'30',2,'59',59999),
 (60000,894,199,'600',3,'999',99999),
 (0,895,200,'0',1,'0',9999),
 (10000,896,200,'10',2,'94',94999),
 (95000,897,200,'950',3,'999',99999),
 (0,898,201,'0',1,'3',39999),
 (40000,899,201,'40',2,'89',89999),
 (90000,900,201,'900',3,'999',99999),
 (0,901,202,'0',1,'4',49999),
 (50000,902,202,'50',2,'79',79999),
 (80000,903,202,'800',3,'999',99999),
 (0,904,203,'00',2,'49',49999),
 (50000,905,203,'500',3,'999',99999),
 (0,906,204,'0',1,'1',19999),
 (20000,907,204,'20',2,'79',79999),
 (80000,908,204,'800',3,'999',99999),
 (0,909,205,'0',1,'3',39999),
 (40000,910,205,'40',2,'79',79999),
 (80000,911,205,'800',3,'999',99999),
 (0,912,206,'0',1,'2',29999),
 (30000,913,206,'30',2,'69',69999),
 (70000,914,206,'700',3,'799',79999),
 (0,915,207,'0',1,'1',19999),
 (20000,916,207,'20',2,'59',59999),
 (60000,917,207,'600',3,'899',89999),
 (0,918,208,'0',1,'3',39999),
 (40000,919,208,'400',3,'599',59999),
 (60000,920,208,'60',2,'89',89999),
 (90000,921,208,'900',3,'999',99999),
 (0,922,209,'00',2,'19',19999),
 (20000,923,209,'200',3,'699',69999),
 (70000,924,209,'7000',4,'8999',89999),
 (90000,925,209,'90000',5,'97599',97599),
 (97600,926,209,'976000',6,'999999',99999);
/*!40000 ALTER TABLE `ezisbn_registrant_range` ENABLE KEYS */;


--
-- Dumping data for table `ezkeyword`
--

/*!40000 ALTER TABLE `ezkeyword` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezkeyword` ENABLE KEYS */;


--
-- Dumping data for table `ezkeyword_attribute_link`
--

/*!40000 ALTER TABLE `ezkeyword_attribute_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezkeyword_attribute_link` ENABLE KEYS */;


--
-- Dumping data for table `ezm_block`
--

/*!40000 ALTER TABLE `ezm_block` DISABLE KEYS */;
INSERT INTO `ezm_block` (`id`,`zone_id`,`name`,`node_id`,`overflow_id`,`last_update`,`block_type`,`fetch_params`,`rotation_type`,`rotation_interval`,`is_removed`) VALUES 
 ('21446f4f233f3d5ca6b9072d03c60a40','4f6d946ab48d95799d31179c3acde8cb','Transparent',2,'',0,'astTransparentBanner','',0,0,0),
 ('39f4886bbe6d162c01ab77b65b96ba2a','4f6d946ab48d95799d31179c3acde8cb','Qui sommes nous',2,'',0,'NounoursEdito','',0,0,0),
 ('480655c28ee1aa2f14d76639cd774cfa','164b072e900f76653995211929541301','Où nous trouver',2,'',0,'GMap','',0,0,0),
 ('5201665176b2455e198b34425ec20cc6','038ffb3d0c9ba2a8dc1ecc6c3e6ea86d','Promotions2',2,'',0,'NounoursPromotion','',0,0,0),
 ('dc32434bab785565f942f4100be260f2','a1117aa7fd4548568490cc7ab1271a4b','Promotion1',2,'',0,'NounoursPromotion','',0,0,0);
/*!40000 ALTER TABLE `ezm_block` ENABLE KEYS */;


--
-- Dumping data for table `ezm_pool`
--

/*!40000 ALTER TABLE `ezm_pool` DISABLE KEYS */;
INSERT INTO `ezm_pool` (`block_id`,`object_id`,`node_id`,`priority`,`ts_publication`,`ts_visible`,`ts_hidden`,`rotation_until`,`moved_to`) VALUES 
 ('21446f4f233f3d5ca6b9072d03c60a40',74,74,1,1307017792,1307017807,0,0,NULL),
 ('5201665176b2455e198b34425ec20cc6',64,66,3,1305979282,1305979283,0,0,NULL),
 ('5201665176b2455e198b34425ec20cc6',65,67,4,1305979282,1305979283,0,0,NULL),
 ('5201665176b2455e198b34425ec20cc6',66,68,5,1305979282,1305979283,0,0,NULL),
 ('5201665176b2455e198b34425ec20cc6',67,69,0,1305979270,1305979283,1305979283,0,NULL),
 ('5201665176b2455e198b34425ec20cc6',68,70,0,1305979270,1305979283,1305979283,0,NULL),
 ('dc32434bab785565f942f4100be260f2',64,66,1,1305979244,1305979283,0,0,NULL),
 ('dc32434bab785565f942f4100be260f2',65,67,2,1305979244,1305979283,0,0,NULL),
 ('dc32434bab785565f942f4100be260f2',66,68,3,1305979244,1305979283,0,0,NULL);
/*!40000 ALTER TABLE `ezm_pool` ENABLE KEYS */;


--
-- Dumping data for table `ezmedia`
--

/*!40000 ALTER TABLE `ezmedia` DISABLE KEYS */;
INSERT INTO `ezmedia` (`contentobject_attribute_id`,`controls`,`filename`,`has_controller`,`height`,`is_autoplay`,`is_loop`,`mime_type`,`original_filename`,`pluginspage`,`quality`,`version`,`width`) VALUES 
 (369,'','f14e6944b471451ce8d2b800613c5347.swf',0,800,0,0,'application/x-shockwave-flash','banniere.swf','http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash','high',1,600),
 (369,'','f14e6944b471451ce8d2b800613c5347.swf',0,600,0,0,'application/x-shockwave-flash','banniere.swf','http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash','high',2,800);
/*!40000 ALTER TABLE `ezmedia` ENABLE KEYS */;


--
-- Dumping data for table `ezmessage`
--

/*!40000 ALTER TABLE `ezmessage` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezmessage` ENABLE KEYS */;


--
-- Dumping data for table `ezmodule_run`
--

/*!40000 ALTER TABLE `ezmodule_run` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezmodule_run` ENABLE KEYS */;


--
-- Dumping data for table `ezmultipricedata`
--

/*!40000 ALTER TABLE `ezmultipricedata` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezmultipricedata` ENABLE KEYS */;


--
-- Dumping data for table `eznode_assignment`
--

/*!40000 ALTER TABLE `eznode_assignment` DISABLE KEYS */;
INSERT INTO `eznode_assignment` (`contentobject_id`,`contentobject_version`,`from_node_id`,`id`,`is_main`,`op_code`,`parent_node`,`parent_remote_id`,`remote_id`,`sort_field`,`sort_order`) VALUES 
 (8,2,0,4,1,2,5,'',0,1,1),
 (42,1,0,5,1,2,5,'',0,9,1),
 (10,2,-1,6,1,2,44,'',0,9,1),
 (4,1,0,7,1,2,1,'',0,1,1),
 (12,1,0,8,1,2,5,'',0,1,1),
 (13,1,0,9,1,2,5,'',0,1,1),
 (41,1,0,11,1,2,1,'',0,1,1),
 (11,1,0,12,1,2,5,'',0,1,1),
 (45,1,-1,16,1,2,1,'',0,9,1),
 (49,1,0,27,1,2,43,'',0,9,1),
 (50,1,0,28,1,2,43,'',0,9,1),
 (51,1,0,29,1,2,43,'',0,9,1),
 (52,1,0,30,1,2,48,'',0,1,1),
 (56,1,0,34,1,2,1,'',0,2,0),
 (14,3,-1,38,1,2,13,'',0,1,1),
 (54,2,-1,39,1,2,58,'',0,1,1),
 (14,4,-1,44,1,2,13,'',0,1,1),
 (58,1,0,45,1,2,5,'',0,1,1),
 (11,2,-1,46,1,2,5,'',0,1,1),
 (59,1,0,47,1,2,2,'',0,1,1),
 (61,1,0,49,1,2,2,'',0,1,1),
 (62,1,0,50,1,2,2,'',0,1,1),
 (63,1,0,51,1,2,2,'',0,1,1),
 (64,1,0,52,1,2,61,'',0,1,1),
 (65,1,0,53,1,2,61,'',0,1,1),
 (66,1,0,54,1,2,61,'',0,1,1),
 (64,2,-1,55,1,2,61,'',0,1,1),
 (67,1,0,56,1,2,64,'',0,1,1),
 (68,1,0,57,1,2,64,'',0,1,1),
 (57,3,-1,59,1,2,1,'',0,8,1),
 (57,4,-1,60,1,2,1,'',0,8,1),
 (57,5,-1,61,1,2,1,'',0,8,1),
 (57,6,-1,62,1,2,1,'',0,8,1),
 (57,7,-1,63,1,2,1,'',0,8,1),
 (57,8,-1,64,1,2,1,'',0,8,1),
 (57,9,-1,65,1,2,1,'',0,8,1),
 (66,2,-1,66,1,2,61,'',0,1,1),
 (70,1,0,68,1,2,2,'',0,1,1),
 (57,10,-1,69,1,2,1,'',0,8,1),
 (71,1,0,70,1,2,2,'',0,1,1),
 (73,1,0,72,1,2,2,'',0,1,1),
 (73,2,-1,73,1,2,2,'',0,1,1),
 (73,3,-1,74,1,2,2,'',0,1,1),
 (73,4,-1,75,1,2,2,'',0,1,1),
 (73,5,-1,76,1,2,2,'',0,1,1),
 (57,11,-1,77,1,2,1,'',0,8,1),
 (57,12,-1,78,1,2,1,'',0,8,1),
 (74,1,0,79,1,2,53,'',0,1,1),
 (74,2,-1,80,1,2,53,'',0,1,1);
/*!40000 ALTER TABLE `eznode_assignment` ENABLE KEYS */;


--
-- Dumping data for table `eznotificationcollection`
--

/*!40000 ALTER TABLE `eznotificationcollection` DISABLE KEYS */;
/*!40000 ALTER TABLE `eznotificationcollection` ENABLE KEYS */;


--
-- Dumping data for table `eznotificationcollection_item`
--

/*!40000 ALTER TABLE `eznotificationcollection_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `eznotificationcollection_item` ENABLE KEYS */;


--
-- Dumping data for table `eznotificationevent`
--

/*!40000 ALTER TABLE `eznotificationevent` DISABLE KEYS */;
INSERT INTO `eznotificationevent` (`data_int1`,`data_int2`,`data_int3`,`data_int4`,`data_text1`,`data_text2`,`data_text3`,`data_text4`,`event_type_string`,`id`,`status`) VALUES 
 (57,1,0,0,'','','','','ezpublish',1,0),
 (14,4,0,0,'','','','','ezpublish',2,0),
 (58,1,0,0,'','','','','ezpublish',3,0),
 (11,2,0,0,'','','','','ezpublish',4,0),
 (59,1,0,0,'','','','','ezpublish',5,0),
 (60,1,0,0,'','','','','ezpublish',6,0),
 (61,1,0,0,'','','','','ezpublish',7,0),
 (62,1,0,0,'','','','','ezpublish',8,0),
 (63,1,0,0,'','','','','ezpublish',9,0),
 (64,1,0,0,'','','','','ezpublish',10,0),
 (65,1,0,0,'','','','','ezpublish',11,0),
 (66,1,0,0,'','','','','ezpublish',12,0),
 (64,2,0,0,'','','','','ezpublish',13,0),
 (67,1,0,0,'','','','','ezpublish',14,0),
 (68,1,0,0,'','','','','ezpublish',15,0),
 (57,2,0,0,'','','','','ezpublish',16,0),
 (57,3,0,0,'','','','','ezpublish',17,0),
 (57,4,0,0,'','','','','ezpublish',18,0),
 (57,5,0,0,'','','','','ezpublish',19,0),
 (57,6,0,0,'','','','','ezpublish',20,0),
 (57,7,0,0,'','','','','ezpublish',21,0),
 (57,8,0,0,'','','','','ezpublish',22,0),
 (57,9,0,0,'','','','','ezpublish',23,0),
 (66,2,0,0,'','','','','ezpublish',24,0),
 (70,1,0,0,'','','','','ezpublish',25,0),
 (57,10,0,0,'','','','','ezpublish',26,0),
 (71,1,0,0,'','','','','ezpublish',27,0),
 (73,1,0,0,'','','','','ezpublish',28,0),
 (73,2,0,0,'','','','','ezpublish',29,0),
 (73,3,0,0,'','','','','ezpublish',30,0),
 (73,4,0,0,'','','','','ezpublish',31,0),
 (73,5,0,0,'','','','','ezpublish',32,0),
 (57,11,0,0,'','','','','ezpublish',33,0),
 (74,1,0,0,'','','','','ezpublish',34,0),
 (74,2,0,0,'','','','','ezpublish',35,0),
 (57,12,0,0,'','','','','ezpublish',36,0);
/*!40000 ALTER TABLE `eznotificationevent` ENABLE KEYS */;


--
-- Dumping data for table `ezoperation_memento`
--

/*!40000 ALTER TABLE `ezoperation_memento` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezoperation_memento` ENABLE KEYS */;


--
-- Dumping data for table `ezorder`
--

/*!40000 ALTER TABLE `ezorder` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezorder` ENABLE KEYS */;


--
-- Dumping data for table `ezorder_item`
--

/*!40000 ALTER TABLE `ezorder_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezorder_item` ENABLE KEYS */;


--
-- Dumping data for table `ezorder_nr_incr`
--

/*!40000 ALTER TABLE `ezorder_nr_incr` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezorder_nr_incr` ENABLE KEYS */;


--
-- Dumping data for table `ezorder_status`
--

/*!40000 ALTER TABLE `ezorder_status` DISABLE KEYS */;
INSERT INTO `ezorder_status` (`id`,`is_active`,`name`,`status_id`) VALUES 
 (1,1,'Pending',1),
 (2,1,'Processing',2),
 (3,1,'Delivered',3);
/*!40000 ALTER TABLE `ezorder_status` ENABLE KEYS */;


--
-- Dumping data for table `ezorder_status_history`
--

/*!40000 ALTER TABLE `ezorder_status_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezorder_status_history` ENABLE KEYS */;


--
-- Dumping data for table `ezpackage`
--

/*!40000 ALTER TABLE `ezpackage` DISABLE KEYS */;
INSERT INTO `ezpackage` (`id`,`install_date`,`name`,`version`) VALUES 
 (1,1301057838,'plain_site_data','1.0-1'),
 (2,1305866633,'ezwt_extension','1.4-0'),
 (3,1305866637,'ezstarrating_extension','1.3-0'),
 (4,1305866641,'ezgmaplocation_extension','1.3-0'),
 (5,1305866647,'ezwebin_extension','1.8-0'),
 (6,1305866654,'ezflow_extension','2.3-0'),
 (7,1305866659,'ezflow_classes','2.3-0'),
 (8,1305866662,'ezflow_democontent_clean','2.3-0');
/*!40000 ALTER TABLE `ezpackage` ENABLE KEYS */;


--
-- Dumping data for table `ezpaymentobject`
--

/*!40000 ALTER TABLE `ezpaymentobject` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezpaymentobject` ENABLE KEYS */;


--
-- Dumping data for table `ezpdf_export`
--

/*!40000 ALTER TABLE `ezpdf_export` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezpdf_export` ENABLE KEYS */;


--
-- Dumping data for table `ezpending_actions`
--

/*!40000 ALTER TABLE `ezpending_actions` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezpending_actions` ENABLE KEYS */;


--
-- Dumping data for table `ezpolicy`
--

/*!40000 ALTER TABLE `ezpolicy` DISABLE KEYS */;
INSERT INTO `ezpolicy` (`function_name`,`id`,`module_name`,`original_id`,`role_id`) VALUES 
 ('*',308,'*',0,2),
 ('login',319,'user',0,3),
 ('read',328,'content',0,1),
 ('pdf',329,'content',0,1),
 ('*',330,'ezoe',0,3),
 ('*',332,'ezoe',0,3),
 ('feed',333,'rss',0,1),
 ('login',334,'user',0,1),
 ('login',335,'user',0,1),
 ('login',336,'user',0,1),
 ('read',337,'content',0,1),
 ('create',338,'content',0,3),
 ('create',339,'content',0,3),
 ('create',340,'content',0,3),
 ('create',341,'content',0,3),
 ('create',342,'content',0,3),
 ('create',343,'content',0,3),
 ('use',344,'websitetoolbar',0,3),
 ('edit',345,'content',0,3),
 ('read',346,'content',0,3),
 ('use',347,'notification',0,3),
 ('manage_locations',348,'content',0,3),
 ('*',349,'ezodf',0,3),
 ('*',350,'ezflow',0,3),
 ('*',351,'ezajax',0,3),
 ('diff',352,'content',0,3),
 ('versionread',353,'content',0,3),
 ('versionremove',354,'content',0,3),
 ('remove',355,'content',0,3),
 ('translate',356,'content',0,3),
 ('feed',357,'rss',0,3),
 ('bookmark',358,'content',0,3),
 ('pendinglist',359,'content',0,3),
 ('dashboard',360,'content',0,3),
 ('view_embed',361,'content',0,3),
 ('read',362,'content',0,4),
 ('create',363,'content',0,4),
 ('create',364,'content',0,4),
 ('create',365,'content',0,4),
 ('edit',366,'content',0,4),
 ('selfedit',367,'user',0,4),
 ('use',368,'notification',0,4),
 ('create',369,'content',0,5),
 ('create',370,'content',0,5),
 ('create',371,'content',0,5),
 ('edit',372,'content',0,5),
 ('selfedit',373,'user',0,5),
 ('use',374,'notification',0,5),
 ('password',375,'user',0,5),
 ('call',376,'ezjscore',0,5);
/*!40000 ALTER TABLE `ezpolicy` ENABLE KEYS */;


--
-- Dumping data for table `ezpolicy_limitation`
--

/*!40000 ALTER TABLE `ezpolicy_limitation` DISABLE KEYS */;
INSERT INTO `ezpolicy_limitation` (`id`,`identifier`,`policy_id`) VALUES 
 (251,'Section',328),
 (252,'Section',329),
 (254,'SiteAccess',334),
 (255,'SiteAccess',335),
 (256,'SiteAccess',336),
 (257,'Class',337),
 (258,'Section',337),
 (259,'Class',338),
 (260,'ParentClass',338),
 (261,'Class',339),
 (262,'ParentClass',339),
 (263,'Class',340),
 (264,'ParentClass',340),
 (265,'Class',341),
 (266,'ParentClass',341),
 (267,'Class',342),
 (268,'ParentClass',342),
 (269,'Class',343),
 (270,'ParentClass',343),
 (271,'Class',344),
 (272,'Section',346),
 (273,'Section',362),
 (274,'Class',363),
 (275,'Section',363),
 (276,'ParentClass',363),
 (277,'Class',364),
 (278,'Section',364),
 (279,'ParentClass',364),
 (280,'Class',365),
 (281,'Section',365),
 (282,'ParentClass',365),
 (283,'Class',366),
 (284,'Section',366),
 (285,'Owner',366),
 (286,'Class',369),
 (287,'Section',369),
 (288,'ParentClass',369),
 (289,'Class',370),
 (290,'Section',370),
 (291,'ParentClass',370),
 (292,'Class',371),
 (293,'Section',371),
 (294,'ParentClass',371),
 (295,'Class',372),
 (296,'Section',372),
 (297,'Owner',372);
/*!40000 ALTER TABLE `ezpolicy_limitation` ENABLE KEYS */;


--
-- Dumping data for table `ezpolicy_limitation_value`
--

/*!40000 ALTER TABLE `ezpolicy_limitation_value` DISABLE KEYS */;
INSERT INTO `ezpolicy_limitation_value` (`id`,`limitation_id`,`value`) VALUES 
 (477,251,'1'),
 (478,252,'1'),
 (480,254,'2597280906'),
 (481,255,'2479546403'),
 (482,256,'475308017'),
 (483,257,'33'),
 (484,257,'45'),
 (485,257,'29'),
 (486,257,'37'),
 (487,257,'36'),
 (488,257,'35'),
 (489,258,'3'),
 (490,259,'1'),
 (491,259,'34'),
 (492,259,'28'),
 (493,259,'21'),
 (494,259,'22'),
 (495,259,'23'),
 (496,259,'16'),
 (497,259,'17'),
 (498,259,'18'),
 (499,259,'19'),
 (500,259,'27'),
 (501,259,'26'),
 (502,259,'24'),
 (503,259,'25'),
 (504,259,'29'),
 (505,259,'35'),
 (506,259,'36'),
 (507,259,'37'),
 (508,259,'38'),
 (509,259,'40'),
 (510,259,'46'),
 (511,259,'44'),
 (512,259,'45'),
 (513,259,'33'),
 (514,260,'1'),
 (515,261,'20'),
 (516,262,'19'),
 (517,263,'41'),
 (518,264,'40'),
 (519,265,'43'),
 (520,266,'44'),
 (521,267,'33'),
 (522,268,'38'),
 (523,269,'1'),
 (524,269,'34'),
 (525,269,'22'),
 (526,269,'23'),
 (527,269,'24'),
 (528,269,'38'),
 (529,269,'44'),
 (530,269,'26'),
 (531,269,'46'),
 (532,270,'23'),
 (533,271,'1'),
 (534,271,'34'),
 (535,271,'16'),
 (536,271,'17'),
 (537,271,'18'),
 (538,271,'19'),
 (539,271,'20'),
 (540,271,'21'),
 (541,271,'22'),
 (542,271,'23'),
 (543,271,'24'),
 (544,271,'26'),
 (545,271,'27'),
 (546,271,'28'),
 (547,271,'29'),
 (548,271,'33'),
 (549,271,'35'),
 (550,271,'36'),
 (551,271,'37'),
 (552,271,'38'),
 (553,271,'40'),
 (554,271,'43'),
 (555,271,'44'),
 (556,271,'46'),
 (557,272,'1'),
 (558,272,'6'),
 (559,272,'3'),
 (560,273,'6'),
 (561,274,'41'),
 (562,275,'6'),
 (563,276,'40'),
 (564,277,'42'),
 (565,278,'6'),
 (566,279,'41'),
 (567,280,'13'),
 (568,281,'6'),
 (569,282,'16'),
 (570,283,'13'),
 (571,283,'41'),
 (572,283,'42'),
 (573,284,'6'),
 (574,285,'1'),
 (575,286,'41'),
 (576,287,'1'),
 (577,288,'40'),
 (578,289,'42'),
 (579,290,'1'),
 (580,291,'41'),
 (581,292,'13'),
 (582,293,'1'),
 (583,294,'16'),
 (584,294,'20'),
 (585,294,'17'),
 (586,295,'13'),
 (587,295,'41'),
 (588,295,'42'),
 (589,296,'1'),
 (590,297,'1');
/*!40000 ALTER TABLE `ezpolicy_limitation_value` ENABLE KEYS */;


--
-- Dumping data for table `ezpreferences`
--

/*!40000 ALTER TABLE `ezpreferences` DISABLE KEYS */;
INSERT INTO `ezpreferences` (`id`,`name`,`user_id`,`value`) VALUES 
 (1,'admin_navigation_content',14,'0'),
 (2,'admin_navigation_roles',14,'1'),
 (3,'admin_navigation_policies',14,'1'),
 (4,'admin_list_limit',14,'2'),
 (5,'admin_treemenu',14,'1'),
 (6,'admin_bookmark_menu',14,'1'),
 (7,'admin_right_menu_show',14,'1'),
 (8,'admin_clearcache_type',14,'All'),
 (9,'admin_left_menu_size',14,'19.69230769em'),
 (10,'admin_quicksettings_siteaccess',14,'global_override');
/*!40000 ALTER TABLE `ezpreferences` ENABLE KEYS */;


--
-- Dumping data for table `ezprest_authcode`
--

/*!40000 ALTER TABLE `ezprest_authcode` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezprest_authcode` ENABLE KEYS */;


--
-- Dumping data for table `ezprest_authorized_clients`
--

/*!40000 ALTER TABLE `ezprest_authorized_clients` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezprest_authorized_clients` ENABLE KEYS */;


--
-- Dumping data for table `ezprest_clients`
--

/*!40000 ALTER TABLE `ezprest_clients` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezprest_clients` ENABLE KEYS */;


--
-- Dumping data for table `ezprest_token`
--

/*!40000 ALTER TABLE `ezprest_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezprest_token` ENABLE KEYS */;


--
-- Dumping data for table `ezproductcategory`
--

/*!40000 ALTER TABLE `ezproductcategory` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezproductcategory` ENABLE KEYS */;


--
-- Dumping data for table `ezproductcollection`
--

/*!40000 ALTER TABLE `ezproductcollection` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezproductcollection` ENABLE KEYS */;


--
-- Dumping data for table `ezproductcollection_item`
--

/*!40000 ALTER TABLE `ezproductcollection_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezproductcollection_item` ENABLE KEYS */;


--
-- Dumping data for table `ezproductcollection_item_opt`
--

/*!40000 ALTER TABLE `ezproductcollection_item_opt` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezproductcollection_item_opt` ENABLE KEYS */;


--
-- Dumping data for table `ezpublishingqueueprocesses`
--

/*!40000 ALTER TABLE `ezpublishingqueueprocesses` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezpublishingqueueprocesses` ENABLE KEYS */;


--
-- Dumping data for table `ezrole`
--

/*!40000 ALTER TABLE `ezrole` DISABLE KEYS */;
INSERT INTO `ezrole` (`id`,`is_new`,`name`,`value`,`version`) VALUES 
 (1,0,'Anonymous','',0),
 (2,0,'Administrator','*',0),
 (3,0,'Editor','',0),
 (4,0,'Partner',NULL,0),
 (5,0,'Member',NULL,0);
/*!40000 ALTER TABLE `ezrole` ENABLE KEYS */;


--
-- Dumping data for table `ezrss_export`
--

/*!40000 ALTER TABLE `ezrss_export` DISABLE KEYS */;
INSERT INTO `ezrss_export` (`access_url`,`active`,`created`,`creator_id`,`description`,`id`,`image_id`,`main_node_only`,`modified`,`modifier_id`,`node_id`,`number_of_objects`,`rss_version`,`site_access`,`status`,`title`,`url`) VALUES 
 ('my_feed',1,1305866665,14,'',1,0,1,1305866665,14,0,10,'2.0','',1,'My RSS Feed','http://example.com');
/*!40000 ALTER TABLE `ezrss_export` ENABLE KEYS */;


--
-- Dumping data for table `ezrss_export_item`
--

/*!40000 ALTER TABLE `ezrss_export_item` DISABLE KEYS */;
INSERT INTO `ezrss_export_item` (`category`,`class_id`,`description`,`enclosure`,`id`,`rssexport_id`,`source_node_id`,`status`,`subnodes`,`title`) VALUES 
 ('',16,'intro','',1,1,139,1,0,'title');
/*!40000 ALTER TABLE `ezrss_export_item` ENABLE KEYS */;


--
-- Dumping data for table `ezrss_import`
--

/*!40000 ALTER TABLE `ezrss_import` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezrss_import` ENABLE KEYS */;


--
-- Dumping data for table `ezscheduled_script`
--

/*!40000 ALTER TABLE `ezscheduled_script` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezscheduled_script` ENABLE KEYS */;


--
-- Dumping data for table `ezsearch_object_word_link`
--

/*!40000 ALTER TABLE `ezsearch_object_word_link` DISABLE KEYS */;
INSERT INTO `ezsearch_object_word_link` (`contentclass_attribute_id`,`contentclass_id`,`contentobject_id`,`frequency`,`id`,`identifier`,`integer_value`,`next_word_id`,`placement`,`prev_word_id`,`published`,`section_id`,`word_id`) VALUES 
 (6,3,4,0,4663,'name',0,951,0,0,1033917596,2,930),
 (7,3,4,0,4664,'description',0,952,1,930,1033917596,2,951),
 (7,3,4,0,4665,'description',0,0,2,951,1033917596,2,952),
 (8,4,10,0,4666,'first_name',0,954,0,0,1033920665,2,953),
 (9,4,10,0,4667,'last_name',0,953,1,953,1033920665,2,954),
 (12,4,10,0,4668,'user_account',0,955,2,954,1033920665,2,953),
 (12,4,10,0,4669,'user_account',0,927,3,953,1033920665,2,955),
 (12,4,10,0,4670,'user_account',0,0,4,955,1033920665,2,927),
 (6,3,12,0,4673,'name',0,930,0,0,1033920775,2,958),
 (6,3,12,0,4674,'name',0,0,1,958,1033920775,2,930),
 (6,3,13,0,4675,'name',0,0,0,0,1033920794,2,959),
 (4,1,41,0,4681,'name',0,0,0,0,1060695457,3,961),
 (6,3,42,0,4682,'name',0,930,0,0,1072180330,2,953),
 (6,3,42,0,4683,'name',0,954,1,953,1072180330,2,930),
 (7,3,42,0,4684,'description',0,952,2,930,1072180330,2,954),
 (7,3,42,0,4685,'description',0,816,3,954,1072180330,2,952),
 (7,3,42,0,4686,'description',0,814,4,952,1072180330,2,816),
 (7,3,42,0,4687,'description',0,953,5,816,1072180330,2,814),
 (7,3,42,0,4688,'description',0,954,6,814,1072180330,2,953),
 (7,3,42,0,4689,'description',0,0,7,953,1072180330,2,954),
 (4,1,45,0,4690,'name',0,0,0,0,1079684190,4,812),
 (4,1,49,0,4691,'name',0,0,0,0,1080220197,3,962),
 (4,1,50,0,4692,'name',0,0,0,0,1080220220,3,963),
 (4,1,51,0,4693,'name',0,0,0,0,1080220233,3,964),
 (159,14,52,0,4694,'name',0,965,0,0,1082016591,4,877),
 (159,14,52,0,4695,'name',0,966,1,877,1082016591,4,965),
 (159,14,52,0,4696,'name',0,0,2,965,1082016591,4,966),
 (176,15,54,0,4697,'id',0,0,0,0,1082016652,5,967),
 (4,1,56,0,4698,'name',0,0,0,0,1103023132,5,968),
 (8,4,14,0,4700,'first_name',0,954,0,0,1033920830,2,958),
 (9,4,14,0,4701,'last_name',0,970,1,958,1033920830,2,954),
 (12,4,14,0,4702,'user_account',0,970,2,954,1033920830,2,970),
 (12,4,14,0,4703,'user_account',0,971,3,970,1033920830,2,970),
 (12,4,14,0,4704,'user_account',0,0,4,970,1033920830,2,971),
 (6,3,58,0,4705,'name',0,0,0,0,1305866665,1,972),
 (6,3,11,0,4706,'name',0,0,0,0,1033920746,2,973),
 (359,49,59,0,4707,'name',0,0,0,0,1305867225,1,974),
 (347,48,61,0,4709,'title',0,977,0,0,1305867313,1,976),
 (347,48,61,0,4710,'title',0,978,1,976,1305867313,1,977),
 (350,48,61,0,4711,'intro',0,979,2,977,1305867313,1,978),
 (355,48,61,0,4712,'publish_date',0,979,3,978,1305867313,1,979),
 (356,48,61,0,4713,'unpublish_date',0,0,4,979,1305867313,1,979),
 (359,49,62,0,4714,'name',0,0,0,0,1305867354,1,980),
 (347,48,63,0,4715,'title',0,982,0,0,1305867397,1,981),
 (347,48,63,0,4716,'title',0,978,1,981,1305867397,1,982),
 (350,48,63,0,4717,'intro',0,979,2,982,1305867397,1,978),
 (355,48,63,0,4718,'publish_date',0,979,3,978,1305867397,1,979),
 (356,48,63,0,4719,'unpublish_date',0,0,4,979,1305867397,1,979),
 (220,21,65,0,4749,'name',0,983,0,0,1305867483,1,981),
 (220,21,65,0,4750,'name',0,998,1,981,1305867483,1,983),
 (220,21,65,0,4751,'name',0,985,2,983,1305867483,1,998),
 (220,21,65,0,4752,'name',0,986,3,998,1305867483,1,985),
 (227,21,65,0,4753,'additional_options',0,987,4,985,1305867483,1,986),
 (227,21,65,0,4754,'additional_options',0,988,5,986,1305867483,1,987),
 (227,21,65,0,4755,'additional_options',0,989,6,987,1305867483,1,988),
 (227,21,65,0,4756,'additional_options',0,990,7,988,1305867483,1,989),
 (227,21,65,0,4757,'additional_options',0,991,8,989,1305867483,1,990),
 (227,21,65,0,4758,'additional_options',0,992,9,990,1305867483,1,991),
 (227,21,65,0,4759,'additional_options',0,993,10,991,1305867483,1,992),
 (227,21,65,0,4760,'additional_options',0,986,11,992,1305867483,1,993),
 (227,21,65,0,4761,'additional_options',0,994,12,993,1305867483,1,986),
 (227,21,65,0,4762,'additional_options',0,995,13,986,1305867483,1,994),
 (227,21,65,0,4763,'additional_options',0,979,14,994,1305867483,1,995),
 (227,21,65,0,4764,'additional_options',0,993,15,995,1305867483,1,979),
 (227,21,65,0,4765,'additional_options',0,986,16,979,1305867483,1,993),
 (227,21,65,0,4766,'additional_options',0,996,17,993,1305867483,1,986),
 (227,21,65,0,4767,'additional_options',0,993,18,986,1305867483,1,996),
 (227,21,65,0,4768,'additional_options',0,986,19,996,1305867483,1,993),
 (227,21,65,0,4769,'additional_options',0,996,20,993,1305867483,1,986),
 (227,21,65,0,4770,'additional_options',0,993,21,986,1305867483,1,996),
 (227,21,65,0,4771,'additional_options',0,986,22,996,1305867483,1,993),
 (227,21,65,0,4772,'additional_options',0,997,23,993,1305867483,1,986),
 (227,21,65,0,4773,'additional_options',0,993,24,986,1305867483,1,997),
 (227,21,65,0,4774,'additional_options',0,986,25,997,1305867483,1,993),
 (227,21,65,0,4775,'additional_options',0,994,26,993,1305867483,1,986),
 (227,21,65,0,4776,'additional_options',0,993,27,986,1305867483,1,994),
 (227,21,65,0,4777,'additional_options',0,0,28,994,1305867483,1,993),
 (220,21,64,0,4807,'name',0,983,0,0,1305867455,1,981),
 (220,21,64,0,4808,'name',0,1001,1,981,1305867455,1,983),
 (220,21,64,0,4809,'name',0,985,2,983,1305867455,1,1001),
 (220,21,64,0,4810,'name',0,986,3,1001,1305867455,1,985),
 (227,21,64,0,4811,'additional_options',0,987,4,985,1305867455,1,986),
 (227,21,64,0,4812,'additional_options',0,988,5,986,1305867455,1,987),
 (227,21,64,0,4813,'additional_options',0,989,6,987,1305867455,1,988),
 (227,21,64,0,4814,'additional_options',0,990,7,988,1305867455,1,989),
 (227,21,64,0,4815,'additional_options',0,991,8,989,1305867455,1,990),
 (227,21,64,0,4816,'additional_options',0,992,9,990,1305867455,1,991),
 (227,21,64,0,4817,'additional_options',0,993,10,991,1305867455,1,992),
 (227,21,64,0,4818,'additional_options',0,986,11,992,1305867455,1,993),
 (227,21,64,0,4819,'additional_options',0,994,12,993,1305867455,1,986),
 (227,21,64,0,4820,'additional_options',0,995,13,986,1305867455,1,994),
 (227,21,64,0,4821,'additional_options',0,979,14,994,1305867455,1,995),
 (227,21,64,0,4822,'additional_options',0,993,15,995,1305867455,1,979),
 (227,21,64,0,4823,'additional_options',0,986,16,979,1305867455,1,993),
 (227,21,64,0,4824,'additional_options',0,996,17,993,1305867455,1,986),
 (227,21,64,0,4825,'additional_options',0,993,18,986,1305867455,1,996),
 (227,21,64,0,4826,'additional_options',0,986,19,996,1305867455,1,993),
 (227,21,64,0,4827,'additional_options',0,996,20,993,1305867455,1,986),
 (227,21,64,0,4828,'additional_options',0,993,21,986,1305867455,1,996),
 (227,21,64,0,4829,'additional_options',0,986,22,996,1305867455,1,993),
 (227,21,64,0,4830,'additional_options',0,997,23,993,1305867455,1,986),
 (227,21,64,0,4831,'additional_options',0,993,24,986,1305867455,1,997),
 (227,21,64,0,4832,'additional_options',0,986,25,997,1305867455,1,993),
 (227,21,64,0,4833,'additional_options',0,994,26,993,1305867455,1,986),
 (227,21,64,0,4834,'additional_options',0,993,27,986,1305867455,1,994),
 (227,21,64,0,4835,'additional_options',0,0,28,994,1305867455,1,993),
 (220,21,67,0,4836,'name',0,986,0,0,1305867702,1,1002),
 (227,21,67,0,4837,'additional_options',0,987,1,1002,1305867702,1,986),
 (227,21,67,0,4838,'additional_options',0,988,2,986,1305867702,1,987),
 (227,21,67,0,4839,'additional_options',0,989,3,987,1305867702,1,988),
 (227,21,67,0,4840,'additional_options',0,990,4,988,1305867702,1,989),
 (227,21,67,0,4841,'additional_options',0,991,5,989,1305867702,1,990),
 (227,21,67,0,4842,'additional_options',0,992,6,990,1305867702,1,991),
 (227,21,67,0,4843,'additional_options',0,993,7,991,1305867702,1,992),
 (227,21,67,0,4844,'additional_options',0,986,8,992,1305867702,1,993),
 (227,21,67,0,4845,'additional_options',0,994,9,993,1305867702,1,986),
 (227,21,67,0,4846,'additional_options',0,995,10,986,1305867702,1,994),
 (227,21,67,0,4847,'additional_options',0,979,11,994,1305867702,1,995),
 (227,21,67,0,4848,'additional_options',0,993,12,995,1305867702,1,979),
 (227,21,67,0,4849,'additional_options',0,986,13,979,1305867702,1,993),
 (227,21,67,0,4850,'additional_options',0,996,14,993,1305867702,1,986),
 (227,21,67,0,4851,'additional_options',0,993,15,986,1305867702,1,996),
 (227,21,67,0,4852,'additional_options',0,986,16,996,1305867702,1,993),
 (227,21,67,0,4853,'additional_options',0,996,17,993,1305867702,1,986),
 (227,21,67,0,4854,'additional_options',0,993,18,986,1305867702,1,996),
 (227,21,67,0,4855,'additional_options',0,986,19,996,1305867702,1,993),
 (227,21,67,0,4856,'additional_options',0,997,20,993,1305867702,1,986),
 (227,21,67,0,4857,'additional_options',0,993,21,986,1305867702,1,997),
 (227,21,67,0,4858,'additional_options',0,986,22,997,1305867702,1,993),
 (227,21,67,0,4859,'additional_options',0,994,23,993,1305867702,1,986),
 (227,21,67,0,4860,'additional_options',0,993,24,986,1305867702,1,994),
 (227,21,67,0,4861,'additional_options',0,0,25,994,1305867702,1,993),
 (220,21,68,0,4862,'name',0,986,0,0,1305867740,1,1003),
 (227,21,68,0,4863,'additional_options',0,987,1,1003,1305867740,1,986),
 (227,21,68,0,4864,'additional_options',0,988,2,986,1305867740,1,987),
 (227,21,68,0,4865,'additional_options',0,989,3,987,1305867740,1,988),
 (227,21,68,0,4866,'additional_options',0,990,4,988,1305867740,1,989),
 (227,21,68,0,4867,'additional_options',0,991,5,989,1305867740,1,990),
 (227,21,68,0,4868,'additional_options',0,992,6,990,1305867740,1,991),
 (227,21,68,0,4869,'additional_options',0,993,7,991,1305867740,1,992),
 (227,21,68,0,4870,'additional_options',0,986,8,992,1305867740,1,993),
 (227,21,68,0,4871,'additional_options',0,994,9,993,1305867740,1,986),
 (227,21,68,0,4872,'additional_options',0,995,10,986,1305867740,1,994),
 (227,21,68,0,4873,'additional_options',0,979,11,994,1305867740,1,995),
 (227,21,68,0,4874,'additional_options',0,993,12,995,1305867740,1,979),
 (227,21,68,0,4875,'additional_options',0,986,13,979,1305867740,1,993),
 (227,21,68,0,4876,'additional_options',0,996,14,993,1305867740,1,986),
 (227,21,68,0,4877,'additional_options',0,993,15,986,1305867740,1,996),
 (227,21,68,0,4878,'additional_options',0,986,16,996,1305867740,1,993),
 (227,21,68,0,4879,'additional_options',0,996,17,993,1305867740,1,986),
 (227,21,68,0,4880,'additional_options',0,993,18,986,1305867740,1,996),
 (227,21,68,0,4881,'additional_options',0,986,19,996,1305867740,1,993),
 (227,21,68,0,4882,'additional_options',0,997,20,993,1305867740,1,986),
 (227,21,68,0,4883,'additional_options',0,993,21,986,1305867740,1,997),
 (227,21,68,0,4884,'additional_options',0,986,22,997,1305867740,1,993),
 (227,21,68,0,4885,'additional_options',0,994,23,993,1305867740,1,986),
 (227,21,68,0,4886,'additional_options',0,993,24,986,1305867740,1,994),
 (227,21,68,0,4887,'additional_options',0,0,25,994,1305867740,1,993),
 (220,21,66,0,4896,'name',0,983,0,0,1305867536,1,981),
 (220,21,66,0,4897,'name',0,1012,1,981,1305867536,1,983),
 (220,21,66,0,4898,'name',0,1013,2,983,1305867536,1,1012),
 (220,21,66,0,4899,'name',0,1014,3,1012,1305867536,1,1013),
 (222,21,66,0,4900,'short_description',0,1015,4,1013,1305867536,1,1014),
 (222,21,66,0,4901,'short_description',0,1016,5,1014,1305867536,1,1015),
 (222,21,66,0,4902,'short_description',0,1017,6,1015,1305867536,1,1016),
 (222,21,66,0,4903,'short_description',0,1018,7,1016,1305867536,1,1017),
 (222,21,66,0,4904,'short_description',0,1019,8,1017,1305867536,1,1018),
 (222,21,66,0,4905,'short_description',0,1020,9,1018,1305867536,1,1019),
 (222,21,66,0,4906,'short_description',0,1016,10,1019,1305867536,1,1020),
 (222,21,66,0,4907,'short_description',0,1021,11,1020,1305867536,1,1016),
 (222,21,66,0,4908,'short_description',0,1022,12,1016,1305867536,1,1021),
 (222,21,66,0,4909,'short_description',0,1023,13,1021,1305867536,1,1022),
 (222,21,66,0,4910,'short_description',0,1024,14,1022,1305867536,1,1023),
 (222,21,66,0,4911,'short_description',0,1025,15,1023,1305867536,1,1024),
 (222,21,66,0,4912,'short_description',0,814,16,1024,1305867536,1,1025),
 (222,21,66,0,4913,'short_description',0,1026,17,1025,1305867536,1,814),
 (222,21,66,0,4914,'short_description',0,1027,18,814,1305867536,1,1026),
 (222,21,66,0,4915,'short_description',0,1028,19,1026,1305867536,1,1027),
 (222,21,66,0,4916,'short_description',0,1016,20,1027,1305867536,1,1028),
 (222,21,66,0,4917,'short_description',0,1029,21,1028,1305867536,1,1016),
 (222,21,66,0,4918,'short_description',0,1030,22,1016,1305867536,1,1029),
 (222,21,66,0,4919,'short_description',0,1031,23,1029,1305867536,1,1030),
 (222,21,66,0,4920,'short_description',0,1032,24,1030,1305867536,1,1031),
 (222,21,66,0,4921,'short_description',0,1033,25,1031,1305867536,1,1032),
 (222,21,66,0,4922,'short_description',0,1034,26,1032,1305867536,1,1033),
 (222,21,66,0,4923,'short_description',0,814,27,1033,1305867536,1,1034),
 (222,21,66,0,4924,'short_description',0,1035,28,1034,1305867536,1,814),
 (222,21,66,0,4925,'short_description',0,1028,29,814,1305867536,1,1035),
 (222,21,66,0,4926,'short_description',0,1036,30,1035,1305867536,1,1028),
 (222,21,66,0,4927,'short_description',0,1037,31,1028,1305867536,1,1036),
 (222,21,66,0,4928,'short_description',0,1038,32,1036,1305867536,1,1037),
 (222,21,66,0,4929,'short_description',0,1015,33,1037,1305867536,1,1038),
 (222,21,66,0,4930,'short_description',0,1020,34,1038,1305867536,1,1015),
 (222,21,66,0,4931,'short_description',0,1014,35,1015,1305867536,1,1020),
 (222,21,66,0,4932,'short_description',0,1039,36,1020,1305867536,1,1014),
 (222,21,66,0,4933,'short_description',0,1016,37,1014,1305867536,1,1039),
 (222,21,66,0,4934,'short_description',0,1040,38,1039,1305867536,1,1016),
 (222,21,66,0,4935,'short_description',0,1041,39,1016,1305867536,1,1040),
 (222,21,66,0,4936,'short_description',0,1042,40,1040,1305867536,1,1041),
 (222,21,66,0,4937,'short_description',0,1043,41,1041,1305867536,1,1042),
 (222,21,66,0,4938,'short_description',0,1044,42,1042,1305867536,1,1043),
 (222,21,66,0,4939,'short_description',0,1028,43,1043,1305867536,1,1044),
 (222,21,66,0,4940,'short_description',0,1045,44,1044,1305867536,1,1028),
 (222,21,66,0,4941,'short_description',0,1046,45,1028,1305867536,1,1045),
 (222,21,66,0,4942,'short_description',0,1047,46,1045,1305867536,1,1046),
 (222,21,66,0,4943,'short_description',0,1048,47,1046,1305867536,1,1047),
 (222,21,66,0,4944,'short_description',0,1036,48,1047,1305867536,1,1048),
 (222,21,66,0,4945,'short_description',0,1027,49,1048,1305867536,1,1036),
 (222,21,66,0,4946,'short_description',0,1049,50,1036,1305867536,1,1027),
 (222,21,66,0,4947,'short_description',0,1027,51,1027,1305867536,1,1049),
 (222,21,66,0,4948,'short_description',0,1049,52,1049,1305867536,1,1027),
 (222,21,66,0,4949,'short_description',0,1050,53,1027,1305867536,1,1049),
 (222,21,66,0,4950,'short_description',0,1014,54,1049,1305867536,1,1050),
 (222,21,66,0,4951,'short_description',0,1051,55,1050,1305867536,1,1014),
 (222,21,66,0,4952,'short_description',0,1052,56,1014,1305867536,1,1051),
 (222,21,66,0,4953,'short_description',0,1026,57,1051,1305867536,1,1052),
 (222,21,66,0,4954,'short_description',0,1053,58,1052,1305867536,1,1026),
 (222,21,66,0,4955,'short_description',0,1054,59,1026,1305867536,1,1053),
 (222,21,66,0,4956,'short_description',0,1014,60,1053,1305867536,1,1054),
 (223,21,66,0,4957,'description',0,1015,61,1054,1305867536,1,1014),
 (223,21,66,0,4958,'description',0,1016,62,1014,1305867536,1,1015),
 (223,21,66,0,4959,'description',0,1017,63,1015,1305867536,1,1016),
 (223,21,66,0,4960,'description',0,1018,64,1016,1305867536,1,1017),
 (223,21,66,0,4961,'description',0,1019,65,1017,1305867536,1,1018),
 (223,21,66,0,4962,'description',0,1020,66,1018,1305867536,1,1019),
 (223,21,66,0,4963,'description',0,1016,67,1019,1305867536,1,1020),
 (223,21,66,0,4964,'description',0,1021,68,1020,1305867536,1,1016),
 (223,21,66,0,4965,'description',0,1022,69,1016,1305867536,1,1021),
 (223,21,66,0,4966,'description',0,1023,70,1021,1305867536,1,1022),
 (223,21,66,0,4967,'description',0,1024,71,1022,1305867536,1,1023),
 (223,21,66,0,4968,'description',0,1025,72,1023,1305867536,1,1024),
 (223,21,66,0,4969,'description',0,814,73,1024,1305867536,1,1025),
 (223,21,66,0,4970,'description',0,1026,74,1025,1305867536,1,814),
 (223,21,66,0,4971,'description',0,1027,75,814,1305867536,1,1026),
 (223,21,66,0,4972,'description',0,1028,76,1026,1305867536,1,1027),
 (223,21,66,0,4973,'description',0,1016,77,1027,1305867536,1,1028),
 (223,21,66,0,4974,'description',0,1029,78,1028,1305867536,1,1016),
 (223,21,66,0,4975,'description',0,1030,79,1016,1305867536,1,1029),
 (223,21,66,0,4976,'description',0,1031,80,1029,1305867536,1,1030),
 (223,21,66,0,4977,'description',0,1032,81,1030,1305867536,1,1031),
 (223,21,66,0,4978,'description',0,1033,82,1031,1305867536,1,1032),
 (223,21,66,0,4979,'description',0,1034,83,1032,1305867536,1,1033),
 (223,21,66,0,4980,'description',0,814,84,1033,1305867536,1,1034),
 (223,21,66,0,4981,'description',0,1035,85,1034,1305867536,1,814),
 (223,21,66,0,4982,'description',0,1028,86,814,1305867536,1,1035),
 (223,21,66,0,4983,'description',0,1036,87,1035,1305867536,1,1028),
 (223,21,66,0,4984,'description',0,1037,88,1028,1305867536,1,1036),
 (223,21,66,0,4985,'description',0,1038,89,1036,1305867536,1,1037),
 (223,21,66,0,4986,'description',0,1015,90,1037,1305867536,1,1038),
 (223,21,66,0,4987,'description',0,1020,91,1038,1305867536,1,1015),
 (223,21,66,0,4988,'description',0,1014,92,1015,1305867536,1,1020),
 (223,21,66,0,4989,'description',0,1039,93,1020,1305867536,1,1014),
 (223,21,66,0,4990,'description',0,1016,94,1014,1305867536,1,1039),
 (223,21,66,0,4991,'description',0,1040,95,1039,1305867536,1,1016),
 (223,21,66,0,4992,'description',0,1041,96,1016,1305867536,1,1040),
 (223,21,66,0,4993,'description',0,1042,97,1040,1305867536,1,1041),
 (223,21,66,0,4994,'description',0,1043,98,1041,1305867536,1,1042),
 (223,21,66,0,4995,'description',0,1044,99,1042,1305867536,1,1043),
 (223,21,66,0,4996,'description',0,1028,100,1043,1305867536,1,1044),
 (223,21,66,0,4997,'description',0,1045,101,1044,1305867536,1,1028),
 (223,21,66,0,4998,'description',0,1046,102,1028,1305867536,1,1045),
 (223,21,66,0,4999,'description',0,1047,103,1045,1305867536,1,1046),
 (223,21,66,0,5000,'description',0,1048,104,1046,1305867536,1,1047),
 (223,21,66,0,5001,'description',0,1036,105,1047,1305867536,1,1048),
 (223,21,66,0,5002,'description',0,1027,106,1048,1305867536,1,1036),
 (223,21,66,0,5003,'description',0,1049,107,1036,1305867536,1,1027),
 (223,21,66,0,5004,'description',0,1027,108,1027,1305867536,1,1049),
 (223,21,66,0,5005,'description',0,1049,109,1049,1305867536,1,1027),
 (223,21,66,0,5006,'description',0,1050,110,1027,1305867536,1,1049),
 (223,21,66,0,5007,'description',0,1014,111,1049,1305867536,1,1050),
 (223,21,66,0,5008,'description',0,1051,112,1050,1305867536,1,1014),
 (223,21,66,0,5009,'description',0,1052,113,1014,1305867536,1,1051),
 (223,21,66,0,5010,'description',0,1026,114,1051,1305867536,1,1052),
 (223,21,66,0,5011,'description',0,1053,115,1052,1305867536,1,1026),
 (223,21,66,0,5012,'description',0,1055,116,1026,1305867536,1,1053),
 (223,21,66,0,5013,'description',0,1015,117,1053,1305867536,1,1055),
 (223,21,66,0,5014,'description',0,1016,118,1055,1305867536,1,1015),
 (223,21,66,0,5015,'description',0,1017,119,1015,1305867536,1,1016),
 (223,21,66,0,5016,'description',0,1018,120,1016,1305867536,1,1017),
 (223,21,66,0,5017,'description',0,1019,121,1017,1305867536,1,1018),
 (223,21,66,0,5018,'description',0,1020,122,1018,1305867536,1,1019),
 (223,21,66,0,5019,'description',0,1016,123,1019,1305867536,1,1020),
 (223,21,66,0,5020,'description',0,1021,124,1020,1305867536,1,1016),
 (223,21,66,0,5021,'description',0,1022,125,1016,1305867536,1,1021),
 (223,21,66,0,5022,'description',0,1023,126,1021,1305867536,1,1022),
 (223,21,66,0,5023,'description',0,1024,127,1022,1305867536,1,1023),
 (223,21,66,0,5024,'description',0,1025,128,1023,1305867536,1,1024),
 (223,21,66,0,5025,'description',0,814,129,1024,1305867536,1,1025),
 (223,21,66,0,5026,'description',0,1026,130,1025,1305867536,1,814),
 (223,21,66,0,5027,'description',0,1027,131,814,1305867536,1,1026),
 (223,21,66,0,5028,'description',0,1028,132,1026,1305867536,1,1027),
 (223,21,66,0,5029,'description',0,1016,133,1027,1305867536,1,1028),
 (223,21,66,0,5030,'description',0,1029,134,1028,1305867536,1,1016),
 (223,21,66,0,5031,'description',0,1030,135,1016,1305867536,1,1029),
 (223,21,66,0,5032,'description',0,1031,136,1029,1305867536,1,1030),
 (223,21,66,0,5033,'description',0,1032,137,1030,1305867536,1,1031),
 (223,21,66,0,5034,'description',0,1033,138,1031,1305867536,1,1032),
 (223,21,66,0,5035,'description',0,1034,139,1032,1305867536,1,1033),
 (223,21,66,0,5036,'description',0,814,140,1033,1305867536,1,1034),
 (223,21,66,0,5037,'description',0,1035,141,1034,1305867536,1,814),
 (223,21,66,0,5038,'description',0,1028,142,814,1305867536,1,1035),
 (223,21,66,0,5039,'description',0,1036,143,1035,1305867536,1,1028),
 (223,21,66,0,5040,'description',0,1037,144,1028,1305867536,1,1036),
 (223,21,66,0,5041,'description',0,1038,145,1036,1305867536,1,1037),
 (223,21,66,0,5042,'description',0,1015,146,1037,1305867536,1,1038),
 (223,21,66,0,5043,'description',0,1020,147,1038,1305867536,1,1015),
 (223,21,66,0,5044,'description',0,1014,148,1015,1305867536,1,1020),
 (223,21,66,0,5045,'description',0,1039,149,1020,1305867536,1,1014),
 (223,21,66,0,5046,'description',0,1016,150,1014,1305867536,1,1039),
 (223,21,66,0,5047,'description',0,1040,151,1039,1305867536,1,1016),
 (223,21,66,0,5048,'description',0,1041,152,1016,1305867536,1,1040),
 (223,21,66,0,5049,'description',0,1042,153,1040,1305867536,1,1041),
 (223,21,66,0,5050,'description',0,1043,154,1041,1305867536,1,1042),
 (223,21,66,0,5051,'description',0,1044,155,1042,1305867536,1,1043),
 (223,21,66,0,5052,'description',0,1028,156,1043,1305867536,1,1044),
 (223,21,66,0,5053,'description',0,1045,157,1044,1305867536,1,1028),
 (223,21,66,0,5054,'description',0,1046,158,1028,1305867536,1,1045),
 (223,21,66,0,5055,'description',0,1047,159,1045,1305867536,1,1046),
 (223,21,66,0,5056,'description',0,1048,160,1046,1305867536,1,1047),
 (223,21,66,0,5057,'description',0,1036,161,1047,1305867536,1,1048),
 (223,21,66,0,5058,'description',0,1027,162,1048,1305867536,1,1036),
 (223,21,66,0,5059,'description',0,1049,163,1036,1305867536,1,1027),
 (223,21,66,0,5060,'description',0,1027,164,1027,1305867536,1,1049),
 (223,21,66,0,5061,'description',0,1049,165,1049,1305867536,1,1027),
 (223,21,66,0,5062,'description',0,1050,166,1027,1305867536,1,1049),
 (223,21,66,0,5063,'description',0,1014,167,1049,1305867536,1,1050),
 (223,21,66,0,5064,'description',0,1051,168,1050,1305867536,1,1014),
 (223,21,66,0,5065,'description',0,1052,169,1014,1305867536,1,1051),
 (223,21,66,0,5066,'description',0,1026,170,1051,1305867536,1,1052),
 (223,21,66,0,5067,'description',0,1053,171,1052,1305867536,1,1026),
 (223,21,66,0,5068,'description',0,1055,172,1026,1305867536,1,1053),
 (223,21,66,0,5069,'description',0,1015,173,1053,1305867536,1,1055),
 (223,21,66,0,5070,'description',0,1016,174,1055,1305867536,1,1015),
 (223,21,66,0,5071,'description',0,1017,175,1015,1305867536,1,1016),
 (223,21,66,0,5072,'description',0,1018,176,1016,1305867536,1,1017),
 (223,21,66,0,5073,'description',0,1019,177,1017,1305867536,1,1018),
 (223,21,66,0,5074,'description',0,1020,178,1018,1305867536,1,1019),
 (223,21,66,0,5075,'description',0,1016,179,1019,1305867536,1,1020),
 (223,21,66,0,5076,'description',0,1021,180,1020,1305867536,1,1016),
 (223,21,66,0,5077,'description',0,1022,181,1016,1305867536,1,1021),
 (223,21,66,0,5078,'description',0,1023,182,1021,1305867536,1,1022),
 (223,21,66,0,5079,'description',0,1024,183,1022,1305867536,1,1023),
 (223,21,66,0,5080,'description',0,1025,184,1023,1305867536,1,1024),
 (223,21,66,0,5081,'description',0,814,185,1024,1305867536,1,1025),
 (223,21,66,0,5082,'description',0,1026,186,1025,1305867536,1,814),
 (223,21,66,0,5083,'description',0,1027,187,814,1305867536,1,1026),
 (223,21,66,0,5084,'description',0,1028,188,1026,1305867536,1,1027),
 (223,21,66,0,5085,'description',0,1016,189,1027,1305867536,1,1028),
 (223,21,66,0,5086,'description',0,1029,190,1028,1305867536,1,1016),
 (223,21,66,0,5087,'description',0,1030,191,1016,1305867536,1,1029),
 (223,21,66,0,5088,'description',0,1031,192,1029,1305867536,1,1030),
 (223,21,66,0,5089,'description',0,1032,193,1030,1305867536,1,1031),
 (223,21,66,0,5090,'description',0,1033,194,1031,1305867536,1,1032),
 (223,21,66,0,5091,'description',0,1034,195,1032,1305867536,1,1033),
 (223,21,66,0,5092,'description',0,814,196,1033,1305867536,1,1034),
 (223,21,66,0,5093,'description',0,1035,197,1034,1305867536,1,814),
 (223,21,66,0,5094,'description',0,1028,198,814,1305867536,1,1035),
 (223,21,66,0,5095,'description',0,1036,199,1035,1305867536,1,1028),
 (223,21,66,0,5096,'description',0,1037,200,1028,1305867536,1,1036),
 (223,21,66,0,5097,'description',0,1038,201,1036,1305867536,1,1037),
 (223,21,66,0,5098,'description',0,1015,202,1037,1305867536,1,1038),
 (223,21,66,0,5099,'description',0,1020,203,1038,1305867536,1,1015),
 (223,21,66,0,5100,'description',0,1014,204,1015,1305867536,1,1020),
 (223,21,66,0,5101,'description',0,1039,205,1020,1305867536,1,1014),
 (223,21,66,0,5102,'description',0,1016,206,1014,1305867536,1,1039),
 (223,21,66,0,5103,'description',0,1040,207,1039,1305867536,1,1016),
 (223,21,66,0,5104,'description',0,1041,208,1016,1305867536,1,1040),
 (223,21,66,0,5105,'description',0,1042,209,1040,1305867536,1,1041),
 (223,21,66,0,5106,'description',0,1043,210,1041,1305867536,1,1042),
 (223,21,66,0,5107,'description',0,1044,211,1042,1305867536,1,1043),
 (223,21,66,0,5108,'description',0,1028,212,1043,1305867536,1,1044),
 (223,21,66,0,5109,'description',0,1045,213,1044,1305867536,1,1028),
 (223,21,66,0,5110,'description',0,1046,214,1028,1305867536,1,1045),
 (223,21,66,0,5111,'description',0,1047,215,1045,1305867536,1,1046),
 (223,21,66,0,5112,'description',0,1048,216,1046,1305867536,1,1047),
 (223,21,66,0,5113,'description',0,1036,217,1047,1305867536,1,1048),
 (223,21,66,0,5114,'description',0,1027,218,1048,1305867536,1,1036),
 (223,21,66,0,5115,'description',0,1049,219,1036,1305867536,1,1027),
 (223,21,66,0,5116,'description',0,1027,220,1027,1305867536,1,1049),
 (223,21,66,0,5117,'description',0,1049,221,1049,1305867536,1,1027),
 (223,21,66,0,5118,'description',0,1050,222,1027,1305867536,1,1049),
 (223,21,66,0,5119,'description',0,1014,223,1049,1305867536,1,1050),
 (223,21,66,0,5120,'description',0,1051,224,1050,1305867536,1,1014),
 (223,21,66,0,5121,'description',0,1052,225,1014,1305867536,1,1051),
 (223,21,66,0,5122,'description',0,1026,226,1051,1305867536,1,1052),
 (223,21,66,0,5123,'description',0,1053,227,1052,1305867536,1,1026),
 (223,21,66,0,5124,'description',0,1055,228,1026,1305867536,1,1053),
 (223,21,66,0,5125,'description',0,1015,229,1053,1305867536,1,1055),
 (223,21,66,0,5126,'description',0,1016,230,1055,1305867536,1,1015),
 (223,21,66,0,5127,'description',0,1017,231,1015,1305867536,1,1016),
 (223,21,66,0,5128,'description',0,1018,232,1016,1305867536,1,1017),
 (223,21,66,0,5129,'description',0,1019,233,1017,1305867536,1,1018),
 (223,21,66,0,5130,'description',0,1020,234,1018,1305867536,1,1019),
 (223,21,66,0,5131,'description',0,1016,235,1019,1305867536,1,1020),
 (223,21,66,0,5132,'description',0,1021,236,1020,1305867536,1,1016),
 (223,21,66,0,5133,'description',0,1022,237,1016,1305867536,1,1021),
 (223,21,66,0,5134,'description',0,1023,238,1021,1305867536,1,1022),
 (223,21,66,0,5135,'description',0,1024,239,1022,1305867536,1,1023),
 (223,21,66,0,5136,'description',0,1025,240,1023,1305867536,1,1024),
 (223,21,66,0,5137,'description',0,814,241,1024,1305867536,1,1025),
 (223,21,66,0,5138,'description',0,1026,242,1025,1305867536,1,814),
 (223,21,66,0,5139,'description',0,1027,243,814,1305867536,1,1026),
 (223,21,66,0,5140,'description',0,1028,244,1026,1305867536,1,1027),
 (223,21,66,0,5141,'description',0,1016,245,1027,1305867536,1,1028),
 (223,21,66,0,5142,'description',0,1029,246,1028,1305867536,1,1016),
 (223,21,66,0,5143,'description',0,1030,247,1016,1305867536,1,1029),
 (223,21,66,0,5144,'description',0,1031,248,1029,1305867536,1,1030),
 (223,21,66,0,5145,'description',0,1032,249,1030,1305867536,1,1031),
 (223,21,66,0,5146,'description',0,1033,250,1031,1305867536,1,1032),
 (223,21,66,0,5147,'description',0,1034,251,1032,1305867536,1,1033),
 (223,21,66,0,5148,'description',0,814,252,1033,1305867536,1,1034),
 (223,21,66,0,5149,'description',0,1035,253,1034,1305867536,1,814),
 (223,21,66,0,5150,'description',0,1028,254,814,1305867536,1,1035),
 (223,21,66,0,5151,'description',0,1036,255,1035,1305867536,1,1028),
 (223,21,66,0,5152,'description',0,1037,256,1028,1305867536,1,1036),
 (223,21,66,0,5153,'description',0,1038,257,1036,1305867536,1,1037),
 (223,21,66,0,5154,'description',0,1015,258,1037,1305867536,1,1038),
 (223,21,66,0,5155,'description',0,1020,259,1038,1305867536,1,1015),
 (223,21,66,0,5156,'description',0,1014,260,1015,1305867536,1,1020),
 (223,21,66,0,5157,'description',0,1039,261,1020,1305867536,1,1014),
 (223,21,66,0,5158,'description',0,1016,262,1014,1305867536,1,1039),
 (223,21,66,0,5159,'description',0,1040,263,1039,1305867536,1,1016),
 (223,21,66,0,5160,'description',0,1041,264,1016,1305867536,1,1040),
 (223,21,66,0,5161,'description',0,1042,265,1040,1305867536,1,1041),
 (223,21,66,0,5162,'description',0,1043,266,1041,1305867536,1,1042),
 (223,21,66,0,5163,'description',0,1044,267,1042,1305867536,1,1043),
 (223,21,66,0,5164,'description',0,1028,268,1043,1305867536,1,1044),
 (223,21,66,0,5165,'description',0,1045,269,1044,1305867536,1,1028),
 (223,21,66,0,5166,'description',0,1046,270,1028,1305867536,1,1045),
 (223,21,66,0,5167,'description',0,1047,271,1045,1305867536,1,1046),
 (223,21,66,0,5168,'description',0,1048,272,1046,1305867536,1,1047),
 (223,21,66,0,5169,'description',0,1036,273,1047,1305867536,1,1048),
 (223,21,66,0,5170,'description',0,1027,274,1048,1305867536,1,1036),
 (223,21,66,0,5171,'description',0,1049,275,1036,1305867536,1,1027),
 (223,21,66,0,5172,'description',0,1027,276,1027,1305867536,1,1049),
 (223,21,66,0,5173,'description',0,1049,277,1049,1305867536,1,1027),
 (223,21,66,0,5174,'description',0,1050,278,1027,1305867536,1,1049),
 (223,21,66,0,5175,'description',0,1014,279,1049,1305867536,1,1050),
 (223,21,66,0,5176,'description',0,1051,280,1050,1305867536,1,1014),
 (223,21,66,0,5177,'description',0,1052,281,1014,1305867536,1,1051),
 (223,21,66,0,5178,'description',0,1026,282,1051,1305867536,1,1052),
 (223,21,66,0,5179,'description',0,1053,283,1052,1305867536,1,1026),
 (223,21,66,0,5180,'description',0,1054,284,1026,1305867536,1,1053),
 (223,21,66,0,5181,'description',0,986,285,1053,1305867536,1,1054),
 (227,21,66,0,5182,'additional_options',0,987,286,1054,1305867536,1,986),
 (227,21,66,0,5183,'additional_options',0,988,287,986,1305867536,1,987),
 (227,21,66,0,5184,'additional_options',0,989,288,987,1305867536,1,988),
 (227,21,66,0,5185,'additional_options',0,990,289,988,1305867536,1,989),
 (227,21,66,0,5186,'additional_options',0,991,290,989,1305867536,1,990),
 (227,21,66,0,5187,'additional_options',0,992,291,990,1305867536,1,991),
 (227,21,66,0,5188,'additional_options',0,993,292,991,1305867536,1,992),
 (227,21,66,0,5189,'additional_options',0,986,293,992,1305867536,1,993),
 (227,21,66,0,5190,'additional_options',0,994,294,993,1305867536,1,986),
 (227,21,66,0,5191,'additional_options',0,995,295,986,1305867536,1,994),
 (227,21,66,0,5192,'additional_options',0,979,296,994,1305867536,1,995),
 (227,21,66,0,5193,'additional_options',0,993,297,995,1305867536,1,979),
 (227,21,66,0,5194,'additional_options',0,986,298,979,1305867536,1,993),
 (227,21,66,0,5195,'additional_options',0,996,299,993,1305867536,1,986),
 (227,21,66,0,5196,'additional_options',0,993,300,986,1305867536,1,996),
 (227,21,66,0,5197,'additional_options',0,986,301,996,1305867536,1,993),
 (227,21,66,0,5198,'additional_options',0,996,302,993,1305867536,1,986),
 (227,21,66,0,5199,'additional_options',0,993,303,986,1305867536,1,996),
 (227,21,66,0,5200,'additional_options',0,986,304,996,1305867536,1,993),
 (227,21,66,0,5201,'additional_options',0,997,305,993,1305867536,1,986),
 (227,21,66,0,5202,'additional_options',0,993,306,986,1305867536,1,997),
 (227,21,66,0,5203,'additional_options',0,986,307,997,1305867536,1,993),
 (227,21,66,0,5204,'additional_options',0,994,308,993,1305867536,1,986),
 (227,21,66,0,5205,'additional_options',0,993,309,986,1305867536,1,994),
 (227,21,66,0,5206,'additional_options',0,0,310,994,1305867536,1,993),
 (296,39,70,0,5207,'title',0,1057,0,0,1306043684,1,1056),
 (296,39,70,0,5208,'title',0,1058,1,1056,1306043684,1,1057),
 (296,39,70,0,5209,'title',0,1059,2,1057,1306043684,1,1058),
 (296,39,70,0,5210,'title',0,1060,3,1058,1306043684,1,1059),
 (299,39,70,0,5211,'intro',0,1061,4,1059,1306043684,1,1060),
 (299,39,70,0,5212,'intro',0,979,5,1060,1306043684,1,1061),
 (304,39,70,0,5213,'publish_date',0,979,6,1061,1306043684,1,979),
 (305,39,70,0,5214,'unpublish_date',0,1062,7,979,1306043684,1,979),
 (307,39,70,0,5215,'location',0,1063,8,979,1306043684,1,1062),
 (307,39,70,0,5216,'location',0,1064,9,1062,1306043684,1,1063),
 (307,39,70,0,5217,'location',0,1065,10,1063,1306043684,1,1064),
 (307,39,70,0,5218,'location',0,1066,11,1064,1306043684,1,1065),
 (307,39,70,0,5219,'location',0,0,12,1065,1306043684,1,1066),
 (296,39,71,0,5221,'title',0,1069,0,0,1306053770,1,1068),
 (296,39,71,0,5222,'title',0,1070,1,1068,1306053770,1,1069),
 (299,39,71,0,5223,'intro',0,1071,2,1069,1306053770,1,1070),
 (299,39,71,0,5224,'intro',0,1072,3,1070,1306053770,1,1071),
 (299,39,71,0,5225,'intro',0,1071,4,1071,1306053770,1,1072),
 (299,39,71,0,5226,'intro',0,1071,5,1072,1306053770,1,1071),
 (299,39,71,0,5227,'intro',0,979,6,1071,1306053770,1,1071),
 (304,39,71,0,5228,'publish_date',0,979,7,1071,1306053770,1,979),
 (305,39,71,0,5229,'unpublish_date',0,1062,8,979,1306053770,1,979),
 (307,39,71,0,5230,'location',0,1073,9,979,1306053770,1,1062),
 (307,39,71,0,5231,'location',0,1074,10,1062,1306053770,1,1073),
 (307,39,71,0,5232,'location',0,1068,11,1073,1306053770,1,1074),
 (307,39,71,0,5233,'location',0,1075,12,1074,1306053770,1,1068),
 (307,39,71,0,5234,'location',0,1076,13,1068,1306053770,1,1075),
 (307,39,71,0,5235,'location',0,1077,14,1075,1306053770,1,1076),
 (307,39,71,0,5236,'location',0,1078,15,1076,1306053770,1,1077),
 (307,39,71,0,5237,'location',0,1079,16,1077,1306053770,1,1078),
 (307,39,71,0,5238,'location',0,1066,17,1078,1306053770,1,1079),
 (307,39,71,0,5239,'location',0,0,18,1079,1306053770,1,1066),
 (296,39,73,0,5261,'title',0,1090,0,0,1306081523,1,1089),
 (296,39,73,0,5262,'title',0,1056,1,1089,1306081523,1,1090),
 (299,39,73,0,5263,'intro',0,979,2,1090,1306081523,1,1056),
 (304,39,73,0,5264,'publish_date',0,979,3,1056,1306081523,1,979),
 (305,39,73,0,5265,'unpublish_date',0,0,4,979,1306081523,1,979),
 (258,29,74,0,5269,'name',0,1095,0,0,1307017623,3,1094),
 (258,29,74,0,5270,'name',0,0,1,1094,1307017623,3,1095),
 (236,23,57,0,5271,'name',0,0,0,0,1195480486,1,1096);
/*!40000 ALTER TABLE `ezsearch_object_word_link` ENABLE KEYS */;


--
-- Dumping data for table `ezsearch_return_count`
--

/*!40000 ALTER TABLE `ezsearch_return_count` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezsearch_return_count` ENABLE KEYS */;


--
-- Dumping data for table `ezsearch_search_phrase`
--

/*!40000 ALTER TABLE `ezsearch_search_phrase` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezsearch_search_phrase` ENABLE KEYS */;


--
-- Dumping data for table `ezsearch_word`
--

/*!40000 ALTER TABLE `ezsearch_word` DISABLE KEYS */;
INSERT INTO `ezsearch_word` (`id`,`object_count`,`word`) VALUES 
 (812,1,'setup'),
 (814,2,'the'),
 (816,1,'for'),
 (877,1,'common'),
 (927,1,'ez.no'),
 (930,3,'users'),
 (951,1,'main'),
 (952,2,'group'),
 (953,2,'anonymous'),
 (954,3,'user'),
 (955,1,'nospam'),
 (958,2,'administrator'),
 (959,1,'editors'),
 (961,1,'media'),
 (962,1,'images'),
 (963,1,'files'),
 (964,1,'multimedia'),
 (965,1,'ini'),
 (966,1,'settings'),
 (967,1,'sitestyle_identifier'),
 (968,1,'design'),
 (970,1,'admin'),
 (971,1,'nounours.local'),
 (972,1,'partners'),
 (973,1,'members'),
 (974,1,'peluches'),
 (976,1,'mentions'),
 (977,1,'legales'),
 (978,2,'c'),
 (979,10,'0'),
 (980,1,'poupees'),
 (981,4,'la'),
 (982,1,'societe'),
 (983,3,'peluche'),
 (985,2,'mouse'),
 (986,5,'lt'),
 (987,5,'xml'),
 (988,5,'version'),
 (989,5,'1.0'),
 (990,5,'encoding'),
 (991,5,'utf'),
 (992,5,'8'),
 (993,5,'gt'),
 (994,5,'ezmultioption'),
 (995,5,'option_counter'),
 (996,5,'name'),
 (997,5,'multioptions'),
 (998,1,'minnie'),
 (1001,1,'mickey'),
 (1002,1,'melanie'),
 (1003,1,'arthur'),
 (1012,1,'donald'),
 (1013,1,'duck'),
 (1014,1,'it'),
 (1015,1,'is'),
 (1016,1,'a'),
 (1017,1,'long'),
 (1018,1,'established'),
 (1019,1,'fact'),
 (1020,1,'that'),
 (1021,1,'reader'),
 (1022,1,'will'),
 (1023,1,'be'),
 (1024,1,'distracted'),
 (1025,1,'by'),
 (1026,1,'readable'),
 (1027,1,'content'),
 (1028,1,'of'),
 (1029,1,'page'),
 (1030,1,'when'),
 (1031,1,'looking'),
 (1032,1,'at'),
 (1033,1,'its'),
 (1034,1,'layout'),
 (1035,1,'point'),
 (1036,1,'using'),
 (1037,1,'lorem'),
 (1038,1,'ipsum'),
 (1039,1,'has'),
 (1040,1,'more'),
 (1041,1,'or'),
 (1042,1,'less'),
 (1043,1,'normal'),
 (1044,1,'distribution'),
 (1045,1,'letters'),
 (1046,1,'as'),
 (1047,1,'opposed'),
 (1048,1,'to'),
 (1049,1,'here'),
 (1050,1,'making'),
 (1051,1,'look'),
 (1052,1,'like'),
 (1053,1,'english'),
 (1054,1,'many'),
 (1055,1,'manyit'),
 (1056,2,'test'),
 (1057,1,'google'),
 (1058,1,'analytics'),
 (1059,1,'v3'),
 (1060,1,'qsdfqsdfqsdf'),
 (1061,1,'qsdfqsdfqsd'),
 (1062,2,'1'),
 (1063,1,'rue'),
 (1064,1,'de'),
 (1065,1,'belleville'),
 (1066,2,'paris'),
 (1068,1,'champs'),
 (1069,1,'elysees'),
 (1070,1,'qsdfqs'),
 (1071,1,'qsdf'),
 (1072,1,'qsdfqsdf'),
 (1073,1,'avenue'),
 (1074,1,'des'),
 (1075,1,'elys'),
 (1076,1,'amp'),
 (1077,1,'eacute'),
 (1078,1,'es'),
 (1079,1,'75008'),
 (1089,1,'new'),
 (1090,1,'article'),
 (1094,1,'banniere'),
 (1095,1,'transparente'),
 (1096,1,'home');
/*!40000 ALTER TABLE `ezsearch_word` ENABLE KEYS */;


--
-- Dumping data for table `ezsection`
--

/*!40000 ALTER TABLE `ezsection` DISABLE KEYS */;
INSERT INTO `ezsection` (`id`,`identifier`,`locale`,`name`,`navigation_part_identifier`) VALUES 
 (1,'standard','','Standard','ezcontentnavigationpart'),
 (2,'users','','Users','ezusernavigationpart'),
 (3,'media','','Media','ezmedianavigationpart'),
 (4,'setup','','Setup','ezsetupnavigationpart'),
 (5,'design','','Design','ezvisualnavigationpart'),
 (6,'','','Restricted','ezcontentnavigationpart');
/*!40000 ALTER TABLE `ezsection` ENABLE KEYS */;


--
-- Dumping data for table `ezsession`
--

/*!40000 ALTER TABLE `ezsession` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezsession` ENABLE KEYS */;


--
-- Dumping data for table `ezsite_data`
--

/*!40000 ALTER TABLE `ezsite_data` DISABLE KEYS */;
INSERT INTO `ezsite_data` (`name`,`value`) VALUES 
 ('ezflow','2.0'),
 ('ezpublish-release','1'),
 ('ezpublish-version','4.5.0');
/*!40000 ALTER TABLE `ezsite_data` ENABLE KEYS */;


--
-- Dumping data for table `ezstarrating`
--

/*!40000 ALTER TABLE `ezstarrating` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezstarrating` ENABLE KEYS */;


--
-- Dumping data for table `ezstarrating_data`
--

/*!40000 ALTER TABLE `ezstarrating_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezstarrating_data` ENABLE KEYS */;


--
-- Dumping data for table `ezsubtree_notification_rule`
--

/*!40000 ALTER TABLE `ezsubtree_notification_rule` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezsubtree_notification_rule` ENABLE KEYS */;


--
-- Dumping data for table `eztipafriend_counter`
--

/*!40000 ALTER TABLE `eztipafriend_counter` DISABLE KEYS */;
/*!40000 ALTER TABLE `eztipafriend_counter` ENABLE KEYS */;


--
-- Dumping data for table `eztipafriend_request`
--

/*!40000 ALTER TABLE `eztipafriend_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `eztipafriend_request` ENABLE KEYS */;


--
-- Dumping data for table `eztrigger`
--

/*!40000 ALTER TABLE `eztrigger` DISABLE KEYS */;
/*!40000 ALTER TABLE `eztrigger` ENABLE KEYS */;


--
-- Dumping data for table `ezurl`
--

/*!40000 ALTER TABLE `ezurl` DISABLE KEYS */;
INSERT INTO `ezurl` (`created`,`id`,`is_valid`,`last_checked`,`modified`,`original_url_md5`,`url`) VALUES 
 (1305866664,23,1,0,1305866664,'9b492048041e95b32de08bafc86d759b','/content/view/sitemap/2'),
 (1305866664,24,1,0,1305866664,'c86bcb109d8e70f9db65c803baafd550','/content/view/tagcloud/2');
/*!40000 ALTER TABLE `ezurl` ENABLE KEYS */;


--
-- Dumping data for table `ezurl_object_link`
--

/*!40000 ALTER TABLE `ezurl_object_link` DISABLE KEYS */;
INSERT INTO `ezurl_object_link` (`contentobject_attribute_id`,`contentobject_attribute_version`,`url_id`) VALUES 
 (203,2,23),
 (204,2,24);
/*!40000 ALTER TABLE `ezurl_object_link` ENABLE KEYS */;


--
-- Dumping data for table `ezurlalias`
--

/*!40000 ALTER TABLE `ezurlalias` DISABLE KEYS */;
INSERT INTO `ezurlalias` (`destination_url`,`forward_to_id`,`id`,`is_imported`,`is_internal`,`is_wildcard`,`source_md5`,`source_url`) VALUES 
 ('content/view/full/2',0,12,1,1,0,'d41d8cd98f00b204e9800998ecf8427e',''),
 ('content/view/full/5',0,13,1,1,0,'9bc65c2abec141778ffaa729489f3e87','users'),
 ('content/view/full/12',0,15,1,1,0,'02d4e844e3a660857a3f81585995ffe1','users/guest_accounts'),
 ('content/view/full/13',0,16,1,1,0,'1b1d79c16700fd6003ea7be233e754ba','users/administrator_users'),
 ('content/view/full/14',0,17,1,1,0,'0bb9dd665c96bbc1cf36b79180786dea','users/editors'),
 ('content/view/full/15',0,18,1,1,0,'f1305ac5f327a19b451d82719e0c3f5d','users/administrator_users/administrator_user'),
 ('content/view/full/43',0,20,1,1,0,'62933a2951ef01f4eafd9bdf4d3cd2f0','media'),
 ('content/view/full/44',0,21,1,1,0,'3ae1aac958e1c82013689d917d34967a','users/anonymous_users'),
 ('content/view/full/45',0,22,1,1,0,'aad93975f09371695ba08292fd9698db','users/anonymous_users/anonymous_user'),
 ('content/view/full/48',0,25,1,1,0,'a0f848942ce863cf53c0fa6cc684007d','setup'),
 ('content/view/full/50',0,27,1,1,0,'c60212835de76414f9bfd21eecb8f221','foo_bar_folder/images/vbanner'),
 ('content/view/full/51',0,28,1,1,0,'38985339d4a5aadfc41ab292b4527046','media/images'),
 ('content/view/full/52',0,29,1,1,0,'ad5a8c6f6aac3b1b9df267fe22e7aef6','media/files'),
 ('content/view/full/53',0,30,1,1,0,'562a0ac498571c6c3529173184a2657c','media/multimedia'),
 ('content/view/full/54',0,31,1,1,0,'e501fe6c81ed14a5af2b322d248102d8','setup/common_ini_settings'),
 ('content/view/full/56',0,32,1,1,0,'2dd3db5dc7122ea5f3ee539bb18fe97d','design/ez_publish'),
 ('content/view/full/58',0,33,1,1,0,'31c13f47ad87dd7baa2d558a91e0fbb9','design');
/*!40000 ALTER TABLE `ezurlalias` ENABLE KEYS */;


--
-- Dumping data for table `ezurlalias_ml`
--

/*!40000 ALTER TABLE `ezurlalias_ml` DISABLE KEYS */;
INSERT INTO `ezurlalias_ml` (`action`,`action_type`,`alias_redirects`,`id`,`is_alias`,`is_original`,`lang_mask`,`link`,`parent`,`text`,`text_md5`) VALUES 
 ('nop:','nop',1,14,0,0,1,14,0,'foo_bar_folder','0288b6883046492fa92e4a84eb67acc9'),
 ('eznode:61','eznode',1,42,0,1,3,42,0,'Peluches','090d57909d16277544904d4d646739b5'),
 ('eznode:59','eznode',1,39,0,0,3,38,0,'Home','106a6c241b8797f52e1e77317b96a201'),
 ('eznode:59','eznode',1,38,0,1,3,38,0,'eZ-Publish','10e4c3cb527fb9963258469986c16240'),
 ('eznode:63','eznode',1,44,0,1,2,44,0,'Mentions-legales','19a51ec9ca14f0dcfcb3ef708610507e'),
 ('eznode:71','eznode',1,52,0,1,2,52,0,'Test-google-analytics-v3','28126b7d42da9132c49372b21dedab6d'),
 ('eznode:58','eznode',1,25,0,1,3,25,0,'Design','31c13f47ad87dd7baa2d558a91e0fbb9'),
 ('eznode:48','eznode',1,13,0,1,3,13,0,'Setup2','475e97c0146bfb1c490339546d9e72ee'),
 ('nop:','nop',1,17,0,0,1,17,0,'media2','50e2736330de124f6edea9b008556fe6'),
 ('eznode:43','eznode',1,9,0,1,3,9,0,'Media','62933a2951ef01f4eafd9bdf4d3cd2f0'),
 ('nop:','nop',1,21,0,0,1,21,0,'setup3','732cefcf28bf4547540609fb1a786a30'),
 ('nop:','nop',1,3,0,0,1,3,0,'users2','86425c35a33507d479f71ade53a669aa'),
 ('eznode:72','eznode',1,53,0,1,2,53,0,'Champs-elysees','98e528159650e1295d1caad042b20131'),
 ('eznode:64','eznode',1,45,0,1,3,45,0,'Poupees','9bc3f88833fb8ddf204dcdc5c62b13f8'),
 ('eznode:5','eznode',1,2,0,1,3,2,0,'Users','9bc65c2abec141778ffaa729489f3e87'),
 ('eznode:65','eznode',1,46,0,1,2,46,0,'La-societe','9c09246294996aee3ec9234d688e3b55'),
 ('eznode:2','eznode',1,1,0,1,3,1,0,'','d41d8cd98f00b204e9800998ecf8427e'),
 ('eznode:73','eznode',1,54,0,1,2,54,0,'New-article','d8931660c0e4a9bb82113b8f94dac737'),
 ('eznode:60','eznode',1,40,0,1,3,40,2,'Partners','7896f8fa69398c56d86a65357615c41f'),
 ('eznode:14','eznode',1,6,0,1,3,6,2,'Editors','a147e136bfa717592f2bd70bd4b53b17'),
 ('eznode:44','eznode',1,10,0,1,3,10,2,'Anonymous-Users','c2803c3fa1b0b5423237b4e018cae755'),
 ('eznode:12','eznode',1,4,0,1,3,4,2,'Members','d2e3083420929d8bfae81f58fa4594cb'),
 ('eznode:12','eznode',1,41,0,0,3,4,2,'Guest-accounts','e57843d836e3af8ab611fde9e2139b3a'),
 ('eznode:13','eznode',1,5,0,1,3,5,2,'Administrator-users','f89fad7f8a3abc8c09e1deb46a420007'),
 ('nop:','nop',1,11,0,0,1,11,3,'anonymous_users2','505e93077a6dde9034ad97a14ab022b1'),
 ('eznode:12','eznode',1,26,0,0,0,4,3,'guest_accounts','70bb992820e73638731aa8de79b3329e'),
 ('eznode:14','eznode',1,29,0,0,1,6,3,'editors','a147e136bfa717592f2bd70bd4b53b17'),
 ('nop:','nop',1,7,0,0,1,7,3,'administrator_users2','a7da338c20bf65f9f789c87296379c2a'),
 ('eznode:13','eznode',1,27,0,0,1,5,3,'administrator_users','aeb8609aa933b0899aa012c71139c58c'),
 ('eznode:44','eznode',1,30,0,0,1,10,3,'anonymous_users','e9e5ad0c05ee1a43715572e5cc545926'),
 ('eznode:15','eznode',1,8,0,1,3,8,5,'Administrator-User','5a9d7b0ec93173ef4fedee023209cb61'),
 ('eznode:15','eznode',1,28,0,0,0,8,7,'administrator_user','a3cca2de936df1e2f805710399989971'),
 ('eznode:53','eznode',1,20,0,1,3,20,9,'Multimedia','2e5bc8831f7ae6a29530e7f1bbf2de9c'),
 ('eznode:52','eznode',1,19,0,1,3,19,9,'Files','45b963397aa40d4a0063e0d85e4fe7a1'),
 ('eznode:51','eznode',1,18,0,1,3,18,9,'Images','59b514174bffe4ae402b3d63aad79fe0'),
 ('eznode:45','eznode',1,12,0,1,3,12,10,'Anonymous-User','ccb62ebca03a31272430bc414bd5cd5b'),
 ('eznode:45','eznode',1,31,0,0,1,12,11,'anonymous_user','c593ec85293ecb0e02d50d4c5c6c20eb'),
 ('eznode:54','eznode',1,22,0,1,2,22,13,'Common-INI-settings','4434993ac013ae4d54bb1f51034d6401'),
 ('nop:','nop',1,15,0,0,1,15,14,'images','59b514174bffe4ae402b3d63aad79fe0'),
 ('eznode:50','eznode',1,16,0,1,2,16,15,'vbanner','c54e2d1b93642e280bdc5d99eab2827d'),
 ('eznode:53','eznode',1,34,0,0,1,20,17,'multimedia','2e5bc8831f7ae6a29530e7f1bbf2de9c'),
 ('eznode:52','eznode',1,33,0,0,1,19,17,'files','45b963397aa40d4a0063e0d85e4fe7a1'),
 ('eznode:51','eznode',1,32,0,0,1,18,17,'images','59b514174bffe4ae402b3d63aad79fe0'),
 ('eznode:74','eznode',1,55,0,1,2,55,20,'Banniere-transparente','5194bd3ece7cd8339c26338b17f057f7'),
 ('eznode:54','eznode',1,35,0,0,1,22,21,'common_ini_settings','e59d6834e86cee752ed841f9cd8d5baf'),
 ('eznode:56','eznode',1,37,0,0,2,24,25,'eZ-publish','10e4c3cb527fb9963258469986c16240'),
 ('eznode:56','eznode',1,24,0,1,2,24,25,'Plain-site','49a39d99a955d95aa5d636275656a07a'),
 ('eznode:66','eznode',1,47,0,1,2,47,42,'La-peluche-Mickey-Mouse','223d043e58e4337ad494fa19bd0e9e06'),
 ('eznode:68','eznode',1,49,0,1,2,49,42,'La-peluche-Donald-Duck','6a781099cfd163e651c0cbb2dc30d238'),
 ('eznode:67','eznode',1,48,0,1,2,48,42,'La-peluche-Minnie-Mouse','fbd361549b7c48bc446e28978d4aa28c'),
 ('eznode:70','eznode',1,51,0,1,2,51,45,'Arthur','68830aef4dbfad181162f9251a1da51b'),
 ('eznode:69','eznode',1,50,0,1,2,50,45,'Melanie','73aaec6dc33b96597d8019f7553e96a2');
/*!40000 ALTER TABLE `ezurlalias_ml` ENABLE KEYS */;


--
-- Dumping data for table `ezurlalias_ml_incr`
--

/*!40000 ALTER TABLE `ezurlalias_ml_incr` DISABLE KEYS */;
INSERT INTO `ezurlalias_ml_incr` (`id`) VALUES 
 (1),
 (2),
 (3),
 (4),
 (5),
 (6),
 (7),
 (8),
 (9),
 (10),
 (11),
 (12),
 (13),
 (14),
 (15),
 (16),
 (17),
 (18),
 (19),
 (20),
 (21),
 (22),
 (24),
 (25),
 (26),
 (27),
 (28),
 (29),
 (30),
 (31),
 (32),
 (33),
 (34),
 (35),
 (36),
 (37),
 (38),
 (39),
 (40),
 (41),
 (42),
 (43),
 (44),
 (45),
 (46),
 (47),
 (48),
 (49),
 (50),
 (51),
 (52),
 (53),
 (54),
 (55);
/*!40000 ALTER TABLE `ezurlalias_ml_incr` ENABLE KEYS */;


--
-- Dumping data for table `ezurlwildcard`
--

/*!40000 ALTER TABLE `ezurlwildcard` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezurlwildcard` ENABLE KEYS */;


--
-- Dumping data for table `ezuser`
--

/*!40000 ALTER TABLE `ezuser` DISABLE KEYS */;
INSERT INTO `ezuser` (`contentobject_id`,`email`,`login`,`password_hash`,`password_hash_type`) VALUES 
 (10,'nospam@ez.no','anonymous','4e6f6184135228ccd45f8233d72a0363',2),
 (14,'admin@nounours.local','admin','c78e3b0f3d9244ed8c6d1c29464bdff9',2);
/*!40000 ALTER TABLE `ezuser` ENABLE KEYS */;


--
-- Dumping data for table `ezuser_accountkey`
--

/*!40000 ALTER TABLE `ezuser_accountkey` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezuser_accountkey` ENABLE KEYS */;


--
-- Dumping data for table `ezuser_discountrule`
--

/*!40000 ALTER TABLE `ezuser_discountrule` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezuser_discountrule` ENABLE KEYS */;


--
-- Dumping data for table `ezuser_role`
--

/*!40000 ALTER TABLE `ezuser_role` DISABLE KEYS */;
INSERT INTO `ezuser_role` (`contentobject_id`,`id`,`limit_identifier`,`limit_value`,`role_id`) VALUES 
 (12,25,'','',2),
 (11,28,'','',1),
 (42,31,'','',1),
 (13,32,'Subtree','/1/2/',3),
 (13,33,'Subtree','/1/43/',3),
 (11,34,'','',5),
 (58,35,'','',4),
 (58,36,'','',5),
 (58,37,'','',1),
 (13,38,'','',5);
/*!40000 ALTER TABLE `ezuser_role` ENABLE KEYS */;


--
-- Dumping data for table `ezuser_setting`
--

/*!40000 ALTER TABLE `ezuser_setting` DISABLE KEYS */;
INSERT INTO `ezuser_setting` (`is_enabled`,`max_login`,`user_id`) VALUES 
 (1,1000,10),
 (1,10,14);
/*!40000 ALTER TABLE `ezuser_setting` ENABLE KEYS */;


--
-- Dumping data for table `ezuservisit`
--

/*!40000 ALTER TABLE `ezuservisit` DISABLE KEYS */;
INSERT INTO `ezuservisit` (`current_visit_timestamp`,`failed_login_attempts`,`last_visit_timestamp`,`login_count`,`user_id`) VALUES 
 (1307017539,0,1307017463,10,14);
/*!40000 ALTER TABLE `ezuservisit` ENABLE KEYS */;


--
-- Dumping data for table `ezvatrule`
--

/*!40000 ALTER TABLE `ezvatrule` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezvatrule` ENABLE KEYS */;


--
-- Dumping data for table `ezvatrule_product_category`
--

/*!40000 ALTER TABLE `ezvatrule_product_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezvatrule_product_category` ENABLE KEYS */;


--
-- Dumping data for table `ezvattype`
--

/*!40000 ALTER TABLE `ezvattype` DISABLE KEYS */;
INSERT INTO `ezvattype` (`id`,`name`,`percentage`) VALUES 
 (1,'Std',0);
/*!40000 ALTER TABLE `ezvattype` ENABLE KEYS */;


--
-- Dumping data for table `ezview_counter`
--

/*!40000 ALTER TABLE `ezview_counter` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezview_counter` ENABLE KEYS */;


--
-- Dumping data for table `ezwaituntildatevalue`
--

/*!40000 ALTER TABLE `ezwaituntildatevalue` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezwaituntildatevalue` ENABLE KEYS */;


--
-- Dumping data for table `ezwishlist`
--

/*!40000 ALTER TABLE `ezwishlist` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezwishlist` ENABLE KEYS */;


--
-- Dumping data for table `ezworkflow`
--

/*!40000 ALTER TABLE `ezworkflow` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezworkflow` ENABLE KEYS */;


--
-- Dumping data for table `ezworkflow_assign`
--

/*!40000 ALTER TABLE `ezworkflow_assign` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezworkflow_assign` ENABLE KEYS */;


--
-- Dumping data for table `ezworkflow_event`
--

/*!40000 ALTER TABLE `ezworkflow_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezworkflow_event` ENABLE KEYS */;


--
-- Dumping data for table `ezworkflow_group`
--

/*!40000 ALTER TABLE `ezworkflow_group` DISABLE KEYS */;
INSERT INTO `ezworkflow_group` (`created`,`creator_id`,`id`,`modified`,`modifier_id`,`name`) VALUES 
 (1024392098,14,1,1024392098,14,'Standard');
/*!40000 ALTER TABLE `ezworkflow_group` ENABLE KEYS */;


--
-- Dumping data for table `ezworkflow_group_link`
--

/*!40000 ALTER TABLE `ezworkflow_group_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezworkflow_group_link` ENABLE KEYS */;


--
-- Dumping data for table `ezworkflow_process`
--

/*!40000 ALTER TABLE `ezworkflow_process` DISABLE KEYS */;
/*!40000 ALTER TABLE `ezworkflow_process` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
