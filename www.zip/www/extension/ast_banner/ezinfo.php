<?php
class Ast_bannerInfo
{
    static function info()
    {
        return array(
'Name' => 'AST Banner',
'Version' => '1.0',
'Copyright' => 'Copyright (C) 2009-'
 . date('Y') . ' Alexandre SEBBANE',
'License' => 'GNU General Public License v2.0'
                     );
    }
}
?>
