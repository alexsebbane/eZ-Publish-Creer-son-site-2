<?php /*
 
[General]
AllowedTypes[]=astTransparentBanner

[astTransparentBanner]
Name=Transparent Banner (Manual)
NumberOfValidItems=1
NumberOfArchivedItems=0
ManualAddingOfItems=enabled
ViewList[]=version1
ViewName[version1]=Version 1


*/
?>