<?php 
/* #?ini charset="utf-8"?

[ExtensionSettings]
DesignExtensions[]=ast_banner

[StylesheetSettings]
FrontendCSSFileList[]=bannerblock.css

*/
?>
