<?php /* #?ini charset="utf-8"?


[block_astTransparentBanner_version1]
Source=block/view/view.tpl
MatchFile=block/transparentbanner.tpl
Subdir=templates
Match[type]=astTransparentBanner
Match[view]=version1


*/ ?>