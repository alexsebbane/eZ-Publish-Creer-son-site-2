<?php /*

[CronjobSettings]
ExtensionDirectories[]=ezcomments

[CronjobPart-ezcomments]
Scripts[]=ezcomhandlenotification.php

[CronjobPart-infrequent]
Scripts[]=ezcomcleanupsubscription.php

*/ ?>
