<?php /* #?ini charset="utf-8"?

[NavigationPart]
Part[ezcommentsnavigationpart]=eZComments

[TopAdminMenu]
Tabs[]=ezcomments

[Topmenu_ezcomments]
NavigationPartIdentifier=ezcommentsnavigationpart
Name=eZ Comments
Tooltip=eZ Comments dashboard
URL[]
URL[default]=comment/list
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[edit]=true
Shown[navigation]=true
Shown[browse]=true

PolicyList[]=comment/list

[Leftmenu_ezcomments]
Name=ezcommentsmenu
LinkNames[]
Links[]
Links[commentlist]=comment/list
*/ ?>
