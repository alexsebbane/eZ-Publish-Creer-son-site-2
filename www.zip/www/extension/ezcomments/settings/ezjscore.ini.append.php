<?php /*

[ezjscServer]
FunctionList[]=ezcomments_enabled

[ezjscServer_ezcom]
Class=ezcomServerFunctions
# Optionally define File to avoid relying on autoload system
File=extension/ezcomments/classes/ezcomserverfunctions.php
Functions[]=ezcomments_enabled

*/ ?>
