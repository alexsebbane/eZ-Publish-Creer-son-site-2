<?php /* #?ini charset="utf-8"?

[RegionalSettings]
TranslationExtensions[]=ezcomments

[RoleSettings]
PolicyOmitList[]=comment/activate
PolicyOmitList[]=comment/setting

*/ ?>
