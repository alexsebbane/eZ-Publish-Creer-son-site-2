<?php /* #?ini charset="utf-8"?

[DataTypeSettings]
ExtensionDirectories[]=ezcomments
AvailableDataTypes[]=ezcomcomments

*/ ?>
